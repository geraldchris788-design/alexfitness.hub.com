import nodemailer from 'nodemailer';
import crypto from 'crypto';

// Types and Interfaces
export interface EmailPayload {
  to: string;
  subject: string;
  html: string;
  text: string;
  type: 'verify' | 'welcome' | 'reset' | 'subscription' | 'receipt' | 'login_alert' | 'streak_achievement' | 'weekly_report' | 'workout_reminder';
}

export interface EmailLogEntry {
  id: string;
  to: string;
  subject: string;
  type: string;
  status: 'delivered' | 'failed' | 'pending_retry';
  attempts: number;
  createdAt: string;
  error?: string;
}

interface RetriableEmail {
  id: string;
  payload: EmailPayload;
  attempts: number;
  lastAttemptAt: string;
  nextAttemptAt: string;
  error?: string;
}

// In-Memory Retry Queue
const emailRetryQueue: RetriableEmail[] = [];

// DB Logging Hook Callback
let emailDbCallback: ((log: EmailLogEntry) => Promise<void>) | null = null;

export function registerEmailDbCallback(cb: (log: EmailLogEntry) => Promise<void>) {
  emailDbCallback = cb;
}

// Global Simulated Queue for Sandbox tray
const globalSimulatedInboxes: any[] = [];
export { globalSimulatedInboxes, emailRetryQueue };

// Professional brand constants matching AlexFitnessHub
const BRAND_GOLD = '#D97706';
const BRAND_BLACK = '#09090B';

/**
 * Renders the HTML templates for system dispatches with extreme polish.
 */
export function renderEmailTemplate(
  type: 'verify' | 'welcome' | 'reset' | 'subscription' | 'receipt' | 'login_alert' | 'streak_achievement' | 'weekly_report' | 'workout_reminder', 
  data: any
): string {
  const header = `
    <div style="background-color: ${BRAND_BLACK}; padding: 30px; text-align: center; border-radius: 4px 4px 0 0; border-bottom: 3px solid ${BRAND_GOLD};">
      <h1 style="color: #FFFFFF; font-family: 'Helvetica Neue', Arial, sans-serif; letter-spacing: 2px; margin: 0; font-size: 26px; font-weight: 900; text-transform: uppercase; font-style: italic;">ALEX<span style="color: ${BRAND_GOLD};">FITNESSHUB</span></h1>
      <p style="color: #666666; font-size: 10px; text-transform: uppercase; letter-spacing: 3px; margin: 5px 0 0 0; font-family: monospace;">Secured Transformation Channel</p>
    </div>
  `;
  
  const footer = `
    <div style="background-color: #111111; padding: 25px; text-align: center; border-radius: 0 0 4px 4px; border-top: 1px solid #222222; margin-top: 30px;">
      <p style="color: #888888; font-size: 11px; margin: 0; font-family: sans-serif;">This is a premium automated message from Coach Alex's Systems.</p>
      <p style="color: #555555; font-size: 10px; margin: 8px 0 0 0; font-family: monospace;">12 Military Barracks Rd, Lagos, Nigeria. Certified Secure Node</p>
      <p style="color: #444444; font-size: 9px; margin: 12px 0 0 0; font-family: sans-serif; line-height: 1.4;">
        Security Notice: If you did not trigger this request, please change your credentials immediately. This session is cryptographically signed using high-integrity protocols.
      </p>
    </div>
  `;

  if (type === 'verify') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Verify Email</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: ${BRAND_BLACK}; text-align: center;">🔑 VERIFY YOUR EMAIL ADDRESS</h2>
              <p>Welcome, <b>${data.name || 'Champion'}</b>!</p>
              <p>Your physical registration is pending lock. Confirm your account details with the secure link below to activate full fitness coaching access:</p>
              
              <div style="text-align: center; margin: 35px 0;">
                <a href="${data.verifyUrl}" style="background-color: ${BRAND_GOLD}; color: #000000; padding: 14px 30px; font-weight: 800; text-decoration: none; border-radius: 2px; letter-spacing: 1.5px; text-transform: uppercase; font-size: 13px; display: inline-block; box-shadow: 0 4px 10px rgba(217, 119, 6, 0.25);">Verify Account Email</a>
              </div>
              
              <p style="font-size: 11px; color: #999999; margin-top: 25px;">Please verify promptly. This token remains valid for exactly 24 hours.</p>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  if (type === 'welcome') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Welcome to AlexFitnessHub</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: ${BRAND_GOLD}; text-align: center;">🔥 Welcome to ALEXFITNESSHUB</h2>
              <p>Welcome to Coach Alex's Elite Fitness Community, <b>${data.name || 'Athlete'}</b>!</p>
              <p>Your account is created and instated. Here is your official registration details:</p>
              
              <div style="background-color: #F8F8F9; border: 1px solid #ECEAEA; padding: 20px; margin: 25px 0; border-radius: 3px;">
                <h4 style="margin: 0 0 10px 0; text-transform: uppercase; font-size: 12px; letter-spacing: 1px; color: ${BRAND_BLACK};">ACCOUNT INFORMATION:</h4>
                <p style="margin: 4px 0; font-size: 11px; font-family: monospace;"><b>Athlete Name:</b> ${data.name}</p>
                <p style="margin: 4px 0; font-size: 11px; font-family: monospace;"><b>Registered Email:</b> ${data.email}</p>
                <p style="margin: 4px 0; font-size: 11px; font-family: monospace;"><b>Access Status:</b> Pending Email Verification</p>
              </div>

              <p>To finalize your registered profile and verify ownership of your email, please act now and verify your email address following the button check below:</p>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="${data.verifyUrl}" style="background-color: ${BRAND_GOLD}; color: #000000; padding: 14px 30px; font-weight: 800; text-decoration: none; border-radius: 2px; letter-spacing: 1.5px; text-transform: uppercase; font-size: 13px; display: inline-block;">Verify My Email Address</a>
              </div>
              
              <p style="font-size: 12px; color: #666666;">After verification, you can login anytime at <a href="${data.loginUrl}" style="color: ${BRAND_GOLD}; text-decoration: none; font-weight: bold;">${data.loginUrl}</a>.</p>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  if (type === 'reset') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Reset Password</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: #BE123C; text-align: center;">🔒 RESET YOUR PASSWORD</h2>
              <p>Hello <b>${data.name || 'Athlete'}</b>,</p>
              <p>You requested a secure interface to update your password code. If this wasn't you, ignore this email safely.</p>
              
              <div style="text-align: center; margin: 35px 0;">
                <a href="${data.resetUrl}" style="background-color: ${BRAND_GOLD}; color: #000000; padding: 14px 30px; font-weight: 800; text-decoration: none; border-radius: 2px; letter-spacing: 1.5px; text-transform: uppercase; font-size: 13px; display: inline-block;">Reset Password Code</a>
              </div>
              
              <p style="font-size: 11px; color: #999999; margin-top: 25px;">This one-time update URL remains valid for exactly 30 minutes.</p>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  if (type === 'subscription') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Subscription Confirmed</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: ${BRAND_GOLD}; text-align: center;">🎖️ SUBSCRIPTION SUCCESSFUL</h2>
              <p>Dear <b>${data.name}</b>,</p>
              <p><b>Your premium athlete subscription is active!</b> Your profile is formally upgraded to the ALEXFITNESSHUB premium athlete club.</p>
              
              <table style="width: 100%; border-collapse: collapse; margin: 25px 0; font-size: 13px;">
                <tr style="background-color: #F8F8F9;">
                  <th style="padding: 10px; border: 1px solid #EAEAEA; text-align: left; font-weight: bold; color: ${BRAND_BLACK};">Access Matrix</th>
                  <th style="padding: 10px; border: 1px solid #EAEAEA; text-align: left; font-weight: bold; color: ${BRAND_BLACK};">Details</th>
                </tr>
                <tr>
                  <td style="padding: 10px; border: 1px solid #EAEAEA; font-family: monospace;"><b>Active Plan:</b></td>
                  <td style="padding: 10px; border: 1px solid #EAEAEA; color: ${BRAND_GOLD}; font-weight: bold;">${data.planName}</td>
                </tr>
                <tr>
                  <td style="padding: 10px; border: 1px solid #EAEAEA; font-family: monospace;"><b>Billing System:</b></td>
                  <td style="padding: 10px; border: 1px solid #EAEAEA; font-weight: bold;">One-Time Secured Clear</td>
                </tr>
                <tr>
                  <td style="padding: 10px; border: 1px solid #EAEAEA; font-family: monospace;"><b>Active Date:</b></td>
                  <td style="padding: 10px; border: 1px solid #EAEAEA; font-weight: bold;">${new Date().toLocaleDateString()}</td>
                </tr>
              </table>
              
              <h4 style="color: ${BRAND_BLACK}; font-size: 13px; text-transform: uppercase; letter-spacing: 1px;">MEMBERSHIP PREMIUM BENEFITS UNLOCKED:</h4>
              <ul style="padding-left: 20px; margin-top: 5px; font-size: 12.5px; color: #444444;">
                <li><b>Elite Workout Hub:</b> Tailored gym splits, custom calisthenics, intensive cardio schedules.</li>
                <li><b>Pro Diet Protocols:</b> Gourmet meal matrices (Nigerian and global compound macros).</li>
                <li><b>Generative AI AI-Coach:</b> Real-time consultation under private chat guidelines.</li>
                <li><b>Dual-Analytics Tracker:</b> Track visual metrics, log weights/meals, and dynamic streak counting.</li>
              </ul>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="${data.dashboardUrl || '/dashboard'}" style="background-color: #000000; color: #FFFFFF; padding: 13px 25px; font-weight: bold; text-decoration: none; border-radius: 2px; letter-spacing: 1.5px; text-transform: uppercase; font-size: 12px; display: inline-block;">Return to Elite Dashboard</a>
              </div>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  if (type === 'receipt') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Receipt</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: ${BRAND_BLACK}; text-align: center;">🧾 TRANSACTION RECEIPT</h2>
              <p>Dear <b>${data.name}</b>,</p>
              <p>Your payment went through successfully. Receipt details below:</p>
              
              <div style="background-color: #FAFAFA; padding: 25px; border: 1px solid #EEEEEE; font-family: monospace; font-size: 12px; color: #333333; margin: 25px 0;">
                <div style="text-align: center; font-weight: bold; font-size: 14px; margin-bottom: 20px; text-decoration: underline;">ALEXFITNESSHUB NIGERIA LTD</div>
                <div style="margin-bottom: 6px;"><b>RECEIPT REFERENCE:</b> ${data.transId}</div>
                <div style="margin-bottom: 6px;"><b>DATE:</b> ${data.date}</div>
                <div style="margin-bottom: 6px;"><b>EMAIL:</b> ${data.email}</div>
                <hr style="border: none; border-top: 1px dashed #CCCCCC; margin: 15px 0;">
                <div style="margin-bottom: 6px;">BASE AMOUNT: ${data.normalPrice} || DISCOUNT: ${data.savings}</div>
                <div style="font-size: 15px; font-weight: bold; color: #000000; margin-top: 10px;">TOTAL CHARGED: ${data.amount} NGN</div>
              </div>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  if (type === 'login_alert') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>New Login Detected</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: #D97706; text-align: center;">🚨 NEW LOGIN DETECTED</h2>
              <p>Hello <b>${data.name || 'Athlete'}</b>,</p>
              <p>We detected access to your Coach Alex dashboard from a modern login sequence.</p>
              
              <div style="background-color: #F8F8F9; border: 1px solid #ECEAEA; padding: 20px; margin: 25px 0; border-radius: 3px;">
                <h4 style="margin: 0 0 10px 0; text-transform: uppercase; font-size: 11px; letter-spacing: 1px; color: #000;">DEVICE / CONNECTION SPECIFICS:</h4>
                <p style="margin: 4px 0; font-size: 11.5px; font-family: monospace;"><b>Device/Browser:</b> ${data.device}</p>
                <p style="margin: 4px 0; font-size: 11.5px; font-family: monospace;"><b>Date Segment:</b> ${data.date}</p>
                <p style="margin: 4px 0; font-size: 11.5px; font-family: monospace;"><b>Time Segment (UTC):</b> ${data.time}</p>
                <p style="margin: 4px 0; font-size: 11.5px; font-family: monospace;"><b>IP Security Tag:</b> ${data.ip || '102.89.23.4 (Lagos, Nigeria)'}</p>
              </div>

              <p style="font-size: 12.5px; color: #444444;">If this was indeed you, no further action is necessary! Your sessions are cryptographically protected.</p>
              <p style="font-size: 12.5px; color: #BE123C; font-weight: bold; margin-top: 15px;">If this was NOT you, immediately reset your login credentials using the Account Dashboard to block unauthorized access.</p>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  if (type === 'streak_achievement') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Congratulations on Your Streak!</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 22px; text-transform: uppercase; letter-spacing: 1.5px; color: ${BRAND_GOLD}; text-align: center;">🔥 STREAK MILESTONE ACHIEVED</h2>
              <p>Dear <b>${data.name}</b>,</p>
              <p><b>Boom!</b> Your dedication is unmatched. The system registers that you have hit a massive daily activity milestone!</p>
              
              <div style="text-align: center; margin: 30px 0; padding: 20px; background-color: #000000; color: #FFFFFF; border-radius: 3px; border: 1px solid ${BRAND_GOLD};">
                <span style="font-size: 12px; text-transform: uppercase; letter-spacing: 2px; color: #888888; display: block;">Current Active Streak</span>
                <span style="font-size: 64px; font-weight: 900; color: ${BRAND_GOLD}; display: block; line-height: 1; margin: 10px 0;">${data.currentStreak} <span style="font-size: 24px; font-weight: 500; font-family: sans-serif;">DAYS</span></span>
                <span style="font-size: 11px; font-family: monospace; color: #666666;">LONGEST CONSECUTIVE RECORD: ${data.longestStreak} DAYS</span>
              </div>

              <blockquote style="border-left: 4px solid ${BRAND_GOLD}; padding: 10px 15px; margin: 20px 0; background-color: #FAFAFA; font-style: italic; font-size: 13px; color: #555555;">
                "${data.motivationalQuote || 'Consistency is the absolute key to permanent evolution. What we log today, we master tomorrow.'}"
              </blockquote>

              <p style="font-size: 13px; color: #444444;">Keep pushing, athlete! Share your achievements in the Coach Alex Support community or continuous tracking sheets to unlock visual accolades!</p>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  if (type === 'weekly_report') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Weekly Fitness Progress Report</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: #000000; text-align: center; border-bottom: 2px solid ${BRAND_GOLD}; padding-bottom: 10px;">📊 WEEKLY PROGRESS REPORT</h2>
              <p>Dear <b>${data.name}</b>,</p>
              <p>Excellent progress this week! Here is your customized high-integrity activity breakdown aggregated from your training and nutrition logs:</p>
              
              <div style="display: flex; flex-wrap: wrap; margin: 25px 0; justify-content: space-between; text-align: center;">
                <div style="flex: 1; min-width: 120px; background-color: #FAFAFA; border: 1px solid #ECEAEA; padding: 15px; margin: 5px; border-radius: 2px;">
                  <span style="font-size: 10px; text-transform: uppercase; letter-spacing: 1.5px; color: #888; display: block;">WORKOUTS</span>
                  <span style="font-size: 28px; font-weight: bold; color: ${BRAND_BLACK};">${data.workoutsCount}</span>
                </div>
                <div style="flex: 1; min-width: 120px; background-color: #FAFAFA; border: 1px solid #ECEAEA; padding: 15px; margin: 5px; border-radius: 2px;">
                  <span style="font-size: 10px; text-transform: uppercase; letter-spacing: 1.5px; color: #888; display: block;">CALORIES</span>
                  <span style="font-size: 28px; font-weight: bold; color: ${BRAND_GOLD};">${(data.caloriesBurned || 0).toLocaleString()}</span>
                </div>
                <div style="flex: 1; min-width: 120px; background-color: #FAFAFA; border: 1px solid #ECEAEA; padding: 15px; margin: 5px; border-radius: 2px;">
                  <span style="font-size: 10px; text-transform: uppercase; letter-spacing: 1.5px; color: #888; display: block;">GOALS MET</span>
                  <span style="font-size: 28px; font-weight: bold; color: #10B981;">${data.completedGoalsCount}</span>
                </div>
              </div>

              <div style="background-color: #FAFAFA; border: 1px solid #ECEAEA; padding: 20px; border-radius: 3px; margin: 25px 0;">
                <h4 style="margin: 0 0 10px 0; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: #000;">PROGRESSIVE ANALYSIS METRICS:</h4>
                <p style="margin: 5px 0; font-size: 12px;"><b>Training Days:</b> ${data.activeDays || 0} / 7 active days logged</p>
                <p style="margin: 5px 0; font-size: 12px;"><b>Weight Alteration:</b> ${data.progressWeightChange || '0.0 kg stability'}</p>
                <p style="margin: 5px 0; font-size: 12px;"><b>Report Window:</b> ${data.weekStart} to ${data.weekEnd}</p>
              </div>

              <p style="font-size: 12.5px; color: #555555; text-align: center;">Commit to another solid cycle. Open your Coach Alex system profile to plan next week's macro levels. Let's do this!</p>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  if (type === 'workout_reminder') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Workout Reminder - Time to Crush Your Goals!</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: ${BRAND_GOLD}; text-align: center;">⚡ TIME TO TRAIN, CHAMPION</h2>
              <p>Hey <b>${data.name || 'Athlete'}</b>,</p>
              <p>This is your official Coach Alex daily physical check. Your body adapts to the demands you consistently place on it—don't miss today's training stimulus.</p>
              
              <div style="background-color: #F8F8F9; border: 1px solid #ECEAEA; padding: 20px; margin: 25px 0; border-radius: 3px; border-left: 4px solid ${BRAND_GOLD};">
                <h4 style="margin: 0 0 10px 0; letter-spacing: 1px; color: ${BRAND_BLACK}; text-transform: uppercase; font-size: 11px;">TODAY'S TARGET METADATA:</h4>
                <p style="margin: 4px 0; font-size: 12px;"><b>Suggested split:</b> ${data.splitName || 'Compound Hypertrophy (Full Body)'}</p>
                <p style="margin: 4px 0; font-size: 12px;"><b>Duration check:</b> 45 - 60 Minutes</p>
                <p style="margin: 4px 0; font-size: 12px;"><b>Target macros:</b> Pre-workout complex carb, high protein hydration</p>
              </div>

              <p>Success is built on daily micro-decisions. Open your training board right now to log your sets and preserve your consecutive daily streak counts:</p>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="${data.dashboardUrl || '/dashboard'}" style="background-color: #000000; color: #FFFFFF; padding: 13px 25px; font-weight: bold; text-decoration: none; border-radius: 2px; letter-spacing: 1.5px; text-transform: uppercase; font-size: 12px; display: inline-block;">Launch My Training Board</a>
              </div>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  return `<p>Secure email format generated.</p>`;
}

/**
 * Core raw delivery dispatcher attempting direct API or fallback channels.
 */
async function attemptSend(payload: EmailPayload, isRetry: boolean = false): Promise<boolean> {
  const { to, subject, html, text, type } = payload;
  const resendApiKey = process.env.RESEND_API_KEY;
  
  if (resendApiKey && resendApiKey !== '' && resendApiKey !== 'MY_RESEND_API_KEY') {
    try {
      const fromEmail = process.env.RESEND_FROM_EMAIL || 'onboarding@resend.dev';
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${resendApiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: `AlexFitnessHub <${fromEmail}>`,
          to: [to],
          subject: subject,
          html: html,
          text: text
        })
      });

      if (res.ok) {
        console.log(`[EMAIL COURIER] Resend API successful delivery to: ${to}`);
        return true;
      } else {
        const errorText = await res.text();
        console.error(`[EMAIL COURIER] Resend API rejected: ${errorText}`);
      }
    } catch (err) {
      console.error(`[EMAIL COURIER] Resend API error trace:`, err);
    }
  }

  // Fallback traditional SMTP transport
  const smtpHost = process.env.EMAIL_SERVER_HOST;
  const smtpPort = process.env.EMAIL_SERVER_PORT;
  const smtpUser = process.env.EMAIL_SERVER_USER;
  const smtpPass = process.env.EMAIL_SERVER_PASSWORD;

  if (smtpHost && smtpPort && smtpUser && smtpPass) {
    try {
      const transporter = nodemailer.createTransport({
        host: smtpHost,
        port: parseInt(smtpPort),
        secure: parseInt(smtpPort) === 465,
        auth: {
          user: smtpUser,
          pass: smtpPass
        },
        tls: {
          rejectUnauthorized: false
        }
      });

      const fromAddress = process.env.EMAIL_FROM || '"AlexFitnessHub" <no-reply@alexfit.com>';
      await transporter.sendMail({
        from: fromAddress,
        to,
        subject,
        text,
        html
      });

      console.log(`[EMAIL COURIER] SMTP Nodemailer successful delivery to: ${to}`);
      return true;
    } catch (err) {
      console.error(`[EMAIL COURIER] SMTP Nodemailer error trace:`, err);
    }
  }

  // If both configurations are absent, they fallback to local simulation
  if (!resendApiKey && !smtpHost) {
    console.log(`[EMAIL COURIER] No configuration present. Simulated sandbox delivery verified for: ${to}`);
    return true;
  }

  return false;
}

/**
 * Securely dispatches email through Resend API, SMTP Nodemailer, or falls back to Simulation Logs
 */
export async function sendEmail(payload: EmailPayload): Promise<boolean> {
  const { to, subject, html, text, type } = payload;
  
  // Ensure we register on global simulated inboxes for full sandbox tray UI experience
  const logObj = {
    id: `email-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    to: to.toLowerCase(),
    subject,
    html,
    text,
    createdAt: new Date().toISOString(),
    type
  };
  globalSimulatedInboxes.unshift(logObj);
  if (globalSimulatedInboxes.length > 50) globalSimulatedInboxes.pop();

  // Try to dispatch primary
  const success = await attemptSend(payload);
  
  const nowStr = new Date().toISOString();

  if (success) {
    // Deliver history immediately
    if (emailDbCallback) {
      emailDbCallback({
        id: logObj.id,
        to: to.toLowerCase(),
        subject,
        type,
        status: 'delivered',
        attempts: 1,
        createdAt: nowStr
      });
    }
    return true;
  } else {
    // Trigger failure queuing and retries
    console.log(`[EMAIL COURIER] Delivery failed. Adding to active retry queue for automated trace...`);
    
    const queueItem: RetriableEmail = {
      id: logObj.id,
      payload,
      attempts: 1,
      lastAttemptAt: nowStr,
      nextAttemptAt: new Date(Date.now() + 1 * 60 * 1000).toISOString(), // retry in 1 minute
    };
    
    emailRetryQueue.push(queueItem);

    if (emailDbCallback) {
      emailDbCallback({
        id: logObj.id,
        to: to.toLowerCase(),
        subject,
        type,
        status: 'pending_retry',
        attempts: 1,
        createdAt: nowStr,
        error: 'Initial delivery failure'
      });
    }
    return false;
  }
}

// Background Retry Worker Running Automatically
if (typeof setInterval !== 'undefined') {
  setInterval(async () => {
    const now = new Date();
    // Use traditional for loop to avoid array modification side effects
    for (let i = emailRetryQueue.length - 1; i >= 0; i--) {
      const item = emailRetryQueue[i];
      if (item.attempts < 3 && new Date(item.nextAttemptAt) <= now) {
        item.attempts++;
        item.lastAttemptAt = now.toISOString();
        console.log(`[EMAIL AUTOMATED RETRY] Attempt #${item.attempts}/3 for ${item.payload.to} (${item.payload.type})`);
        
        const success = await attemptSend(item.payload, true);
        if (success) {
          console.log(`[EMAIL AUTOMATED RETRY] Successful dispatch recovery on attempt #${item.attempts}!`);
          emailRetryQueue.splice(i, 1);
          
          if (emailDbCallback) {
            emailDbCallback({
              id: item.id,
              to: item.payload.to,
              subject: item.payload.subject,
              type: item.payload.type,
              status: 'delivered',
              attempts: item.attempts,
              createdAt: item.lastAttemptAt
            });
          }
        } else {
          // Exponential Backoff increment (e.g. attempt 2 -> 4 minutes, attempt 3 -> 8 minutes)
          const multiplier = Math.pow(2, item.attempts);
          item.nextAttemptAt = new Date(Date.now() + multiplier * 60 * 1000).toISOString();
          
          console.log(`[EMAIL AUTOMATED RETRY] Failed recovery. Next retry scheduled at: ${item.nextAttemptAt}`);

          if (emailDbCallback) {
            emailDbCallback({
              id: item.id,
              to: item.payload.to,
              subject: item.payload.subject,
              type: item.payload.type,
              status: 'pending_retry',
              attempts: item.attempts,
              createdAt: item.lastAttemptAt,
              error: `Retry #${item.attempts} failed`
            });
          }

          if (item.attempts >= 3) {
            console.error(`[EMAIL AUTOMATED RETRY] Max retries exhausted. Removing from retry queues.`);
            emailRetryQueue.splice(i, 1);
            
            if (emailDbCallback) {
              emailDbCallback({
                id: item.id,
                to: item.payload.to,
                subject: item.payload.subject,
                type: item.payload.type,
                status: 'failed',
                attempts: item.attempts,
                createdAt: item.lastAttemptAt,
                error: 'Max retry attempts exhausted'
              });
            }
          }
        }
      }
    }
  }, 30000); // Poll and run checks every 30 seconds
}
