import 'dotenv/config';

const isProduction = process.env.NODE_ENV === 'production';

export const MONNIFY_CONFIG = {
  apiKey: process.env.MONNIFY_API_KEY || '',
  secretKey: process.env.MONNIFY_SECRET_KEY || '',
  contractCode: process.env.MONNIFY_CONTRACT_CODE || '',
  // Use the env variable if specified; fallback to sandbox or live depending on NODE_ENV
  baseUrl: process.env.MONNIFY_BASE_URL || (isProduction ? 'https://api.monnify.com' : 'https://sandbox.monnify.com'),
  isProduction
};
