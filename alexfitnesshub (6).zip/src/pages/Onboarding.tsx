import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Dumbbell, ArrowRight, ArrowLeft, Sparkles, Trophy, Apple, HeartPulse, RefreshCw } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Onboarding() {
  const navigate = useNavigate();
  const { user: currentUser, loading: authLoading, updateProfile } = useAuth();
  
  // Questionnaire states
  const [step, setStep] = useState(1);
  const [fitnessGoals, setFitnessGoals] = useState('muscle-gain');
  const [gender, setGender] = useState('male');
  const [age, setAge] = useState('25');
  const [height, setHeight] = useState('175');
  const [currentWeight, setCurrentWeight] = useState('80');
  const [targetWeight, setTargetWeight] = useState('78');
  const [activityLevel, setActivityLevel] = useState('moderate');
  const [dietaryPrefs, setDietaryPrefs] = useState('high-protein');
  const [isLoading, setIsLoading] = useState(false);
  const [errorText, setErrorText] = useState<string | null>(null);

  if (authLoading) {
    return (
      <div className="pt-32 pb-16 min-h-screen bg-black flex flex-col items-center justify-center text-center px-4">
        <RefreshCw className="h-8 w-8 animate-spin text-amber-500 mb-4" />
        <p className="text-xs text-neutral-450 font-mono tracking-widest uppercase">Initializing Athletic Profile details...</p>
      </div>
    );
  }

  if (!currentUser) {
    // If guest accesses onboarding, gracefully take them to sign up
    return (
      <div className="pt-32 pb-16 min-h-screen bg-black flex flex-col items-center justify-center text-center px-4">
        <span className="text-amber-500 text-3xl">⚠️</span>
        <h2 className="font-bebas text-2xl text-white mt-3 uppercase tracking-wider">Access Restricted</h2>
        <p className="text-xs text-neutral-450 mt-1 max-w-sm">
          Please create an athletic profile first or login to configure your metric onboarding charts.
        </p>
        <button 
          onClick={() => navigate('/auth/signup')}
          className="mt-6 px-6 py-2.5 bg-amber-500 text-black font-bold uppercase text-[10px] tracking-wider rounded-full cursor-pointer"
        >
          Create Profile
        </button>
      </div>
    );
  }

  const handleNextStep = () => {
    setStep(prev => prev + 1);
  };

  const handlePrevStep = () => {
    setStep(prev => prev - 1);
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    setErrorText(null);
    try {
      if (!currentUser) throw new Error("A authenticated user context was not detected.");

      await updateProfile({
        ...currentUser,
        fitnessGoals: [fitnessGoals],
        gender,
        age: Number(age),
        height: Number(height),
        currentWeight: Number(currentWeight),
        targetWeight: Number(targetWeight),
        activityLevel
      });
      
      setTimeout(() => {
        navigate('/dashboard');
      }, 1000);
    } catch (err: any) {
      console.error("[ONBOARDING ERROR]", err);
      setErrorText(err.message || "Failed to finalize biometrics onboarding parameters.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-black text-white pt-28 pb-16 min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
      
      {/* Decorative premium glows */}
      <div className="absolute top-1/4 left-10 w-96 h-96 bg-amber-500/5 rounded-full blur-[150px] pointer-events-none"></div>
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-emerald-500/5 rounded-full blur-[130px] pointer-events-none"></div>

      <div className="bg-neutral-950 border border-neutral-900 rounded-2xl p-6 sm:p-10 max-w-xl w-full text-left shadow-2xl relative z-10">
        
        {/* Progress header bar */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 bg-amber-500 rounded flex items-center justify-center">
              <Dumbbell className="h-3 w-3 text-black" />
            </div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-neutral-450 font-mono">
              Onboarding Phase
            </span>
          </div>
          <span className="text-[10px] font-mono text-amber-500 font-extrabold bg-amber-500/10 border border-amber-500/20 px-2.5 py-0.5 rounded-full">
            Step {step} of 4
          </span>
        </div>

        {/* Form Error Banner */}
        {errorText && (
          <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded text-rose-500 text-xs italic mb-6">
            {errorText}
          </div>
        )}

        {/* Step 1: Physical Direction Goals */}
        {step === 1 && (
          <div className="space-y-6">
            <div className="space-y-1.5">
              <h2 className="font-bebas text-2xl sm:text-3xl font-extrabold tracking-wider text-white">CHOOSE YOUR TARGET DIRECTION</h2>
              <p className="text-xs text-neutral-450 uppercase tracking-wider">Select the primary focus of your training program</p>
            </div>

            <div className="space-y-3 pt-2">
              {[
                { id: 'muscle-gain', label: 'Hypertrophy Muscle Gain', desc: 'Secure structural mass and target absolute body symmetrical proportions.', icon: Trophy },
                { id: 'fat-loss', label: 'Metabolic Fat Reduction', desc: 'Caloric restriction deficits matched with high-protein traditional options.', icon: Apple },
                { id: 'military', label: 'Military Calisthenics & Power', desc: 'Gravitational resistance parameters for tendons resilience, endurance push, and passing physicals.', icon: HeartPulse },
                { id: 'health-reversal', label: 'Somatic Health & Joint Reversal', desc: 'Low impact flexibility walks, sugar homeostasis, and joint rehabilitation.', icon: Sparkles }
              ].map((goalItem) => {
                const GoalIcon = goalItem.icon;
                const isSelected = fitnessGoals === goalItem.id;
                return (
                  <button
                    key={goalItem.id}
                    onClick={() => setFitnessGoals(goalItem.id)}
                    className={`w-full p-4 rounded-xl text-left border transition-all duration-200 flex items-start gap-4 cursor-pointer ${
                      isSelected 
                        ? 'bg-amber-500/5 border-amber-500 text-white shadow-lg' 
                        : 'bg-neutral-900/40 border-neutral-900 text-neutral-400 hover:border-neutral-800'
                    }`}
                  >
                    <div className={`p-2.5 rounded-lg border my-auto ${
                      isSelected ? 'bg-amber-500/20 border-amber-500/30 text-amber-500' : 'bg-neutral-950 border-neutral-850 text-neutral-500'
                    }`}>
                      <GoalIcon className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-200">{goalItem.label}</h4>
                      <p className="text-[11px] text-neutral-400 mt-1 italic">{goalItem.desc}</p>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="pt-4 flex justify-end">
              <button
                onClick={handleNextStep}
                className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-black text-xs font-black uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>Continue</span>
                <ArrowRight className="h-4.5 w-4.5" />
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Biometrics inputs */}
        {step === 2 && (
          <div className="space-y-6">
            <div className="space-y-1.5">
              <h2 className="font-bebas text-2xl sm:text-3xl font-extrabold tracking-wider text-white">PHYSICAL BIOPHYSICS PARAMETERS</h2>
              <p className="text-xs text-neutral-450 uppercase tracking-wider">Provide initial statistics for caloric models computations</p>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="flex flex-col space-y-1">
                <label className="text-[10px] uppercase text-neutral-400 font-bold font-mono">Gender Group</label>
                <div className="grid grid-cols-2 gap-2">
                  {['male', 'female'].map((g) => (
                    <button
                      key={g}
                      type="button"
                      onClick={() => setGender(g)}
                      className={`py-2 text-xs uppercase font-extrabold rounded-sm border transition-all cursor-pointer ${
                        gender === g ? 'bg-amber-500 text-black border-amber-500' : 'bg-neutral-950 text-neutral-400 border-neutral-900'
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-col space-y-1">
                <label className="text-[10px] uppercase text-neutral-400 font-bold font-mono">Age (Years)</label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="bg-neutral-950 border border-neutral-900 rounded p-2.5 text-xs text-white outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex flex-col space-y-1">
                <label className="text-[10px] uppercase text-neutral-400 font-bold font-mono">Height (cm)</label>
                <input
                  type="number"
                  value={height}
                  onChange={(e) => setHeight(e.target.value)}
                  className="bg-neutral-950 border border-neutral-900 rounded p-2.5 text-xs text-white outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex flex-col space-y-1">
                <label className="text-[10px] uppercase text-neutral-400 font-bold font-mono">Current Weight (kg)</label>
                <input
                  type="number"
                  value={currentWeight}
                  onChange={(e) => setCurrentWeight(e.target.value)}
                  className="bg-neutral-950 border border-neutral-900 rounded p-2.5 text-xs text-white outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex flex-col space-y-1 col-span-2">
                <label className="text-[10px] uppercase text-neutral-400 font-bold font-mono">Target Weight (kg)</label>
                <input
                  type="number"
                  value={targetWeight}
                  onChange={(e) => setTargetWeight(e.target.value)}
                  className="bg-neutral-950 border border-neutral-900 rounded p-2.5 text-xs text-white outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="pt-4 flex justify-between">
              <button
                onClick={handlePrevStep}
                className="px-5 py-3 border border-neutral-900 hover:bg-neutral-900 text-neutral-400 text-xs font-bold uppercase rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back</span>
              </button>
              <button
                onClick={handleNextStep}
                className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-black text-xs font-black uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>Continue</span>
                <ArrowRight className="h-4.5 w-4.5" />
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Activeness Multipliers */}
        {step === 3 && (
          <div className="space-y-6">
            <div className="space-y-1.5">
              <h2 className="font-bebas text-2xl sm:text-3xl font-extrabold tracking-wider text-white">DAILY METABOLIC CADENCE</h2>
              <p className="text-xs text-neutral-450 uppercase tracking-wider">How active is your standard muscle load weekly?</p>
            </div>

            <div className="space-y-3 pt-2">
              {[
                { id: 'sedentary', label: 'Sedentary / Office Worker', multiplier: '1.2x factor', desc: 'No scheduled exercise. Mostly desk and command station duties.' },
                { id: 'light', label: 'Lightly Active Student/Candidate', multiplier: '1.375x factor', desc: 'Gentle walk or calisthenics 1-2 times weekly.' },
                { id: 'moderate', label: 'Moderately Active Athlete', multiplier: '1.55x factor', desc: 'Gym compound logs 3-4 times weekly with deep muscle fatigue.' },
                { id: 'very', label: 'Extremely Active Military Candidate', multiplier: '1.725x factor', desc: 'Explosive high-intensity power sessions 6+ days weekly.' }
              ].map((activityItem) => {
                const isSelected = activityLevel === activityItem.id;
                return (
                  <button
                    key={activityItem.id}
                    onClick={() => setActivityLevel(activityItem.id)}
                    className={`w-full p-4 rounded-xl text-left border transition-all duration-200 flex justify-between items-center cursor-pointer ${
                      isSelected 
                        ? 'bg-amber-500/5 border-amber-500 text-white shadow-md' 
                        : 'bg-neutral-900/40 border-neutral-900 text-neutral-400 hover:border-neutral-800'
                    }`}
                  >
                    <div className="pr-2">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-200">{activityItem.label}</h4>
                      <p className="text-[11px] text-neutral-400 mt-1 italic leading-normal">{activityItem.desc}</p>
                    </div>
                    <span className="text-[9px] font-mono text-amber-500 font-bold border border-amber-500/20 bg-amber-500/10 px-2 py-1 rounded shrink-0">
                      {activityItem.multiplier}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="pt-4 flex justify-between">
              <button
                onClick={handlePrevStep}
                className="px-5 py-3 border border-neutral-900 hover:bg-neutral-900 text-neutral-400 text-xs font-bold uppercase rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back</span>
              </button>
              <button
                onClick={handleNextStep}
                className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-black text-xs font-black uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>Continue</span>
                <ArrowRight className="h-4.5 w-4.5" />
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Dietary preferences summary */}
        {step === 4 && (
          <div className="space-y-6">
            <div className="space-y-1.5">
              <h2 className="font-bebas text-2xl sm:text-3xl font-extrabold tracking-wider text-white">NUTRITIONAL CORNER SETUPS</h2>
              <p className="text-xs text-neutral-450 uppercase tracking-wider">Confirm nutritional categories inputs</p>
            </div>

            <div className="space-y-3 pt-2">
              {[
                { id: 'high-protein', label: 'Balanced High Protein Whole Foods', desc: 'Focus heavily on grilled croaker, eggs, turkey, sweet-potato, and oats.' },
                { id: 'vegan', label: 'Clean Vegan / Vegetable Fibers', desc: 'Rich vegetable soups, beans, fruit salads, soy proteins, and grains.' },
                { id: 'traditional-nigerian', label: 'Traditional Anabolic Nigerian Meal Setups', desc: 'Focusing on Moi Moi, Garri (Eba), Akara, plantain, and bean cakes.' }
              ].map((dietItem) => {
                const isSelected = dietaryPrefs === dietItem.id;
                return (
                  <button
                    key={dietItem.id}
                    onClick={() => setDietaryPrefs(dietItem.id)}
                    className={`w-full p-4 rounded-xl text-left border transition-all duration-205 flex items-start gap-4 cursor-pointer ${
                      isSelected 
                        ? 'bg-amber-500/5 border-amber-500 text-white shadow-lg' 
                        : 'bg-neutral-900/40 border-neutral-900 text-neutral-400 hover:border-neutral-800'
                    }`}
                  >
                    <div className="pt-0.5">
                      <div className={`w-4- h-4 rounded-full border flex items-center justify-center p-0.5 ${isSelected ? 'border-amber-500 text-amber-500' : 'border-neutral-800 text-transparent'}`}>
                        {isSelected && <span className="w-1.5 h-1.5 bg-amber-500 rounded-full"></span>}
                      </div>
                    </div>
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-200">{dietItem.label}</h4>
                      <p className="text-[11px] text-neutral-400 mt-1 italic">{dietItem.desc}</p>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Calculated Somatic Metrics */}
            <div className="p-4 bg-amber-500/5 border border-amber-500/15 rounded-xl space-y-2 text-xs text-left">
              <div className="flex justify-between font-mono text-[10px] text-amber-500 font-bold uppercase tracking-wider">
                <span>Personalized Somatic Metrics</span>
                <span>Active</span>
              </div>
              <p className="text-neutral-400">
                Your somatic metrics profile predicts an estimated BMR value of <strong className="text-white">{(10 * Number(currentWeight) + 6.25 * Number(height) - 5 * Number(age) + 5).toFixed(0)} kcal</strong>. Your customized protein targets will target exactly <strong className="text-white">{Math.round(Number(currentWeight) * 2.0)}g</strong> of whole grains & raw protein factors daily.
              </p>
            </div>

            <div className="pt-4 flex justify-between">
              <button
                onClick={handlePrevStep}
                disabled={isLoading}
                className="px-5 py-3 border border-neutral-900 hover:bg-neutral-900 text-neutral-400 text-xs font-bold uppercase rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back</span>
              </button>
              <button
                onClick={handleSubmit}
                disabled={isLoading}
                className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-black text-xs font-black uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-amber-500/10"
              >
                <span>{isLoading ? 'Synchronizing...' : 'Launch Premium Dashboard'}</span>
                <ArrowRight className="h-4.5 w-4.5" />
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
