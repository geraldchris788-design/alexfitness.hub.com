import React, { useState } from 'react';
import { Target, Zap, Shield, HelpCircle, Lock, Crown, ArrowRight, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getMediaProxyUrl } from '../lib/api';

export default function Calisthenics() {
  const { user: authUser, loading: authLoading } = useAuth();
  const [selectedSpec, setSelectedSpec] = useState<'push' | 'pull' | 'core' | 'running'>('push');
  const isPremium = authUser?.subscriptionStatus === 'premium' || authUser?.email === 'muzikworld08@gmail.com' || (authUser as any)?.role === 'admin';

  const calisthenicsPrograms = {
    push: {
      title: "TACTICAL PUSH MODULES",
      rounds: "Perform 4 Rounds twice weekly",
      exercises: [
        { name: "Perfect Decelerate Push-Up", specs: "20 Reps", sub: "Control chest downward for 3 full seconds, explode up.", gif: "https://i.pinimg.com/originals/48/da/79/48da79042a1a23b3060e4fa684b8af90.gif" },
        { name: "Wide-Arm Knuckle Press", specs: "15 Reps", sub: "Hard grip on floor. Recruits shoulder blade stability and clavicle fibers.", gif: "https://fitnessprogramer.com/wp-content/uploads/2022/07/Knuckle-Push-Up.gif" },
        { name: "Incline Couch/Bench Pushup", specs: "25 Reps", sub: "Mechanical drop-offset to target lower pecs and triceps.", gif: "https://media.tenor.com/e45GckrMBLEAAAAM/flex%C3%A3o-inclinada-no-banco.gif" },
        { name: "Military Head-to-Wall Handstand", specs: "30s Hold", sub: "Excellent structural shoulder capacity developer.", gif: "https://liftmanual.com/wp-content/uploads/2023/04/handstand-hold-on-wall.gif" }
      ]
    },
    pull: {
      title: "DEAD-HANG PULL MODULES",
      rounds: "Perform 3 Rounds twice weekly",
      exercises: [
        { name: "Strict Dead-Hang Pull-Up", specs: "10-12 Reps", sub: "Do not kick hips. Complete vertical lat leverage only.", png: "https://fitnessprogramer.com/wp-content/uploads/2021/02/dead-hang.png" },
        { name: "Wide Grip Lat Isolation Bar Pull", specs: "8 Reps", sub: "Hands triple shoulder width. Targets upper lat sweep arches.", gif: "https://fitnessprogramer.com/wp-content/uploads/2021/02/Pull-up.gif" },
        { name: "Chin Ups (Underhand grip)", specs: "12 Reps", sub: "Bicep dominant pulling with chest touching the bar.", gif: "https://fitnessprogramer.com/wp-content/uploads/2021/03/Chin-Up.gif" },
        { name: "Australian Bar Rows (Low bar)", specs: "20 Reps", sub: "Feet extended on floor. Squeeze middle rhomboids.", gif: "https://api.smartworkout.app/asset/image/a57e3d8b-2b77-48b8-a14f-058d0f9524ea" }
      ]
    },
    core: {
      title: "STABILIZATION CORE MODULES",
      rounds: "Perform 4 Rounds thrice weekly",
      exercises: [
        { name: "Military Cadet Strict Sit-Ups", specs: "50 Reps", sub: "Hands supporting lower neck. Touch elbows to knees consecutively.", gif: "https://fitnessprogramer.com/wp-content/uploads/2021/02/Sit-up.gif" },
        { name: "Incline Ab Hanging Raise", specs: "15 Reps", sub: "Focus entirely on rotating lower pelvis upward.", gif: "https://fitnessprogramer.com/wp-content/uploads/2021/08/Hanging-Leg-Raises.gif" },
        { name: "L-Sit Parallette Hold", specs: "20s Hold", sub: "Press body high off arms, locking legs fully straight.", gif: "https://fitnessprogramer.com/wp-content/uploads/2022/02/L-sit.gif" },
        { name: "Side Hip Star-Planks", specs: "45s per side", sub: "Extreme oblique stabilizer load.", gif: "https://fitnessprogramer.com/wp-content/uploads/2021/10/Side-Plank.gif" }
      ]
    },
    running: {
      title: "TACTICAL RUNNING & STAMINA",
      rounds: "Track bi-weekly targets",
      exercises: [
        { name: "5KM Base Aero Run", specs: "Under 25:00", sub: "Steady zone 3 aerobic conditioning pace.", gif: "https://fitnessprogramer.com/wp-content/uploads/2021/08/Running.gif" },
        { name: "400m Track Intervals", specs: "8 Repeats", sub: "Sprint 400m, followed by 90s complete slow walk recovery.", gif: "https://fitnessprogramer.com/wp-content/uploads/2021/08/Running.gif" },
        { name: "Hill Sprints (Incline 10%+)", specs: "10 Rounds", sub: "30-second explosive climbs. Triggers quad and cardiovascular peak.", gif: "https://fitnessprogramer.com/wp-content/uploads/2021/04/Treadmill-Incline.gif" },
        { name: "Obstacle Bear Walks", specs: "50 Meters", sub: "High hips, hands and feet scraping floor. Elite stamina burner.", gif: "https://fitnessprogramer.com/wp-content/uploads/2022/01/Bear-Crawl.gif" }
      ]
    }
  };

  if (authLoading) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin text-amber-500 font-bold" />
      </div>
    );
  }

  if (!isPremium) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex flex-col items-center justify-center px-4 relative overflow-hidden">
        {/* Cinematic Backdrop Pattern */}
        <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-[120px]"></div>
        
        <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-lg w-full text-center space-y-6 shadow-2xl relative z-10">
          <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full flex items-center justify-center mx-auto">
            <Lock className="h-6 w-6" />
          </div>
          <div>
            <h2 className="font-syne text-3xl font-extrabold tracking-wide uppercase">TACTICAL CALISTHENICS LOCKED</h2>
            <p className="text-[10px] text-amber-500 font-mono tracking-widest mt-1.5 uppercase">ATHLETE AUTHENTICATION & PREMIUM SUBSCRIPTION REQUIRED</p>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans font-light">
            Gain full, unrestricted access to the special forces athletic conditioning tracks: push modules, dead-hang vertical lat pull regimes, core isometric holds, and extreme running splits.
          </p>
          <div className="pt-2 flex flex-col gap-3">
            <Link
              to="/pricing"
              className="w-full bg-amber-500 hover:bg-gold hover:scale-[1.02] text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded-sm block transition-all font-mono"
            >
              Get Premium Access Now
            </Link>
            <Link
              to="/"
              className="w-full bg-neutral-900 border border-neutral-850 hover:bg-neutral-850 text-white font-bold uppercase text-xs tracking-widest py-3 rounded-sm block transition-all font-mono"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-black text-white pt-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-amber-500 uppercase text-xs font-bold tracking-widest mb-2 font-mono">SPECIAL FORCES CONDITIONING</p>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black text-white tracking-wide">
            MILITARY <span className="text-amber-500">CALISTHENICS</span>
          </h1>
          <p className="text-neutral-400 mt-4 leading-relaxed font-light">
            Engineered guidelines to unlock raw physical steel without plates. Learn strict progression metrics for tactical fitness and supreme endurance.
          </p>
        </div>

        {/* Tab filters */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mb-12">
          {[
            { id: 'push', label: 'Push Modules' },
            { id: 'pull', label: 'Pull Modules' },
            { id: 'core', label: 'Core / Situps' },
            { id: 'running', label: 'Tactical Runs' }
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setSelectedSpec(t.id as any)}
              className={`py-3.5 rounded font-bebas text-lg tracking-wider transition-all border ${
                selectedSpec === t.id
                  ? 'bg-amber-500 text-black border-amber-500 font-extrabold shadow-lg shadow-amber-500/10'
                  : 'bg-neutral-950 border-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Selected target Program */}
        <div className="bg-neutral-950 border border-neutral-900 p-8 rounded-lg max-w-4xl mx-auto mb-16 relative overflow-hidden min-h-[350px] flex flex-col justify-between">
          
          {(!isPremium && selectedSpec !== 'push') ? (
            /* Premium Locker Screen */
            <div className="absolute inset-0 bg-black/95 backdrop-blur-sm z-30 flex flex-col items-center justify-center p-8 text-center animate-fade-in">
              <div className="w-16 h-16 rounded-full bg-gold/10 border border-gold/30 flex items-center justify-center text-gold mb-4 animate-bounce">
                <Crown className="h-8 w-8" />
              </div>
              <h3 className="font-bebas text-3xl sm:text-4xl font-black text-white tracking-widest uppercase italic">
                {selectedSpec.toUpperCase()} PROGRAM <span className="text-gold">IS LOCK</span>
              </h3>
              <p className="text-neutral-400 text-xs max-w-md mt-2 leading-relaxed">
                Gain access to Captain Babatunde's tactical pull-up metrics, extreme stabilization core drills, and special operation cardio frameworks.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mt-6 w-full max-w-xs">
                <Link
                  to="/pricing"
                  className="bg-gold text-black font-black uppercase text-xs tracking-widest py-3 px-6 rounded-sm hover:brightness-110 shadow-lg shadow-gold/25 text-center flex items-center justify-center gap-2"
                >
                  <span>Go Premium Now</span>
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <Link
                  to="/auth/signup"
                  className="border border-white/10 hover:bg-white/5 text-xs font-bold uppercase tracking-widest py-3 px-6 text-white text-center rounded"
                >
                  Start Free Trial
                </Link>
              </div>
              <p className="text-[9px] uppercase tracking-widest text-neutral-500 mt-4 font-mono">Secure payment verification via SSL</p>
            </div>
          ) : null}

          {/* Table contents visible for Premium or Push tab */}
          <div>
            <div className="absolute top-4 right-6 text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest bg-amber-500/10 border border-amber-500/25 px-2 py-0.5 rounded">
              {calisthenicsPrograms[selectedSpec].rounds}
            </div>
            
            <div className="flex items-center space-x-2.5 mb-8">
              <Shield className="h-5 w-5 text-amber-500" />
              <h2 className="font-bebas text-2xl sm:text-3xl font-bold tracking-wider text-white">
                {calisthenicsPrograms[selectedSpec].title}
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {calisthenicsPrograms[selectedSpec].exercises.map((item, i) => (
                <div key={i} className="bg-black border border-neutral-900 p-5 rounded hover:border-neutral-800 transition-all flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-bebas text-lg font-bold text-white tracking-widest">{item.name}</h4>
                      <span className="text-xs bg-amber-500/20 text-amber-500 font-bold px-2.5 py-0.5 rounded font-mono">{item.specs}</span>
                    </div>
                    <p className="text-xs text-neutral-400 leading-relaxed font-light mb-4">
                      {item.sub}
                    </p>
                    {item.gif && (
                      <div className="w-full bg-black/60 border border-white/5 rounded-lg overflow-hidden flex items-center justify-center p-2 mt-2">
                        <img 
                          src={getMediaProxyUrl(item.gif)} 
                          alt={item.name} 
                          referrerPolicy="no-referrer"
                          className="max-h-40 max-w-full object-contain rounded brightness-90 hover:brightness-100 transition-all duration-350" 
                        />
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Tactical standard limits */}
        <div className="border border-neutral-900 bg-neutral-950 rounded p-6 max-w-4xl mx-auto">
          <h4 className="font-bebas text-lg font-bold text-white tracking-wider mb-4 uppercase">CAPTAIN BABATUNDE'S ELITE BENCHMARKS</h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center text-xs">
            <div className="p-4 border border-neutral-900 bg-black rounded">
              <p className="text-neutral-500 uppercase font-bold text-[10px] tracking-wider mb-1">PUSHUP SCORE</p>
              <p className="font-bebas text-2xl font-bold text-amber-500 tracking-widest">75 consecutive</p>
              <p className="text-[10px] text-neutral-400 mt-1">completed under 2 mins</p>
            </div>
            <div className="p-4 border border-neutral-900 bg-black rounded">
              <p className="text-neutral-500 uppercase font-bold text-[10px] tracking-wider mb-1">PULLUP SCORE</p>
              <p className="font-bebas text-2xl font-bold text-amber-500 tracking-widest">20 dead-hangs</p>
              <p className="text-[10px] text-neutral-400 mt-1">Full control, zero swing</p>
            </div>
            <div className="p-4 border border-neutral-900 bg-black rounded">
              <p className="text-neutral-500 uppercase font-bold text-[10px] tracking-wider mb-1">SITUP SCORE</p>
              <p className="font-bebas text-2xl font-bold text-amber-500 tracking-widest">100 consecutive</p>
              <p className="text-[10px] text-neutral-400 mt-1">Under strict military rules</p>
            </div>
          </div>
        </div>

        {/* Centralized database prompt */}
        <div className="bg-neutral-950/80 border border-neutral-900 rounded-lg p-8 max-w-4xl mx-auto mt-12 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl"></div>
          <span className="text-amber-500 uppercase text-[10px] font-black tracking-widest font-mono">Centralized Athletic Database</span>
          <h3 className="font-bebas text-2xl sm:text-3xl font-extrabold text-white uppercase italic mt-1">Want to browse thousands of certified workouts?</h3>
          <p className="text-xs text-neutral-400 max-w-xl mx-auto mt-2 leading-relaxed">
            Gain full access to our massive exercise database. Customize sets, reps, and target tempos based on your exact fitness goal.
          </p>
          <div className="mt-5">
            <Link
              to="/workouts"
              className="inline-flex items-center gap-2 bg-amber-500 text-black font-extrabold text-xs uppercase tracking-widest py-3 px-6 rounded-sm hover:brightness-110 shadow-lg shadow-amber-500/10 transition-all font-mono"
            >
              <span>Explore Massive Exercise Library 📖</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
