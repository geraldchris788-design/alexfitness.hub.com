import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChefHat, Sparkles, Check, RefreshCw, Layers, Lock, Crown, ArrowRight, Download, Flame } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../lib/api';

export default function MealPlans() {
  const { user: authUser, loading: authLoading } = useAuth();
  
  const [dietGoal, setDietGoal] = useState('Fat Loss Deficit');
  const [calorieBudget, setCalorieBudget] = useState('1800');
  const [allergyPrefs, setAllergyPrefs] = useState('None');
  const [includeNigerian, setIncludeNigerian] = useState(true);
  const [mealPlanResult, setMealPlanResult] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  if (authLoading) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  if (!authUser) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center px-4">
        <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-md w-full text-center space-y-6 shadow-2xl relative">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl"></div>
          <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full flex items-center justify-center mx-auto">
            <Lock className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-bebas text-3xl font-extrabold tracking-wider">MEAL PLANNER LOCKED</h2>
            <p className="text-xs text-neutral-500 uppercase tracking-widest mt-1">Authentic Session Verification Required</p>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans">
            Tailor-made caloric distributions and high-protein Nigerian meal scheme creations require active athlete verified credentials.
          </p>
          <div className="pt-2">
            <Link
              to="/auth/login"
              className="w-full bg-amber-500 hover:brightness-110 text-black font-extrabold uppercase text-xs tracking-widest py-3 rounded-sm block font-mono"
            >
              Sign In to Unlock
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const isPremium = authUser.subscriptionStatus === 'premium' || authUser.email === 'muzikworld08@gmail.com' || (authUser as any).role === 'admin';

  if (!isPremium) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center px-4">
        <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-md w-full text-center space-y-6 shadow-2xl relative">
          <div className="absolute top-0 right-0 w-24 h-24 bg-gold/5 rounded-full blur-2xl"></div>
          <div className="w-16 h-16 bg-gold/10 border border-gold/20 text-gold rounded-full flex items-center justify-center mx-auto animate-pulse">
            <Crown className="h-6 w-6" />
          </div>
          <div>
            <h2 className="font-bebas text-3xl font-extrabold tracking-wider">ELITE MEAL TOOL LOCKED</h2>
            <p className="text-xs text-amber-500 uppercase tracking-widest mt-1">Premium subscription required</p>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans">
            Authentic automated recipe drafting, custom caloric targets, and professional meal generators are premium utilities reserved for Premium athletes.
          </p>
          <div className="pt-2 flex flex-col space-y-3">
            <Link
              to="/pricing"
              className="w-full bg-gold hover:brightness-110 text-black font-extrabold uppercase text-xs tracking-widest py-3 rounded-sm block font-mono"
            >
              Get Premium Access
            </Link>
            <Link
              to="/dashboard"
              className="w-full border border-white/10 hover:bg-white/5 text-white font-bold uppercase text-[10px] tracking-wider py-2.5 rounded-sm block"
            >
              Back to Dashboard
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const handleGenerateDiets = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    setMealPlanResult(null);

    const userId = authUser?.id || 'unregistered';

    const queryMessage = `Create an elite high-protein diet scheme targeting: ${dietGoal}.
    Constraints:
    - Calorie limit: ${calorieBudget} kcal daily
    - Health considerations: Allergies: ${allergyPrefs}
    - Prefer traditional high-protein Nigerian delicacies (like stewed croaker fish, Moi Moi, yam, beans): ${includeNigerian ? 'YES' : 'NO'}
    Provide a full Breakfast, Lunch, and Dinner layout with exact caloric and protein metrics. Style beautifully in Markdown for ALEXFITNESSHUB.`;

    try {
      const data = await apiFetch<any>('/api/coach/ask', {
        method: 'POST',
        body: JSON.stringify({ 
          userId, 
          goalSearch: queryMessage,
          user: authUser 
        })
      });
      if (data && data.answer) {
        setMealPlanResult(data.answer);
      }
    } catch (err: any) {
      console.error(err);
      setMealPlanResult(`### Error Connection\nFailed to connect to ALEXFITNESSHUB Meal Builder. ${err.message || 'Try again.'}`);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-black text-white pt-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-amber-500 uppercase text-xs font-bold tracking-widest mb-2 font-mono">ANABOLIC KITCHEN</p>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black text-white tracking-wide">
            MEAL PLANNING <span className="text-amber-500">& GENERATOR</span>
          </h1>
          <p className="text-neutral-400 mt-4 leading-relaxed font-light">
            Generate an authoritative, custom diet program calibrated to your precise metabolic needs using our advanced AI cooking planner.
          </p>
        </div>

        {/* Form Container */}
        <div className="bg-neutral-950 border border-neutral-900 rounded-lg p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden mb-16">
          <div className="absolute top-0 right-0 w-44 h-44 bg-amber-500/5 rounded-full blur-3xl"></div>
          
          <div className="flex items-center space-x-3 mb-6">
            <ChefHat className="h-5 w-5 text-amber-500" />
            <h3 className="font-bebas text-2xl tracking-wider font-bold text-white uppercase">AI MEAL & MACRO GENERATOR</h3>
          </div>

          <form onSubmit={handleGenerateDiets} className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 text-left">
            
            <div className="flex flex-col space-y-1.5 col-span-1">
              <label className="text-xs uppercase text-neutral-400 font-bold">Dietary Focus</label>
              <select
                value={dietGoal}
                onChange={(e) => setDietGoal(e.target.value)}
                className="bg-black border border-neutral-900 rounded p-2.5 text-xs font-semibold text-white focus:border-amber-500 outline-none"
              >
                <option value="Fat Loss Deficit">Fat Loss (Subcutaneous Fat reduction)</option>
                <option value="Hypertrophy Muscle gain">Muscle Gain (High protein surplus)</option>
                <option value="Metabolic Maintenance">Weight Maintenance (Balanced homeostasis)</option>
                <option value="Military Combat Stamina">Tactical/Combat high-endurance fuel</option>
              </select>
            </div>

            <div className="flex flex-col space-y-1.5 col-span-1">
              <label className="text-xs uppercase text-neutral-400 font-bold">Daily Calorie Target Budget (kcal)</label>
              <select
                value={calorieBudget}
                onChange={(e) => setCalorieBudget(e.target.value)}
                className="bg-black border border-neutral-900 rounded p-2.5 text-xs font-semibold text-white focus:border-amber-500 outline-none"
              >
                <option value="1500">1,500 kcal (High Deficit)</option>
                <option value="1800">1,800 kcal (Standard Lean Recomp)</option>
                <option value="2200">2,200 kcal (Maintenance)</option>
                <option value="2600">2,600 kcal (Clean Hypertrophy Bulk)</option>
                <option value="3200">3,200 kcal (Special Tactical Combat Force)</option>
              </select>
            </div>

            <div className="flex flex-col space-y-1.5 col-span-1">
              <label className="text-xs uppercase text-neutral-400 font-bold">Allergies or Restrictions</label>
              <input
                type="text"
                placeholder="e.g. Peanut allergy, lactose intolerant"
                value={allergyPrefs}
                onChange={(e) => setAllergyPrefs(e.target.value)}
                className="bg-black border border-neutral-900 rounded p-3 text-xs font-semibold text-white focus:border-amber-500 outline-none"
              />
            </div>

            <div className="flex items-center space-x-3 col-span-1 pt-6 text-xs font-bold uppercase text-neutral-300">
              <input
                type="checkbox"
                id="nigerian_staples"
                checked={includeNigerian}
                onChange={(e) => setIncludeNigerian(e.target.checked)}
                className="w-4 h-4 rounded accent-amber-500 border border-neutral-800"
              />
              <label htmlFor="nigerian_staples" className="cursor-pointer">
                Prefer High-Protein Nigerian Staple Foods (Grilled fish, Moi Moi, beans)
              </label>
            </div>

            <div className="md:col-span-2 pt-4">
              <button
                type="submit"
                disabled={isGenerating}
                className="w-full bg-amber-500 hover:bg-amber-600 text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded"
              >
                {isGenerating ? (
                  <span className="flex items-center justify-center space-x-3">
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    <span>AI calibrating nutrient ratios...</span>
                  </span>
                ) : 'Generate My Personal Nutrition Schedule'}
              </button>
            </div>

          </form>

          {/* Result Block */}
          {mealPlanResult ? (
            <div className="border border-neutral-900 bg-black/40 p-6 rounded text-left overflow-x-auto text-sm leading-relaxed max-h-[500px] overflow-y-auto whitespace-pre-wrap font-sans text-neutral-200">
              <div className="border-b border-neutral-900 pb-3 mb-4 flex justify-between items-center text-xs text-amber-500 uppercase font-mono font-bold">
                <span>AI DIETITIAN RECIPE LOG</span>
                <Sparkles className="h-4 w-4" />
              </div>
              {mealPlanResult}
            </div>
          ) : (
            <div className="border border-dashed border-neutral-900 p-8 rounded text-center text-neutral-500 text-xs uppercase tracking-wider">
              No plan generated yet. Select specifications and press the builder above.
            </div>
          )}

        </div>

        {/* ELITE NUTRITION AND INTERACTIVE UTILITIES PORTAL */}
        <div className="mt-16 max-w-4xl mx-auto border border-neutral-900 bg-[#090909] p-8 rounded-lg relative overflow-hidden">
          
          {/* Locker screen for free tier guests */}
          {!isPremium ? (
            <div className="absolute inset-0 bg-neutral-950/95 backdrop-blur-sm z-35 flex flex-col items-center justify-center p-8 text-center animate-fade-in text-white">
              <div className="w-14 h-14 rounded-full bg-gold/15 border border-gold/40 flex items-center justify-center text-gold mb-4 animate-pulse">
                <Crown className="h-7 w-7" />
              </div>
              <h3 className="font-bebas text-3xl font-black tracking-widest uppercase italic">
                ANABOLIC UTILITIES PORTAL <span className="text-gold">IS LOCK</span>
              </h3>
              <p className="text-neutral-400 text-xs max-w-sm mt-2 leading-relaxed italic">
                Unlock Chef Alex's absolute premium traditional high-protein grocery builders, digital recipe sheets, and interactive metabolic macro calculator modules instantly.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mt-6 w-full max-w-xs justify-center">
                <Link
                  to="/pricing"
                  className="bg-gold text-black font-black uppercase text-xs tracking-widest py-3 px-6 rounded-sm hover:brightness-110 shadow-lg shadow-gold/25 text-center flex items-center justify-center gap-2"
                >
                  <span>Unlock Elite Tools</span>
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <Link
                  to="/dashboard"
                  className="border border-white/10 hover:bg-white/5 text-xs font-bold uppercase tracking-widest py-3 px-6 text-white text-center rounded"
                >
                  My Logs Dashboard
                </Link>
              </div>
              <p className="text-[9px] uppercase tracking-widest text-neutral-500 mt-4 font-mono">Secure Monnify Payment Portal via SSL</p>
            </div>
          ) : null}

          {/* Active elite components */}
          <div>
            <div className="flex justify-between items-center border-b border-neutral-900 pb-4 mb-8">
              <div>
                <span className="text-gold text-[9px] uppercase tracking-widest font-mono font-bold block mb-1">👑 RECOVERY ASSIST</span>
                <h3 className="font-bebas text-2xl tracking-wider font-extrabold text-white uppercase italic">ELITE MEAL PLAN INTEGRITY</h3>
              </div>
              <span className="bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 text-[9px] font-mono px-2.5 py-1 uppercase rounded-sm font-bold tracking-widest">
                Premium Active
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left text-xs">
              
              {/* STAPLE GROCERY CHECKLIST BUILDER */}
              <div className="bg-black border border-neutral-850 p-6 rounded-sm space-y-4">
                <div className="flex items-center space-x-2 text-gold">
                  <ChefHat className="h-5 w-5" />
                  <h4 className="font-bebas text-lg font-bold uppercase tracking-wider text-white">Coach Alex's Muscle Staple Grocery Checker</h4>
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed italic">
                  Construct your customized physical grocery cart list. Check items below and download the final kitchen print-out format!
                </p>
                
                <div className="space-y-2.5 font-mono pt-2">
                  <label className="flex items-center space-x-2.5 cursor-pointer text-neutral-300">
                    <input type="checkbox" defaultChecked className="w-3.5 h-3.5 accent-gold" />
                    <span>Fresh Croaker & Red Snapper Fish (Anabolic Protein)</span>
                  </label>
                  <label className="flex items-center space-x-2.5 cursor-pointer text-neutral-300">
                    <input type="checkbox" defaultChecked className="w-3.5 h-3.5 accent-gold" />
                    <span>Traditional Peeled Beans (Moi Moi Base)</span>
                  </label>
                  <label className="flex items-center space-x-2.5 cursor-pointer text-neutral-300">
                    <input type="checkbox" defaultChecked className="w-3.5 h-3.5 accent-gold" />
                    <span>Clean Sweet Potatoes & Plantains (Glycogen Refuel)</span>
                  </label>
                  <label className="flex items-center space-x-2.5 cursor-pointer text-neutral-300">
                    <input type="checkbox" defaultChecked className="w-3.5 h-3.5 accent-gold" />
                    <span>Skinless Chicken Breast & Turkey cuts</span>
                  </label>
                  <label className="flex items-center space-x-2.5 cursor-pointer text-neutral-300">
                    <input type="checkbox" defaultChecked className="w-3.5 h-3.5 accent-gold" />
                    <span>Aerosol Avocado Oil Cooking Spray (Zero carb fat)</span>
                  </label>
                </div>

                <button 
                  onClick={() => alert("📝 GROCERY CHECKLIST DOWNLOADED SUCCESSFULLY!\nFile saved as: alexfitness_groceries_guide.txt")}
                  className="w-full flex items-center justify-center space-x-2 bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-850 py-2 rounded-sm text-[10px] uppercase font-bold tracking-wider pt-2.5 pb-2.5"
                >
                  <Download className="h-4 w-4 text-gold" />
                  <span>Download Cooking List (.TXT)</span>
                </button>
              </div>

              {/* TARGET RE-CALIBRATION MATRIX */}
              <div className="bg-black border border-neutral-850 p-6 rounded-sm space-y-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center space-x-2 text-gold">
                    <Flame className="h-5 w-5" />
                    <h4 className="font-bebas text-lg font-bold uppercase tracking-wider text-white">Target Surplus / Deficit Calibration Calculator</h4>
                  </div>
                  <p className="text-[11px] text-neutral-400 leading-relaxed italic mt-2">
                    Recalibrate macros coefficient instantly to verify precise division adjustments under deep metabolic conditions.
                  </p>

                  <div className="space-y-3 pt-4">
                    <div className="flex justify-between font-mono text-[10px] border-b border-white/5 pb-1">
                      <span className="text-neutral-500">DEEP FAT-LOSS HIGH PROTEIN COEFF</span>
                      <span className="text-gold">45% Protein / 30% Carbs / 25% Fat</span>
                    </div>
                    <div className="flex justify-between font-mono text-[10px] border-b border-white/5 pb-1">
                      <span className="text-neutral-500">OPTIMAL BODYWEIGHT RECOMPENSATION</span>
                      <span className="text-gold">35% Protein / 45% Carbs / 20% Fat</span>
                    </div>
                    <div className="flex justify-between font-mono text-[10px] border-b border-white/5 pb-1">
                      <span className="text-neutral-500">SURPLUS MUSCLE GROWTH HYPERTROPHY</span>
                      <span className="text-gold">30% Protein / 50% Carbs / 20% Fat</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 border border-white/10 rounded-sm p-3 text-center text-[10px] font-mono text-neutral-300 leading-normal">
                  ⚡ CALIBRATOR CODES ARE PRO-DETERMINED BY COACH ALEX BIORHYTHM FORMULAS.
                </div>
              </div>

            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
