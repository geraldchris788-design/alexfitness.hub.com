import React, { useEffect, useState } from 'react';
import { useSearchParams, Link, useNavigate } from 'react-router-dom';
import { ShieldCheck, ShieldAlert, RefreshCw, LogIn, ArrowLeft, Mail, Sparkles } from 'lucide-react';
import { applyActionCode } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { apiFetch } from '../lib/api';

export default function VerifyEmail() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get('token');
  const email = searchParams.get('email');
  const mode = searchParams.get('mode');
  const oobCode = searchParams.get('oobCode');

  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('');
  const [isResending, setIsResending] = useState(false);
  const [resendSuccess, setResendSuccess] = useState(false);

  useEffect(() => {
    const verifyToken = async () => {
      // 1. Firebase Native Action Verification Handler
      if (mode === 'verifyEmail' && oobCode) {
        try {
          await applyActionCode(auth, oobCode);
          setStatus('success');
          setMessage('Your email address has been successfully verified. Your account is now fully active.');
          
          if (email) {
            try {
              await apiFetch('/api/auth/send-welcome-email', {
                method: 'POST',
                body: JSON.stringify({ email })
              });
            } catch (welcomeErr) {
              console.warn("[VERIFY EMAIL] Welcome email dispatch failed:", welcomeErr);
            }
          }
        } catch (err: any) {
          console.error("[FIREBASE VERIFICATION ERROR]:", err);
          setStatus('error');
          setMessage(err.message || 'The verification link is invalid, has already been used, or has expired.');
        }
        return;
      }

      // 2. Fallback relative parameters validation
      if (!token || !email) {
        setStatus('error');
        setMessage('Missing verification details. Please click the link in your email.');
        return;
      }

      try {
        const data = await apiFetch<any>(`/api/auth/verify?token=${encodeURIComponent(token)}&email=${encodeURIComponent(email)}`);

        if (data && data.success) {
          setStatus('success');
          setMessage(data.message || 'Your email address has been successfully verified. You are now ready to log in and start your fitness journey.');
        } else {
          setStatus('error');
          setMessage(data?.error || 'The verification link is invalid, has already been used, or has expired.');
        }
      } catch (err: any) {
        console.error("Verification connection error:", err);
        setStatus('error');
        setMessage(err.message || 'The verification request timed out. Please check your network connection and try again.');
      }
    };

    verifyToken();
  }, [token, email, mode, oobCode]);

  const handleResend = async () => {
    if (!email) return;
    setIsResending(true);
    setResendSuccess(false);
    setMessage('');

    try {
      const data = await apiFetch<any>('/api/auth/resend-verification', {
        method: 'POST',
        body: JSON.stringify({ email })
      });

      if (data && data.success) {
        setResendSuccess(true);
        setStatus('error'); // Keep error state but show resend message
        setMessage('📬 A new verification link has been sent to your email!');
      } else {
        setMessage(data?.error || 'Failed to resend. Please wait a minute and retry.');
      }
    } catch (err: any) {
      setMessage(err.message || 'Failed to resend. Please wait a minute and retry.');
      console.error(err);
      setMessage('Our email service is temporarily unavailable. Could not resend.');
    } finally {
      setIsResending(false);
    }
  };

  return (
    <div id="verify-email-viewport" className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
      {/* Cinematic Background Lighting */}
      <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-[125px] pointer-events-none"></div>

      <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 sm:p-10 max-w-lg w-full text-center space-y-8 shadow-2xl relative z-10 transition-all duration-300">
        
        {/* Animated Icon Section */}
        <div className="flex justify-center">
          {status === 'loading' && (
            <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full flex items-center justify-center animate-spin">
              <RefreshCw className="h-6 w-6" />
            </div>
          )}

          {status === 'success' && (
            <div className="relative">
              <div className="absolute inset-0 bg-emerald-500/20 rounded-full blur-md animate-ping"></div>
              <div className="relative w-16 h-16 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-full flex items-center justify-center">
                <ShieldCheck className="h-7 w-7" />
              </div>
            </div>
          )}

          {status === 'error' && (
            <div className="w-16 h-16 bg-rose-500/10 border border-rose-500/30 text-rose-500 rounded-full flex items-center justify-center">
              <ShieldAlert className="h-7 w-7" />
            </div>
          )}
        </div>

        {/* Text Headers */}
        <div>
          <div className="inline-flex items-center gap-1 bg-amber-500/5 border border-amber-500/10 px-2 py-0.5 rounded-full mb-3">
            <Sparkles className="h-3 w-3 text-amber-500" />
            <span className="text-[9px] font-mono font-bold tracking-widest text-amber-500 uppercase">
              ALEXFITNESSHUB ACCOUNT VERIFICATION
            </span>
          </div>
          
          {status === 'loading' && (
            <>
              <h2 className="font-syne text-2xl sm:text-3xl font-extrabold tracking-wide uppercase">Verifying Your Account</h2>
              <p className="text-[10px] text-amber-500 font-mono tracking-widest mt-1.5 uppercase font-medium">ESTABLISHING SECURE CONNECTION</p>
            </>
          )}

          {status === 'success' && (
            <>
              <h2 className="font-syne text-2xl sm:text-3xl font-extrabold tracking-wide uppercase text-white [.light_&]:text-neutral-900">ACCOUNT VERIFIED</h2>
              <p className="text-[10px] text-emerald-400 font-mono tracking-widest mt-1.5 uppercase font-medium">VERIFICATION SUCCESSFUL</p>
            </>
          )}

          {status === 'error' && (
            <>
              <h2 className="font-syne text-2xl sm:text-3xl font-extrabold tracking-wide uppercase">VERIFICATION LINK PATTERN INVALID</h2>
              <p className="text-[10px] text-rose-500 font-mono tracking-widest mt-1.5 uppercase font-medium">VALIDATION REJECTED</p>
            </>
          )}
        </div>

        {/* Message body */}
        <p className="text-xs text-neutral-400 [.light_&]:text-neutral-600 leading-relaxed font-sans font-light max-w-sm mx-auto">
          {message}
        </p>

        {/* Action Button Section with full error handle details */}
        <div className="pt-2 flex flex-col gap-3">
          {status === 'success' && (
            <Link
              to="/auth/login"
              className="w-full bg-amber-500 hover:bg-gold hover:scale-[1.01] text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded-sm block transition-all font-mono"
            >
              🚀 Continue to Login Portal
            </Link>
          )}

          {status === 'error' && (
            <>
              {email && (
                <button
                  onClick={handleResend}
                  disabled={isResending}
                  className="w-full bg-amber-500 hover:bg-gold hover:scale-[1.01] text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded-sm flex items-center justify-center space-x-2 transition-all font-mono disabled:opacity-50 cursor-pointer"
                >
                  {isResending ? (
                    <RefreshCw className="h-4 w-4 animate-spin" />
                  ) : (
                    <Mail className="h-4 w-4" />
                  )}
                  <span>{isResending ? 'SENDING...' : 'RESEND VERIFICATION EMAIL'}</span>
                </button>
              )}

              <Link
                to="/auth/login"
                className="w-full bg-neutral-900 border border-neutral-850 hover:bg-neutral-850 text-white font-bold uppercase text-xs tracking-widest py-3 rounded-sm block transition-all font-mono"
              >
                Return to Login Portal
              </Link>
            </>
          )}

          {status === 'loading' && (
            <div className="text-center font-mono text-[10px] text-neutral-500 animate-pulse uppercase tracking-wider">
              Communicating with authorization servers...
            </div>
          )}
        </div>

        {/* Verification flow helper footer trace */}
        <div className="border-t border-neutral-900/60 pt-4 text-center text-[10px] text-neutral-500 font-mono">
          Progress: Sign Up → Confirm Email → Begin Journey
        </div>
        
      </div>
    </div>
  );
}
