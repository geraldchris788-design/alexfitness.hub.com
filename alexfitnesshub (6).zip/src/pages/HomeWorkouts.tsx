import React, { useState } from 'react';
import { Home, Flame, Star, Compass, Lock, Crown, ArrowRight, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getMediaProxyUrl } from '../lib/api';

export default function HomeWorkouts() {
  const { user: authUser, loading: authLoading } = useAuth();
  const [activeTier, setActiveTier] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate');
  const isPremium = authUser?.subscriptionStatus === 'premium' || authUser?.email === 'muzikworld08@gmail.com' || (authUser as any)?.role === 'admin';

  const routines = {
    beginner: [
      { name: 'Standard Push Ups', reps: '3 Sets x 8-10 Reps', rest: '90s rest', desc: 'Place hands slightly wider than shoulders. Maintain flat core line from head to heels.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/01/Push-Up.gif' },
      { name: 'Air Squats', reps: '3 Sets x 15 Reps', rest: '60s rest', desc: 'Sit down loading heels with chest upright. Excellent lower body bodyweight primer.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Squat.gif' },
      { name: 'Forearm Plank', reps: '3 Sets x 30s Hold', rest: '60s rest', desc: 'Squeeze glutes and abdominals. Prevent lower back from sagging.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/01/Plank.gif' },
      { name: 'Standing Alternate Lunges', reps: '3 Sets x 12 Steps', rest: '60s rest', desc: 'Step forward dropping trailing knee carefully. Maintains joint activation.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Bodyweight-Lunge.gif' }
    ],
    intermediate: [
      { name: 'Diamond Push Ups', reps: '4 Sets x 12 Reps', rest: '60s rest', desc: 'Create diamond index outline with thumbs and pointers. Excellent tricep and middle chest builder.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/10/Diamond-Push-up.gif' },
      { name: 'Jump squats', reps: '3 Sets x 15 Reps', rest: '90s rest', desc: 'Explode upward on the squat concentric phase. Absorptive land back into squat.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/05/Jump-Squat.gif' },
      { name: 'Mountain Climbers', reps: '3 Sets x 45 Seconds', rest: '45s rest', desc: 'High plank index. Speedily alternate knee drives into chest keeping hips low.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/05/Mountain-Climber.gif' },
      { name: 'Reverse Lunges', reps: '3 Sets x 15 Steps', rest: '60s rest', desc: 'Step backward dropping knee. Preserves knee tracking biomechanics.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/10/Reverse-Lunge.gif' }
    ],
    advanced: [
      { name: 'Archer Push Ups', reps: '4 Sets x 8 Reps per arm', rest: '90s rest', desc: 'Shift full torso weight left and right respectively, extending opposite arm fully out.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2022/01/Archer-Push-up.gif' },
      { name: 'Pistol Squats (Single Leg)', reps: '3 Sets x 5 Reps per leg', rest: '95s rest', desc: 'Drop one leg straight out in front and squat completely flat on single ankle support. Extreme balance.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/10/Single-Leg-Squat.gif' },
      { name: 'Burpee Tuck Jumps', reps: '4 Sets x 15 Reps', rest: '60s rest', desc: 'Perform standard burpee. On the vertical leap drop knees straight up into chest at peak height.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/05/Burpee.gif' },
      { name: 'RKC Plank (Extreme squeeze)', reps: '3 Sets x 45s Hold', rest: '60s rest', desc: 'Forearm setup. Actively pull elbows to toes, locking glutes and quads under 100% tension constraint.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/01/Plank.gif' }
    ]
  };

  if (authLoading) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin text-amber-500 font-bold" />
      </div>
    );
  }

  if (!isPremium) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex flex-col items-center justify-center px-4 relative overflow-hidden">
        {/* Cinematic Backdrop Pattern */}
        <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-[120px]"></div>
        
        <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-lg w-full text-center space-y-6 shadow-2xl relative z-10">
          <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full flex items-center justify-center mx-auto">
            <Lock className="h-6 w-6" />
          </div>
          <div>
            <h2 className="font-syne text-3xl font-extrabold tracking-wide uppercase">HOME WORKOUTS LOCKED</h2>
            <p className="text-[10px] text-amber-500 font-mono tracking-widest mt-1.5 uppercase">ATHLETE AUTHENTICATION & PREMIUM SUBSCRIPTION REQUIRED</p>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans font-light">
            Custom home workout routines across Beginner, Intermediate, and Advanced tiers are premium assets. Subscribe today to unlock complete bodyweight and resistance training matrices.
          </p>
          <div className="pt-2 flex flex-col gap-3">
            <Link
              to="/pricing"
              className="w-full bg-amber-500 hover:bg-gold hover:scale-[1.02] text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded-sm block transition-all font-mono"
            >
              Get Premium Access Now
            </Link>
            <Link
              to="/"
              className="w-full bg-neutral-900 border border-neutral-850 hover:bg-neutral-850 text-white font-bold uppercase text-xs tracking-widest py-3 rounded-sm block transition-all font-mono"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-black text-white pt-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-amber-500 uppercase text-xs font-bold tracking-widest mb-2 font-mono">BODY RESISTANCE</p>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black text-white tracking-wide">
            HOME TRAINING <span className="text-amber-500">TIERS</span>
          </h1>
          <p className="text-neutral-400 mt-4 leading-relaxed font-light">
            Zero equipment. Ultimate results. Choose your exact experience tier to analyze relative push, pull, leg, and conditioning layouts.
          </p>
        </div>

        {/* Tier Buttons */}
        <div className="grid grid-cols-3 max-w-2xl mx-auto gap-4 mb-16">
          {(['beginner', 'intermediate', 'advanced'] as const).map((tier) => (
            <button
              key={tier}
              onClick={() => setActiveTier(tier)}
              className={`py-3.5 rounded font-bebas text-lg uppercase tracking-wider transition-all border ${
                activeTier === tier
                  ? 'bg-amber-500 text-black border-amber-500 font-extrabold shadow-lg shadow-amber-500/10'
                  : 'bg-neutral-950 border-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              {tier} Setup
            </button>
          ))}
        </div>

        {/* Exercises mapping */}
        <div className="relative min-h-[300px] border border-neutral-900 rounded bg-[#090909] p-8 max-w-5xl mx-auto flex flex-col justify-center">
          
          {!isPremium && activeTier === 'advanced' ? (
            /* Premium Locker Screen */
            <div className="absolute inset-0 bg-black/95 backdrop-blur-sm z-30 flex flex-col items-center justify-center p-8 text-center animate-fade-in">
              <div className="w-16 h-16 rounded-full bg-gold/10 border border-gold/30 flex items-center justify-center text-gold mb-4 animate-bounce">
                <Crown className="h-8 w-8" />
              </div>
              <h3 className="font-bebas text-3xl sm:text-4xl font-black text-white tracking-widest uppercase italic">
                ADVANCED PROGRAM <span className="text-gold">IS LOCK</span>
              </h3>
              <p className="text-neutral-400 text-xs max-w-md mt-2 leading-relaxed">
                Unlock Coach Alex's high-intensity home program including Archer Push-ups, extreme Pistol squat biomechanics, and tactical RKC planks.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mt-6 w-full max-w-xs justify-center mx-auto">
                <Link
                  to="/pricing"
                  className="bg-gold text-black font-black uppercase text-xs tracking-widest py-3 px-6 rounded-sm hover:brightness-110 shadow-lg shadow-gold/25 text-center flex items-center justify-center gap-2"
                >
                  <span>Go Premium Now</span>
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <Link
                  to="/auth/signup"
                  className="border border-white/10 hover:bg-white/5 text-xs font-bold uppercase tracking-widest py-3 px-6 text-white text-center rounded"
                >
                  Start Free Trial
                </Link>
              </div>
              <p className="text-[9px] uppercase tracking-widest text-neutral-500 mt-4 font-mono">Secure payment verification via SSL</p>
            </div>
          ) : null}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {routines[activeTier].map((item, i) => (
              <div key={i} className="bg-neutral-950 border border-neutral-850 rounded p-6 hover:border-amber-500/10 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <div className="flex items-center space-x-2.5">
                      <Home className="h-4.5 w-4.5 text-amber-500" />
                      <h3 className="font-bebas text-xl sm:text-2xl font-bold tracking-wider text-white uppercase">{item.name}</h3>
                    </div>
                    <span className="text-[10px] bg-neutral-900 text-neutral-500 font-mono py-1 px-2 border border-neutral-850">
                      {activeTier.toUpperCase()}
                    </span>
                  </div>

                  <p className="text-xs text-neutral-450 leading-relaxed font-light mb-4">
                    {item.desc}
                  </p>
                  
                  {item.gif && (
                    <div className="w-full bg-black/60 border border-white/5 rounded-lg overflow-hidden flex items-center justify-center p-2 mb-4">
                      <img 
                        src={getMediaProxyUrl(item.gif)} 
                        alt={item.name} 
                        referrerPolicy="no-referrer"
                        className="max-h-48 max-w-full object-contain rounded brightness-90 hover:brightness-100 transition-all duration-300" 
                      />
                    </div>
                  )}
                </div>

                <div className="border-t border-neutral-900 pt-4 flex justify-between items-center text-xs text-neutral-500">
                  <span className="flex items-center space-x-1">
                    <Flame className="h-3.5 w-3.5 text-amber-500" />
                    <strong>VOLUME: {item.reps}</strong>
                  </span>
                  <span className="font-mono">{item.rest}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Centralized database prompt */}
        <div className="bg-neutral-950/80 border border-neutral-900 rounded-lg p-8 max-w-5xl mx-auto mt-12 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl"></div>
          <span className="text-amber-500 uppercase text-[10px] font-black tracking-widest font-mono">Centralized Athletic Database</span>
          <h3 className="font-bebas text-2xl sm:text-3xl font-extrabold text-white uppercase italic mt-1">Want to browse thousands of verified workouts?</h3>
          <p className="text-xs text-neutral-400 max-w-xl mx-auto mt-2 leading-relaxed">
            Gain full access to our massive exercise database. Customize sets, reps, and target tempos based on your exact fitness goal.
          </p>
          <div className="mt-5">
            <Link
              to="/workouts"
              className="inline-flex items-center gap-2 bg-amber-500 text-black font-extrabold text-xs uppercase tracking-widest py-3 px-6 rounded-sm hover:brightness-110 shadow-lg shadow-amber-500/10 transition-all font-mono"
            >
              <span>Explore Massive Exercise Library 📖</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
