import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, Sparkles, CreditCard, Zap, Calendar, HeartPulse, ShieldCheck, HelpCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../lib/api';

const BILLING_OPTIONS = [
  {
    id: 'monthly',
    name: '1-Month Premium Tracker',
    badge: '📅 STANDARD MONTHLY',
    amount: 20000,
    period: 'PER MONTH ACCESS',
    description: 'Continuous premium platform access billed month-to-month.'
  },
  {
    id: 'month_2',
    name: '2-Month Training Program',
    badge: '🔥 5% EXTRA COOPERATIVE',
    amount: 38040, // 40,000 - 5% = 38,000 (or close to 38,000)
    originalAmount: 40000,
    period: '2 MONTHS PERIOD',
    description: 'Perfect 8-week physical timeline for hypertrophy adaptations.'
  },
  {
    id: 'month_3',
    name: '3-Month Body Transformation',
    badge: '🔥 5% EXTRA COOPERATIVE',
    amount: 57000, // 60,000 - 5% = 57,000
    originalAmount: 60000,
    period: '3 MONTHS PERIOD',
    description: 'Full somatic coaching program for elite fat-loss and core strength.'
  },
  {
    id: 'month_4',
    name: '4-Month Tactical Conditioning',
    badge: '🔥 5% EXTRA COOPERATIVE',
    amount: 76000, // 80,000 - 5% = 76,000
    originalAmount: 80000,
    period: '4 MONTHS PERIOD',
    description: 'In-depth conditioning track for optimal metabolism levels.'
  },
  {
    id: 'month_5',
    name: '5-Month Strength Catalyst',
    badge: '🔥 5% EXTRA COOPERATIVE',
    amount: 95000, // 100,000 - 5% = 95,000
    originalAmount: 100000,
    period: '5 MONTHS PERIOD',
    description: 'Premium nitrogen balance and advanced lifting routines logs.'
  },
  {
    id: 'month_6',
    name: '6-Month Extreme Transformation',
    badge: '🔥 5% EXTRA COOPERATIVE',
    amount: 114000, // 120,000 - 5% = 114,000
    originalAmount: 120000,
    period: '6 MONTHS PERIOD',
    description: 'Standard athlete transformation time horizon with continuous tracker slots.'
  },
  {
    id: 'yearly',
    name: '1-Year Absolute Athlete Pass',
    badge: '👑 ULTRA ATHLETE (10% DISCOUNT)',
    amount: 216000, // 240,050 - 10% = 216,000
    originalAmount: 240000,
    period: 'PER YEAR BILLING',
    description: 'Full peak performance and absolute prioritized consulting logs.'
  }
];

export default function Pricing() {
  const navigate = useNavigate();
  const { user, refreshUser } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [selectedOptionId, setSelectedOptionId] = useState('monthly');
  const [selectedType, setSelectedType] = useState<'slider' | 'yearly'>('slider');
  const [sliderMonths, setSliderMonths] = useState(1);
  
  const [currentCheckout, setCurrentCheckout] = useState<{
    plan: string;
    amount: number;
    reference: string;
  } | null>(null);

  const activeOption = BILLING_OPTIONS.find(o => o.id === selectedOptionId) || BILLING_OPTIONS[0];
  
  const handleInitializePayment = async (plan: string, amount: number) => {
    if (!user) {
      alert("Please Sign Up or Login first to unlock ALEXFITNESSHUB premium programs!");
      navigate('/auth/signup');
      return;
    }

    setIsLoading(true);
    try {
      const data = await apiFetch<any>('/api/payment/initialize', {
        method: 'POST',
        body: JSON.stringify({
          userId: user.id,
          planType: plan,
          amount,
          email: user.email,
          customerName: user.name || 'Athlete Name'
        })
      });
      
      const { paymentReference, apiKey, contractCode } = data;
      const monnify = (window as any).MonnifySDK;

      if (monnify) {
        console.log("[MONNIFY] Launching Inline payment checkout flow...");
        monnify.initialize({
          amount: Number(amount),
          currency: "NGN",
          reference: paymentReference,
          customerName: user.name || 'Athlete Client',
          customerEmail: user.email,
          apiKey: apiKey || "MK_TEST_XXXXXXXXXX",
          contractCode: contractCode || "xxxxxxxxx",
          paymentDescription: `ALEXFITNESSHUB Premium Access: ${plan}`,
          onComplete: async function (response: any) {
            console.log("[MONNIFY COMPLETED]", response);
            setIsLoading(true);
            try {
              await apiFetch<any>('/api/payment/verify', {
                method: 'POST',
                body: JSON.stringify({
                  reference: paymentReference,
                  transactionReference: response.transactionReference || '',
                  userId: user.id,
                  planType: plan,
                  amount: amount,
                  paymentStatus: response.paymentStatus || 'PAID'
                })
              });
              await refreshUser();
              alert(`🎉 Premium access unlocked successfully! Welcome to ALEXFITNESSHUB.`);
              navigate('/dashboard');
            } catch (err: any) {
              console.error(err);
              alert("Verification complete. Confirming details inside your athlete dashboard panel...");
              navigate('/dashboard');
            } finally {
              setIsLoading(false);
            }
          },
          onClose: function (closeData: any) {
            console.log("[MONNIFY CLOSED]", closeData);
            if (closeData && closeData.paymentStatus === "USER_CANCELLED") {
              alert("Payment cancelled. Feel free to upgrade whenever you are ready to forge your physique!");
            } else {
              refreshUser().then(() => {
                navigate('/dashboard');
              });
            }
          },
          onError: function (error: any) {
            console.error("[MONNIFY ERROR]", error);
            alert("An error occurred during payment processing. Please crosscheck internet stability and card credentials.");
          }
        });
      } else {
        console.warn("[MONNIFY] SDK was not loaded. Activating robust interactive sandbox simulator modal fallback.");
        setCurrentCheckout({
          plan,
          amount,
          reference: paymentReference
        });
        setShowModal(true);
      }
    } catch (err: any) {
      console.error(err);
      alert(`Payment initialization failed: ${err.message || 'Check server connection'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyComplete = async () => {
    if (!currentCheckout || !user) return;
    
    setIsLoading(true);
    try {
      const data = await apiFetch<any>('/api/payment/verify', {
        method: 'POST',
        body: JSON.stringify({
          reference: currentCheckout.reference,
          userId: user.id,
          planType: currentCheckout.plan,
          amount: currentCheckout.amount
        })
      });
      
      if (data && data.success) {
        await refreshUser();
        setShowModal(false);
        alert(`🎉 Premium Unlocked! Welcome to ALEXFITNESSHUB.`);
        navigate('/dashboard');
      }
    } catch (err) {
      console.error(err);
      alert("Failed to confirm transaction.");
    } finally {
      setIsLoading(false);
    }
  };

  const premiumFeatures = [
    'Complete AI Fitness Coach Real-time consultation slots',
    'Custom Workout Generator powered by Google Gemini AI',
    'Interactive Nutrition Planner & Cook Guide generator model',
    'Full access to all 5 high-density Celebrity programs',
    'Unlock military calisthenics tactical tracks & stamina indexes',
    'Unrestricted logging of customized biometric values',
    'Post & track progress transformation pictures securely',
    'Personal daily calories & macros targeting computation charts'
  ];

  return (
    <div className="bg-black text-white pt-24 min-h-screen relative overflow-hidden">
      {/* High Density Radial Dot Grid Background Overlay */}
      <div className="absolute inset-0 bg-grid-pattern opacity-15"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 z-10">
        
        {/* Header content */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center space-x-2 bg-amber-500/10 border border-amber-500/20 px-4 py-1.5 rounded-full text-[10px] text-amber-500 font-bold uppercase mb-4 tracking-widest font-mono">
            <Sparkles className="h-3.5 w-3.5 animate-pulse text-amber-500" />
            <span>EXCLUSIVELY AUTHORIZED Billing System Integration</span>
          </div>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black text-white tracking-tighter uppercase italic leading-none">
            CHOOSE YOUR <span className="text-amber-500">PREMIUM ACCESS</span> PASS
          </h1>
          <p className="text-white/50 mt-4 leading-relaxed font-light text-sm italic max-w-2xl mx-auto">
            Upgrade your membership to gain unrestricted premium access to our AI Coach, custom progress galleries, tactical military workout courses, and macro calculations.
          </p>
        </div>

        {/* Master layout grid: Options left / Checkout card right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 max-w-6xl mx-auto items-start pt-4">
          
          {/* Options selector (Left side) */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <h4 className="text-[11px] font-black tracking-widest uppercase text-neutral-400 font-mono mb-2 flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-amber-500" />
              <span>Select Access Plan Package Duration</span>
            </h4>
            
            {/* 1. Custom Duration Plan Card with Slider */}
            <div 
              onClick={() => {
                setSelectedType('slider');
                const idMap = ['monthly', 'month_2', 'month_3', 'month_4', 'month_5', 'month_6'];
                setSelectedOptionId(idMap[sliderMonths - 1]);
              }}
              className={`p-6 sm:p-8 rounded-xl border transition-all cursor-pointer relative overflow-hidden space-y-6 ${
                selectedType === 'slider'
                  ? 'bg-amber-500/10 border-amber-500 ring-1 ring-amber-500/30'
                  : 'bg-neutral-950 hover:bg-neutral-900 border-white/5 opacity-60 hover:opacity-95'
              }`}
            >
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="space-y-1">
                  <span className={`text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-sm ${
                    selectedType === 'slider' ? 'bg-amber-500 text-black' : 'bg-neutral-800 text-neutral-450'
                  }`}>
                    📅 Custom Duration Program
                  </span>
                  <h3 className="text-xl sm:text-2xl font-bebas tracking-wide font-black uppercase text-white mt-2">
                    {selectedType === 'slider' ? activeOption.name : '1 to 6 Months Dynamic Pass'}
                  </h3>
                  <p className="text-xs text-neutral-400 font-sans leading-normal">
                    {selectedType === 'slider' ? activeOption.description : 'Select a customizable duration to fit your fitness program.'}
                  </p>
                </div>
                
                <div className="shrink-0 text-left sm:text-right">
                  <div className="text-2xl font-bebas font-black text-amber-500">
                    ₦{selectedType === 'slider' ? activeOption.amount.toLocaleString() : '20,000'}
                  </div>
                  {selectedType === 'slider' && activeOption.originalAmount && (
                    <div className="text-[10px] text-neutral-500 line-through font-mono">
                      Original ₦{activeOption.originalAmount.toLocaleString()}
                    </div>
                  )}
                  <div className="text-[10px] text-neutral-500 font-mono uppercase tracking-wider">
                    {selectedType === 'slider' ? activeOption.period : 'STARTING PRICE'}
                  </div>
                </div>
              </div>

              {/* Interactive Slider Section */}
              <div className="space-y-4 pt-4 border-t border-white/5" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-neutral-400 uppercase font-bold">DURATION SELECTOR</span>
                  <span className="text-amber-500 font-bold px-2 py-1 bg-amber-500/10 border border-amber-500/20 rounded-md">
                    {sliderMonths} {sliderMonths === 1 ? 'Month' : 'Months'} Access ({sliderMonths >= 2 ? '5% OFF' : 'Standard Rate'})
                  </span>
                </div>

                {/* Styled Slider range input */}
                <div className="relative pt-2 pb-2">
                  <input
                    type="range"
                    min="1"
                    max="6"
                    step="1"
                    value={sliderMonths}
                    onChange={(e) => {
                      const val = parseInt(e.target.value);
                      setSliderMonths(val);
                      setSelectedType('slider');
                      const idMap = ['monthly', 'month_2', 'month_3', 'month_4', 'month_5', 'month_6'];
                      setSelectedOptionId(idMap[val - 1]);
                    }}
                    className="w-full h-2 bg-neutral-900 rounded-lg appearance-none cursor-pointer accent-amber-500 outline-none border border-white/5 focus:ring-1 focus:ring-amber-500/50"
                  />
                  
                  {/* Slider notches */}
                  <div className="flex justify-between text-[11px] font-mono text-neutral-500 mt-3 px-1">
                    {[1, 2, 3, 4, 5, 6].map((num) => {
                      const isActive = sliderMonths === num && selectedType === 'slider';
                      return (
                        <button
                          key={num}
                          type="button"
                          onClick={() => {
                            setSliderMonths(num);
                            setSelectedType('slider');
                            const idMap = ['monthly', 'month_2', 'month_3', 'month_4', 'month_5', 'month_6'];
                            setSelectedOptionId(idMap[num - 1]);
                          }}
                          className={`flex flex-col items-center focus:outline-none transition-all ${
                            isActive ? 'text-amber-500 font-bold scale-105' : 'hover:text-neutral-300'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full mb-1 ${isActive ? 'bg-amber-500' : 'bg-neutral-800'}`} />
                          <span>{num} Month{num > 1 ? 's' : ''}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* 2. Yearly Subscription Plan Card - Separated */}
            <div 
              onClick={() => {
                setSelectedType('yearly');
                setSelectedOptionId('yearly');
              }}
              className={`p-6 sm:p-8 rounded-xl border transition-all cursor-pointer relative overflow-hidden flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 ${
                selectedType === 'yearly'
                  ? 'bg-amber-500/10 border-amber-500 ring-1 ring-amber-500/30'
                  : 'bg-neutral-950 hover:bg-neutral-900 border-white/5 opacity-60 hover:opacity-95'
              }`}
            >
              <div className="absolute top-0 right-0 bg-emerald-500 text-black text-[8px] font-bold uppercase px-3 py-1 font-mono rounded-bl tracking-widest">
                10% OFF APPLIED
              </div>
              
              <div className="space-y-2 text-left flex-1 select-none">
                <div className="flex items-center space-x-2">
                  <span className={`text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-sm ${
                    selectedType === 'yearly' ? 'bg-amber-500 text-black' : 'bg-neutral-800 text-neutral-450'
                  }`}>
                    👑 ULTRA ATHLETE PASS (ANNUAL)
                  </span>
                </div>
                <h3 className="text-xl sm:text-2xl font-bebas tracking-wide font-black uppercase text-white mt-1">
                  1-Year Absolute Athlete Pass
                </h3>
                <p className="text-xs text-neutral-400 font-sans leading-normal">
                  Full peak performance, priority direct coaching support, and absolute prioritize models consulting logs for 12 months.
                </p>
              </div>

              <div className="shrink-0 text-left sm:text-right">
                <div className="text-2xl font-bebas font-black text-amber-500">
                  ₦216,000
                </div>
                <div className="text-[10px] text-neutral-500 line-through font-mono uppercase">
                  Original ₦240,000
                </div>
                <p className="text-[8px] text-neutral-500 font-mono uppercase tracking-wider mt-0.5">
                  PER YEAR BILLING
                </p>
              </div>
            </div>
          </div>

          {/* Core Checkout Preview Card (Right side) */}
          <div className="lg:col-span-5">
            <div className="bg-neutral-950 border-2 border-amber-500 rounded-2xl p-6 sm:p-8 space-y-6 relative shadow-2xl">
              <div className="space-y-1.5 text-left border-b border-white/5 pb-4">
                <span className="text-[9px] font-bold uppercase text-amber-500 font-mono tracking-widest block">SECURED BILLING SUMMARY</span>
                <h3 className="font-bebas text-3xl font-black tracking-wider text-white uppercase italic">
                  {activeOption.name}
                </h3>
                <span className="text-[10px] text-neutral-450 uppercase font-mono tracking-widest block">
                  🚀 ACCESS STATUS: UNLOCKS THE ENTIRE WEBSITE
                </span>
              </div>

              {/* Display exact Selected Item Pricing */}
              <div className="bg-black/80 border border-white/5 p-4 rounded-lg flex items-center justify-between font-mono text-left">
                <div>
                  <span className="text-[9px] text-amber-500 uppercase font-bold tracking-widest block font-mono">YOU WILL BE BILLED</span>
                  <strong className="text-white text-3xl font-bebas font-black">
                    ₦{activeOption.amount.toLocaleString()}
                  </strong>
                </div>
                <div className="text-right">
                  <span className="bg-amber-500/10 text-amber-500 border border-amber-500/20 text-[9px] px-2.5 py-1 rounded-sm font-bold uppercase tracking-wider">
                    {activeOption.id === 'yearly' ? 'ANNUAL PASS' : 'MONTHLY PASS'}
                  </span>
                  <p className="text-[9px] text-neutral-400 mt-1 uppercase font-bold tracking-wider">
                    {activeOption.period}
                  </p>
                </div>
              </div>

              {/* Feature Checkmarks List */}
              <div className="space-y-3.5 text-left">
                <h5 className="text-[10px] uppercase font-mono font-bold text-neutral-400 tracking-wider">PREMIUM PRIVILEGES UNLOCKED:</h5>
                <ul className="space-y-2.5">
                  {premiumFeatures.map((feat, i) => (
                    <li key={i} className="flex items-start space-x-2 text-xs text-neutral-350">
                      <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Pay trigger */}
              <div className="pt-2">
                <button
                  disabled={isLoading}
                  onClick={() => handleInitializePayment(activeOption.name, activeOption.amount)}
                  className="w-full bg-amber-500 hover:bg-amber-600 disabled:bg-neutral-800 disabled:text-neutral-500 text-black font-black uppercase text-xs tracking-widest py-4 rounded-xl transition-all shadow-lg shadow-amber-500/10 cursor-pointer flex items-center justify-center space-x-2"
                >
                  <CreditCard className="h-4 w-4 text-black" />
                  <span>{isLoading ? 'Setting up gateway...' : `AUTHORIZED PAY NGN ${activeOption.amount.toLocaleString()}`}</span>
                </button>
                <div className="mt-3 flex items-center justify-center space-x-1 text-[8px] text-amber-500/80 font-mono uppercase tracking-widest font-bold">
                  <HeartPulse className="h-3 w-3 text-amber-500 animate-pulse" />
                  <span>Lifetime Physique Evolution Gateway SSL Secured</span>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>

      {/* MONNIFY CHECKOUT SIMULATED MODAL */}
      {showModal && currentCheckout && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 px-4 animate-fade-in relative">
          <div className="bg-neutral-950 border border-white/10 rounded-sm p-6 max-w-sm w-full space-y-6 z-50">
            
            {/* Monnify logo design */}
            <div className="text-center border-b border-white/10 pb-4">
              <div className="inline-flex items-center space-x-1.5 text-amber-500 bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-sm">
                <Zap className="h-4 w-4 animate-pulse" />
                <span className="text-[10px] uppercase font-black tracking-widest">MONNIFY PORTAL SECURE</span>
              </div>
              <h3 className="font-bebas text-xl text-white tracking-widest mt-2 uppercase italic font-bold">TRANSACT VERIFICATION</h3>
            </div>

            {/* Bill details */}
            <div className="space-y-2.5 text-xs font-mono text-left">
              <div className="flex justify-between text-neutral-400">
                <span>Paying To:</span>
                <span className="text-white font-bold">ALEXFITNESSHUB NIG LTD</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>Account Email:</span>
                <span className="text-white font-bold">{user?.email}</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>Plan Selection:</span>
                <span className="text-amber-500 uppercase font-bold truncate max-w-[180px]">{currentCheckout.plan}</span>
              </div>
              <div className="flex justify-between text-neutral-400 border-t border-white/10 pt-3 mt-2 font-bold">
                <span>Total Amount:</span>
                <span className="text-white text-lg font-bebas font-black">₦{currentCheckout.amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-neutral-550 truncate text-[9px] uppercase tracking-wider">
                <span>Log Ref:</span>
                <span className="text-neutral-400">{currentCheckout.reference}</span>
              </div>
            </div>

            {/* Gateway actions */}
            <div className="space-y-2.5 pt-2">
              <button
                onClick={handleVerifyComplete}
                className="w-full flex items-center justify-center space-x-2 bg-emerald-500 hover:bg-emerald-600 text-black font-black uppercase text-xs tracking-widest py-3.5 rounded-sm cursor-pointer"
              >
                <CreditCard className="h-4 w-4" />
                <span>Authorize Secure Payment</span>
              </button>
              <button
                onClick={() => setShowModal(false)}
                className="w-full bg-[#111111] hover:bg-neutral-900 text-neutral-400 text-xs uppercase tracking-widest py-2.5 rounded-sm border border-white/5 cursor-pointer"
              >
                Cancel Billing
              </button>
            </div>

            <p className="text-[9px] text-neutral-500 text-center uppercase tracking-widest leading-normal font-mono">
              Authorized secure checkout gateway. Verifies automatically with 256-bit transactional SSL encryption & immediate webhook logs.
            </p>

          </div>
        </div>
      )}

    </div>
  );
}

