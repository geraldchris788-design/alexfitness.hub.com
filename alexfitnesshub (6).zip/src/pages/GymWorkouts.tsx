import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Dumbbell, Target, ChevronRight, Lock, RefreshCw } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { getMediaProxyUrl } from '../lib/api';

interface GymExerciseDetail {
  name: string;
  target: string;
  tip: string;
  gif: string;
  sets: string;
  reps: string;
  equipment: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
}

export default function GymWorkouts() {
  const { user: authUser, loading: authLoading } = useAuth();
  const isPremium = authUser?.subscriptionStatus === 'premium' || authUser?.email === 'muzikworld08@gmail.com' || (authUser as any)?.role === 'admin';
  const [activeCategory, setActiveCategory] = useState<'chest' | 'back' | 'legs' | 'shoulders' | 'arms' | 'core'>('chest');
  const [searchQuery, setSearchQuery] = useState('');
  const [difficultyFilter, setDifficultyFilter] = useState<'all' | 'Beginner' | 'Intermediate' | 'Advanced'>('all');

  const gymDatabase: Record<'chest' | 'back' | 'legs' | 'shoulders' | 'arms' | 'core', GymExerciseDetail[]> = {
    chest: [
      {
        name: 'Barbell Bench Press',
        target: 'Pectoralis Major (Mid & Lower Chest), Triceps Brachii, Anterior Deltoids',
        tip: 'Keep your shoulder blades retracted, your foot heels driven flat into the floor, and lower the bar slowly under control to touch your mid-sternum.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Barbell-Bench-Press.gif',
        sets: '3 - 4 Sets',
        reps: '8 - 12 Reps',
        equipment: 'Barbell',
        difficulty: 'Intermediate'
      },
      {
        name: 'Incline Dumbbell Press',
        target: 'Clavicular Head of Pectoralis Major (Upper Chest), Front Deltoids',
        tip: 'Set incline bench to 30-45 degrees. Lift dumbbells in a strong, steady arc, pressing upward and inward without clanking the weights at peak height.',
        gif: 'https://i.pinimg.com/originals/be/94/3f/be943f55c4a35f5599824db11168d686.gif',
        sets: '3 - 4 Sets',
        reps: '8 - 12 Reps',
        equipment: 'Dumbbells',
        difficulty: 'Intermediate'
      },
      {
        name: 'Decline Barbell Bench Press',
        target: 'Lower Sternal Pectoralis Major, Triceps Brachii, Front Deltoids',
        tip: 'Secure your legs firmly under the bench pads. Secure a slightly wider than shoulder grip, lower the bar smoothly to your lower chest, and press up.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/03/Decline-Barbell-Bench-Press.gif',
        sets: '3 Sets',
        reps: '10 - 12 Reps',
        equipment: 'Barbell',
        difficulty: 'Advanced'
      },
      {
        name: 'Pec Dec Machine Fly',
        target: 'Sternal Fibers of Pectoralis Major (Inner Chest Separation)',
        tip: 'Sit tall, pressing your back tight against the back pad. Sweep your arms together in a broad, fluid arc, and focus entirely on squeezing your chest.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Pec-Deck-Fly.gif',
        sets: '3 - 4 Sets',
        reps: '12 - 15 Reps',
        equipment: 'Machine',
        difficulty: 'Beginner'
      },
      {
        name: 'Dumbbell Chest Fly',
        target: 'Pectoralis Major (Outer Chest Stretch & Squeeze)',
        tip: 'Maintain a soft 15-degree angle in your elbows. Stretch wide slowly until you feel your chest open, then contract upwards with a controlled hug motion.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Dumbbell-Fly.gif',
        sets: '3 Sets',
        reps: '12 - 15 Reps',
        equipment: 'Dumbbells',
        difficulty: 'Intermediate'
      },
      {
        name: 'Chest Dip',
        target: 'Lower Pectoralis fibers, Triceps, Anterior Deltoids',
        tip: 'Lean your chest forward at roughly 30 degrees to bias the chest fibers. Lower yourself until your shoulders stretch slightly, then press upward with chest power.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/06/Chest-Dip.gif',
        sets: '3 Sets',
        reps: '8 - 15 Reps',
        equipment: 'Bodyweight',
        difficulty: 'Advanced'
      }
    ],
    back: [
      {
        name: 'Bent-Over Barbell Row',
        target: 'Latissimus Dorsi, Rhomboids, Middle & Lower Trapezius',
        tip: 'Hinge your hips back keeping your spine dead-flat. Pull the barbell toward your lower waist, pulling with your elbows and squeezing your shoulder blades.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Barbell-Row.gif',
        sets: '4 Sets',
        reps: '8 - 12 Reps',
        equipment: 'Barbell',
        difficulty: 'Intermediate'
      },
      {
        name: 'Classic Barbell Deadlift',
        target: 'Posterior Chain (Erector Spinae, Glutes, Hamstrings, Trapezius)',
        tip: 'Grip the bar tightly at shoulder-width, flatten your back completely, pull your chest up, and push the floor away using leg drive to stand upright.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Barbell-Deadlift.gif',
        sets: '3 - 4 Sets',
        reps: '5 - 8 Reps',
        equipment: 'Barbell',
        difficulty: 'Advanced'
      },
      {
        name: 'Lat Pulldown',
        target: 'Outer Latissimus Dorsi, Teres Major, Lower Trapezius',
        tip: 'Slightly lean back but keep your torso locked. Draw the bar downward toward your upper chest, focusing on driving your elbows toward your hips.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Lat-Pulldown.gif',
        sets: '3 - 4 Sets',
        reps: '10 - 12 Reps',
        equipment: 'Machine',
        difficulty: 'Beginner'
      },
      {
        name: 'Seated Cable Row',
        target: 'Rhomboids, Middle Trapezius, Posterior Deltoids',
        tip: 'Keep your knees slightly flexed and back straight. pull the handle to your abdomen, squeezing your shoulder blades tightly at the end of the motion.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Seated-Cable-Row.gif',
        sets: '3 Sets',
        reps: '10 - 12 Reps',
        equipment: 'Cable',
        difficulty: 'Beginner'
      },
      {
        name: 'Strict Pull-Ups',
        target: 'Latissimus Dorsi, Rhomboids, Biceps, Core',
        tip: 'Start in a secure dead-hang with active shoulders. Pull yourself vertically upwards until your chin clearly passes above the bar with zero leg swing.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/03/Pull-Up.gif',
        sets: '3 Sets',
        reps: '6 - 12 Reps',
        equipment: 'Bodyweight',
        difficulty: 'Advanced'
      },
      {
        name: 'One-Arm Dumbbell Row',
        target: 'Latissimus Dorsi, Rhomboids, Posterior Deltoid',
        tip: 'Place one knee and hand supportively on a bench. Row the dumbbell tightly up toward your back hip pocket in an arc, keeping your pelvis flat.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Dumbbell-Row.gif',
        sets: '3 Sets',
        reps: '10 - 12 Reps',
        equipment: 'Dumbbell',
        difficulty: 'Intermediate'
      }
    ],
    legs: [
      {
        name: 'Barbell Back Squats',
        target: 'Quadriceps, Gluteus Maximus, Hamstrings, Erectors',
        tip: 'Position the barbell securely on your upper traps. Break at your hips and lower down until your thighs go parallel or deeper, then stand up explosively.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/BARBELL-SQUAT.gif',
        sets: '4 Sets',
        reps: '6 - 10 Reps',
        equipment: 'Barbell',
        difficulty: 'Advanced'
      },
      {
        name: 'Leg Press',
        target: 'Quadriceps, Glutes, Hamstrings',
        tip: 'Arrange your feet on the plate shoulder-width apart. Lower the heavy storage carriage controlled to 90 degrees. Do not lock your knees at top.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Leg-Press.gif',
        sets: '3 - 4 Sets',
        reps: '10 - 15 Reps',
        equipment: 'Machine',
        difficulty: 'Beginner'
      },
      {
        name: 'Romanian Deadlift (RDL)',
        target: 'Hamstrings, Glute boundaries, Lower Spine',
        tip: 'Tilt your hips backward with just a micro-flex in your knees. Glide the barbell down close to your shins until you feel an immense hamstring stretch.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Romanian-Deadlift.gif',
        sets: '3 Sets',
        reps: '8 - 12 Reps',
        equipment: 'Barbell',
        difficulty: 'Intermediate'
      },
      {
        name: 'Leg Extension',
        target: 'Quadriceps Femoris (Isolation)',
        tip: 'Ensure your back is flat against the pad. Flex your quads upward to fully extend your legs, holding peak squeeze for 1 second with control.',
        gif: 'https://media.tenor.com/L-taJvA94kQAAAAM/leg-extension.gif',
        sets: '3 Sets',
        reps: '12 - 15 Reps',
        equipment: 'Machine',
        difficulty: 'Beginner'
      },
      {
        name: 'Lying Leg Curl',
        target: 'Biceps Femoris, Hamstrings, Gastrocnemius',
        tip: 'Lie flat keeping your hips glued down to the bench pad. Flex feet upward, dragging the pad toward your lower glutes, then release slowly.',
        gif: 'https://i.pinimg.com/originals/c5/b9/2f/c5b92f47adca09aa352bea92b44179f0.gif',
        sets: '3 Sets',
        reps: '12 - 15 Reps',
        equipment: 'Machine',
        difficulty: 'Beginner'
      },
      {
        name: 'Standing Calf Raise',
        target: 'Gastrocnemius, Soleus (Calves)',
        tip: 'Sink down to get a full, deep stretch in your calf muscles at the base, then explode vertically up on your tiptoes. Squeeze tight.',
        gif: 'https://i.pinimg.com/originals/2f/7c/ca/2f7cca8d37c65384c1d0bd84cc0a91d1.gif',
        sets: '4 Sets',
        reps: '15 - 20 Reps',
        equipment: 'Machine',
        difficulty: 'Beginner'
      },
      {
        name: 'Walking Dumbbell Lunge',
        target: 'Quadriceps, Glutes, Hamstrings, Core Balance',
        tip: 'Take a controlled step brandishing dumbbells at your sides. Lower yourself until your back knee is a fraction of an inch from the floor, then step forward.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Dumbbell-Lunge.gif',
        sets: '3 Sets',
        reps: '10 - 12 Steps per leg',
        equipment: 'Dumbbells',
        difficulty: 'Intermediate'
      }
    ],
    shoulders: [
      {
        name: 'Standing Military Press',
        target: 'Anterior Deltoids, Lateral Deltoids, Triceps Brachii, Abdominal Core',
        tip: 'Squeeze your glutes and core to anchor your lower back. Press the barbell straight overhead, tilting your head slightly back to let the bar pass.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/07/Barbell-Standing-Military-Press.gif',
        sets: '4 Sets',
        reps: '6 - 10 Reps',
        equipment: 'Barbell',
        difficulty: 'Advanced'
      },
      {
        name: 'Dumbbell Lateral Raise',
        target: 'Lateral Deltoids (Shoulder Width)',
        tip: 'Tilt your torso slightly forward. Raise dumbbells outward in a wide sweeping arc, with pinkies slightly elevated at peak height.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Dumbbell-Lateral-Raise.gif',
        sets: '4 Sets',
        reps: '12 - 15 Reps',
        equipment: 'Dumbbells',
        difficulty: 'Beginner'
      },
      {
        name: 'Dumbbell Front Raise',
        target: 'Anterior Deltoids (Front Shoulder Plate)',
        tip: 'Stand tall with wrists turned semi-neutrally. Raise dumbbells forward sequentially or together until they reach head-height with no torso sway.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Dumbbell-Front-Raise.gif',
        sets: '3 Sets',
        reps: '12 - 15 Reps',
        equipment: 'Dumbbells',
        difficulty: 'Beginner'
      },
      {
        name: 'Dumbbell Rear Lateral Raise',
        target: 'Posterior Deltoids (Rear Shoulder Shield)',
        tip: 'Hinge forward at 90 degrees or lay down on an incline bench face-forward. Fly dumbbells out laterally, squeezing the back of your shoulders.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Dumbbell-Rear-Lateral-Raise.gif',
        sets: '4 Sets',
        reps: '12 - 15 Reps',
        equipment: 'Dumbbells',
        difficulty: 'Intermediate'
      },
      {
        name: 'Dumbbell Shoulder Press',
        target: 'Anterior Deltoids, Lateral Deltoids, Upper Chest',
        tip: 'Keep your elbows tucked slightly forward at a 30-degree angle. Press dumbbells upward smoothly, meeting together slightly at the top.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Dumbbell-Shoulder-Press.gif',
        sets: '3 - 4 Sets',
        reps: '8 - 12 Reps',
        equipment: 'Dumbbells',
        difficulty: 'Intermediate'
      },
      {
        name: 'Cable Face Pull',
        target: 'Rear Deltoids, Rhomboids, Infraspinatus (Rotator Cuffs)',
        tip: 'Stand back from pulley set at upper-chest level. Pull rope towards your forehead, spreading your hands wide to rotate your shoulder joints external.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Face-Pull.gif',
        sets: '3 Sets',
        reps: '15 - 20 Reps',
        equipment: 'Cable',
        difficulty: 'Beginner'
      }
    ],
    arms: [
      {
        name: 'Barbell Curl',
        target: 'Biceps Brachii (Long & Short Heads, Bicep Thickener)',
        tip: 'Lock your elbows rigidly to your torso sides. Curl the loaded barbell up using only your biceps, preventing your lower body from throwing sway.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Barbell-Curl.gif',
        sets: '3 - 4 Sets',
        reps: '8 - 12 Reps',
        equipment: 'Barbell',
        difficulty: 'Beginner'
      },
      {
        name: 'Tricep Cable Pushdown',
        target: 'Lateral Head of Triceps, Medial Head of Triceps',
        tip: 'Pin your upper elbows securely into your rib cage. Push the cable bar/rope downward, extending until your elbows lock and squeeze hard.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Tricep-Pushdown.gif',
        sets: '3 - 4 Sets',
        reps: '10 - 15 Reps',
        equipment: 'Cable',
        difficulty: 'Beginner'
      },
      {
        name: 'Dumbbell Hammer Curl',
        target: 'Brachioradialis, Brachialis (Forearm density, outer peak thickness)',
        tip: 'Grip dumbbells with palms facing each other neutrally. Curl dumbbells up without twist, focusing entirely on flexing your forearm muscles.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Dumbbell-Hammer-Curl.gif',
        sets: '3 Sets',
        reps: '10 - 12 Reps',
        equipment: 'Dumbbells',
        difficulty: 'Beginner'
      },
      {
        name: 'Overhead Dumbbell Tricep Extension',
        target: 'Long Head of Triceps (Maximum growth through deep loading stretches)',
        tip: 'Safely support a dumbbell with both palms flat against the inner base flat. Low-slide behind your head keeping elbows tight and parallel.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Dumbbell-Overhead-Triceps-Extension.gif',
        sets: '3 Sets',
        reps: '10 - 12 Reps',
        equipment: 'Dumbbell',
        difficulty: 'Intermediate'
      },
      {
        name: 'EZ-Bar Preacher Curl',
        target: 'Lower Biceps Brachii, Brachialis (Absolute Isolation)',
        tip: 'Rest your armpits and triceps completely flat on Preacher bench slant pad. Lower to a full controlled stretch, curl up and isolate peak contraction.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/03/Ez-Bar-Preacher-Curl.gif',
        sets: '3 Sets',
        reps: '8 - 12 Reps',
        equipment: 'Barbell',
        difficulty: 'Intermediate'
      },
      {
        name: 'Lying Tricep Extension (Skull Crusher)',
        target: 'Triceps Brachii (Long, Lateral & Medial Heads)',
        tip: 'Lie on a flat bench. Extend your arms vertically, draft them slightly back, and hinge ONLY at your elbow joints to lower the bar towards your forehead.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/03/Lying-Triceps-Extension.gif',
        sets: '3 Sets',
        reps: '10 - 12 Reps',
        equipment: 'Barbell',
        difficulty: 'Intermediate'
      }
    ],
    core: [
      {
        name: 'Hanging Leg Raises',
        target: 'Lower Rectus Abdominis, Iliopsoas (Deep Lower Core)',
        tip: 'Hang straight from a high bar. Flex your stomach and lift your straight legs upwards to meet the bar with no torso swinging.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/08/Hanging-Leg-Raises.gif',
        sets: '3 Sets',
        reps: '8 - 15 Reps',
        equipment: 'Bodyweight',
        difficulty: 'Advanced'
      },
      {
        name: 'Russian Twist',
        target: 'Internal / External Obliques (Waist stabilization & rotational power)',
        tip: 'Sit leaning back slightly with your legs bent and feet elevated 2 inches. Rotate your shoulders fully from side to side using core muscles.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2023/09/Russian-Twist.gif',
        sets: '3 Sets',
        reps: '15 - 20 Reps per side',
        equipment: 'Bodyweight',
        difficulty: 'Beginner'
      },
      {
        name: 'Ab Wheel Rollout',
        target: 'Deep Core Stabilization Trunk, Rectus Abdominis, Serratus Anterior',
        tip: 'Kneel holding wheel handles. Pack your tailbone under. Roll slowly out far under brace, hold, with no spine arch, and pull back with abs.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/05/Ab-Wheel-Rollout.gif',
        sets: '3 Sets',
        reps: '8 - 12 Reps',
        equipment: 'Bodyweight',
        difficulty: 'Advanced'
      },
      {
        name: 'Cable Crunch',
        target: 'Upper Rectus Abdominis (Aesthetic Six Pack Fiber)',
        tip: 'Kneel and hold rope overhead. Flex and curl your spine curving down until your elbows drift towards your legs, pulling entirely through abs.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Cable-Crunch.gif',
        sets: '3 Sets',
        reps: '12 - 15 Reps',
        equipment: 'Cable',
        difficulty: 'Intermediate'
      },
      {
        name: 'Decline Sit-Ups',
        target: 'Full Rectus Abdominis, Hip Flexors',
        tip: 'Lay backwards on decline bench. Curve your torso upward slowly in sequential spine flexes, getting a hard squeeze on your upper abdominal wall.',
        gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/03/Decline-Crunch.gif',
        sets: '3 Sets',
        reps: '15 - 20 Reps',
        equipment: 'Bodyweight',
        difficulty: 'Intermediate'
      }
    ]
  };

  const categories = [
    { id: 'chest', label: 'Chest Core' },
    { id: 'back', label: 'Back Thickness' },
    { id: 'legs', label: 'Leg Foundations' },
    { id: 'shoulders', label: 'Shoulder Caps' },
    { id: 'arms', label: 'Arm Hypertrophy' },
    { id: 'core', label: 'Abdominal Core' }
  ];

  if (authLoading) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin text-amber-500 font-bold" />
      </div>
    );
  }

  if (!isPremium) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex flex-col items-center justify-center px-4 relative overflow-hidden">
        {/* Cinematic Backdrop Pattern */}
        <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-[120px]"></div>
        
        <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-lg w-full text-center space-y-6 shadow-2xl relative z-10">
          <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full flex items-center justify-center mx-auto">
            <Lock className="h-6 w-6" />
          </div>
          <div>
            <h2 className="font-syne text-3xl font-extrabold tracking-wide uppercase">ELITE GYM DIRECTORY LOCKED</h2>
            <p className="text-[10px] text-amber-500 font-mono tracking-widest mt-1.5 uppercase">ATHLETE AUTHENTICATION & PREMIUM SUBSCRIPTION REQUIRED</p>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans font-light">
            Symmetry logs, barbell lifting guidelines, mechanical compound keys, and split programs are premium assets reserved specifically for elite subscribers.
          </p>
          <div className="pt-2 flex flex-col gap-3">
            <Link
              to="/pricing"
              className="w-full bg-amber-500 hover:bg-gold hover:scale-[1.02] text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded-sm block transition-all font-mono"
            >
              Get Premium Access Now
            </Link>
            <Link
              to="/"
              className="w-full bg-neutral-900 border border-neutral-850 hover:bg-neutral-850 text-white font-bold uppercase text-xs tracking-widest py-3 rounded-sm block transition-all font-mono"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Filter gymDatabase exercises based on activeCategory, searchQuery, and difficultyFilter
  const activeExercises = gymDatabase[activeCategory].filter((ex) => {
    const matchesSearch = ex.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          ex.target.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDifficulty = difficultyFilter === 'all' || ex.difficulty === difficultyFilter;
    return matchesSearch && matchesDifficulty;
  });

  return (
    <div className="bg-black text-white pt-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-amber-500 uppercase text-xs font-bold tracking-widest mb-2 font-mono">COMPOUND MATRIX</p>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black text-white tracking-wide">
            GYM TRAINING <span className="text-amber-500">PROGRAMS</span>
          </h1>
          <p className="text-neutral-400 mt-4 leading-relaxed font-light">
            Select your target compound region to analyze specific exercises with animated motion demonstrations, main target muscle divisions, and strict coaching instruction keys parsed from <span className="text-amber-500 font-semibold underline decoration-dotted">fitnessprogramer.com</span>.
          </p>
        </div>

        {/* Tab selection */}
        <div className="flex flex-wrap justify-center gap-3 mb-8 border-b border-neutral-900 pb-6">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setActiveCategory(cat.id as any);
                setSearchQuery('');
              }}
              className={`px-5 py-2.5 rounded font-bebas text-lg tracking-wider transition-all uppercase ${
                activeCategory === cat.id
                  ? 'bg-amber-500 text-black font-extrabold shadow-lg shadow-amber-500/10'
                  : 'bg-neutral-950 border border-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Dynamic Filters UI */}
        <div className="flex flex-col md:flex-row gap-4 justify-between items-center mb-12 bg-neutral-950/40 p-5 rounded border border-neutral-900">
          {/* Search bar inside category */}
          <div className="relative w-full md:w-80">
            <input
              type="text"
              placeholder={`Search ${activeCategory} exercises...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-neutral-900 border border-neutral-800 rounded px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 font-sans"
            />
          </div>

          {/* Difficulty Filters */}
          <div className="flex bg-neutral-900/60 p-1.5 rounded border border-neutral-800">
            {(['all', 'Beginner', 'Intermediate', 'Advanced'] as const).map((diff) => (
              <button
                key={diff}
                onClick={() => setDifficultyFilter(diff)}
                className={`px-3.5 py-1.5 rounded text-[10px] font-mono uppercase tracking-wider transition-all ${
                  difficultyFilter === diff
                    ? 'bg-amber-500 text-black font-extrabold'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {diff === 'all' ? 'All skill' : diff}
              </button>
            ))}
          </div>
        </div>

        {/* Exercise database listing with Gifs */}
        {activeExercises.length === 0 ? (
          <div className="text-center py-20 bg-neutral-950 border border-neutral-900 rounded">
            <p className="text-neutral-500 font-mono text-xs uppercase tracking-widest mb-1">NO MATCHING MOTION DEMONSTRATIONS FOUND</p>
            <p className="text-xs text-neutral-400">Try adjusting your filters or query within the active {activeCategory} category.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {activeExercises.map((ex, i) => (
              <div key={i} className="bg-neutral-950 border border-neutral-900 p-6 rounded relative hover:border-amber-500/25 transition-all duration-300 flex flex-col justify-between group">
                <div>
                  {/* Card Header Info */}
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center space-x-2.5">
                      <Dumbbell className="h-5 w-5 text-amber-500" />
                      <h3 className="font-bebas text-xl sm:text-2xl font-bold tracking-wide text-white uppercase group-hover:text-amber-500 transition-colors">{ex.name}</h3>
                    </div>
                    <div className="flex gap-2">
                      <span className={`text-[9px] font-mono uppercase tracking-widest px-2 py-0.5 rounded leading-none border ${
                        ex.difficulty === 'Beginner' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                        ex.difficulty === 'Intermediate' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                        'bg-rose-500/10 text-rose-400 border-rose-500/20'
                      }`}>
                        {ex.difficulty}
                      </span>
                      <span className="bg-neutral-900 border border-neutral-800 text-[9px] text-neutral-400 uppercase tracking-widest px-2 py-0.5 rounded leading-none font-mono">
                        {ex.equipment}
                      </span>
                    </div>
                  </div>

                  {/* Motion demonstration GIF loaded from fitnessprogramer.com */}
                  <div className="w-full h-56 md:h-64 bg-neutral-900 rounded overflow-hidden mb-5 relative border border-neutral-850 group-hover:border-amber-500/10 transition-colors">
                    {ex.gif ? (
                      <img 
                        src={getMediaProxyUrl(ex.gif)} 
                        alt={`${ex.name} form demonstration`} 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover select-none pointer-events-none" 
                        loading="lazy"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center bg-neutral-950">
                        <Dumbbell className="h-8 w-8 text-neutral-700 animate-pulse" />
                        <span className="text-[10px] text-neutral-500 uppercase tracking-widest font-mono mt-1">NO VIDEO DETECTED</span>
                      </div>
                    )}
                    <div className="absolute bottom-2 right-2 bg-black/80 backdrop-blur-md text-[8px] text-neutral-400 font-mono tracking-widest px-2 py-1 rounded border border-neutral-800/80 uppercase">
                      {(() => {
                        try {
                          return new URL(ex.gif).hostname.replace('www.', '');
                        } catch {
                          return 'fitnessprogramer.0com';
                        }
                      })()}
                    </div>
                  </div>

                  {/* Targets Section */}
                  <div className="flex items-start space-x-2 text-xs text-amber-500 mb-4 bg-amber-500/5 px-3 py-2 rounded border border-amber-500/10">
                    <Target className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>
                      <strong className="font-mono text-[10px] uppercase tracking-wider block mb-0.5">TARGET DIVISIONS</strong>
                      <span className="text-neutral-300">{ex.target}</span>
                    </span>
                  </div>

                  {/* Pro Techniques tip */}
                  <p className="text-xs text-neutral-300 leading-relaxed font-sans font-light mt-2">
                    <span className="text-neutral-500 font-bold uppercase block text-[10px] tracking-wider mb-1">PRO COACHING CUES</span>
                    {ex.tip}
                  </p>
                </div>

                {/* Performance parameters footer */}
                <div className="mt-6 pt-4 border-t border-neutral-900 flex justify-between items-center text-[10px] text-neutral-500">
                  <span>SET RECOMMENDATION: <span className="text-white font-bold font-mono">{ex.sets}</span></span>
                  <span>REP PROFILE: <span className="text-white font-bold font-mono">{ex.reps}</span></span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Centralized database prompt */}
        <div className="bg-neutral-950/80 border border-neutral-900 rounded-lg p-8 max-w-5xl mx-auto mt-12 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl"></div>
          <span className="text-amber-500 uppercase text-[10px] font-black tracking-widest font-mono">Centralized Athletic Database</span>
          <h3 className="font-bebas text-2xl sm:text-3xl font-extrabold text-white uppercase italic mt-1">Looking for our massive exercise library?</h3>
          <p className="text-xs text-neutral-400 max-w-xl mx-auto mt-2 leading-relaxed">
            Gain full access to our massive exercise database. Filter thousands of exercises across Gym, Calisthenics, Home bodyweight and Cardio programs.
          </p>
          <div className="mt-5">
            <Link
              to="/workouts"
              className="inline-flex items-center gap-2 bg-amber-500 text-black font-extrabold text-xs uppercase tracking-widest py-3 px-6 rounded-sm hover:brightness-110 shadow-lg shadow-amber-500/10 transition-all font-mono"
            >
              <span>Explore Massive Exercise Library 📖</span>
              <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
