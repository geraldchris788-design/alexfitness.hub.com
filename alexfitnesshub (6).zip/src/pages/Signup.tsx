import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { UserPlus, RefreshCw, ShieldAlert, CheckCircle, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { translateFirebaseAuthError } from '../lib/authErrors';
import { firebaseConfig } from '../lib/firebase';

export default function Signup() {
  const navigate = useNavigate();
  const { signUpWithEmail, loginWithGoogle, loginWithApple, sendVerification } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorText, setErrorText] = useState<string | null>(null);
  const [successText, setSuccessText] = useState<string | null>(null);
  const [isSubmit, setIsSubmit] = useState(false);
  const [isAppleLoading, setIsAppleLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleAppleSignup = async () => {
    setErrorText(null);
    setSuccessText(null);
    setIsAppleLoading(true);
    try {
      await loginWithApple();
      setSuccessText(`🎉 Unified Apple Authentication verified successfully! Syncing dashboard...`);
      navigate('/onboarding');
    } catch (err: any) {
      setErrorText(translateFirebaseAuthError(err.code || 'unknown', err.message));
    } finally {
      setIsAppleLoading(false);
    }
  };

  const handleGoogleSignup = async () => {
    setErrorText(null);
    setSuccessText(null);
    setIsGoogleLoading(true);
    try {
      await loginWithGoogle();
      setSuccessText(`🎉 Unified Google Authentication verified successfully! Syncing dashboard...`);
      navigate('/onboarding');
    } catch (err: any) {
      setErrorText(translateFirebaseAuthError(err.code || 'unknown', err.message));
    } finally {
      setIsGoogleLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmit(true);
    setErrorText(null);
    setSuccessText(null);

    // Client-side minimum password length validation
    if (password.length < 6) {
      setErrorText("Password must be at least 6 characters long.");
      setIsSubmit(false);
      return;
    }

    try {
      await signUpWithEmail(email, password, name);
      try {
        await sendVerification();
      } catch (verifyError) {
        console.warn("Could not dispatch verification email upon signup", verifyError);
      }
      
      setSuccessText(`🎉 Account created! Session authorized. Loading your personalized performance hub...`);
      setName('');
      setEmail('');
      setPassword('');
      
      setTimeout(() => {
        navigate('/dashboard');
      }, 1800);
    } catch (err: any) {
      setErrorText(translateFirebaseAuthError(err.code || 'unknown', err.message));
    } finally {
      setIsSubmit(false);
    }
  };

  return (
    <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center px-4">
      <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-md w-full space-y-6 text-left shadow-2xl relative">
        <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl"></div>
        
        <div className="text-center">
          <span className="text-[10px] text-amber-500 font-extrabold tracking-widest font-mono uppercase block mb-1">Join Coach Alex Elite Club</span>
          <h2 className="font-bebas text-3xl sm:text-4xl font-extrabold text-white tracking-wider">CREATE SECURITY ACCOUNT</h2>
          <p className="text-xs text-neutral-500 uppercase tracking-widest mt-1">Begin your high-integrity transformation path</p>
        </div>

        {errorText === 'auth/operation-not-allowed' ? (
          <div className="bg-neutral-900 border border-amber-500/20 p-4 rounded-sm text-xs leading-5 space-y-3">
            <div className="flex space-x-2 items-center text-amber-500 font-bold uppercase font-mono">
              <ShieldAlert className="h-4.5 w-4.5 text-amber-500 shrink-0" />
              <span>Firebase Auth Provider Disabled</span>
            </div>
            <p className="text-neutral-400">
              The Google or Email/Password Sign-In provider is currently disabled in your Firebase Console for project <strong className="text-white">{firebaseConfig.projectId}</strong>.
            </p>
            <div className="text-[11px] text-neutral-450 bg-black/50 p-2.5 rounded border border-neutral-850 space-y-1.5 leading-4">
               <div className="font-bold text-amber-400 uppercase tracking-widest text-[9px] font-mono">🔧 How to enable it:</div>
              <div>1. Open your <a href={`https://console.firebase.google.com/u/0/project/${firebaseConfig.projectId}/authentication/providers`} target="_blank" rel="noopener noreferrer" className="text-amber-500 underline font-semibold">Firebase Authentication Console</a>.</div>
              <div>2. Click on the <strong>Sign-in method</strong> tab.</div>
              <div>3. Click <strong>Add new provider</strong>, choose <strong>Google</strong>, toggle <strong>Enable</strong>, and click <strong>Save</strong>.</div>
              <div>4. Also add and enable <strong>Email/Password</strong> and click <strong>Save</strong>.</div>
            </div>
            <div className="pt-2 border-t border-neutral-850">
              <button
                type="button"
                onClick={() => setErrorText(null)}
                className="w-full text-center text-[10px] text-neutral-500 uppercase tracking-widest font-mono hover:text-neutral-350 underline pt-1"
              >
                Clear Error Overlay
              </button>
            </div>
          </div>
        ) : (
          errorText && (
            <div className="flex space-x-2.5 items-center p-3 bg-rose-500/10 border border-rose-500/20 text-rose-500 rounded text-xs leading-5">
              <ShieldAlert className="h-4.5 w-4.5 shrink-0" />
              <span>{errorText}</span>
            </div>
          )
        )}

        {successText && (
          <div className="flex space-x-2.5 items-start p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded text-xs leading-5">
            <CheckCircle className="h-5 w-5 shrink-0 mt-0.5 text-emerald-500 animate-pulse" />
            <span>{successText}</span>
          </div>
        )}

        <form onSubmit={handleRegister} className="space-y-4">
          <div className="flex flex-col space-y-1">
            <label className="text-xs uppercase text-neutral-400 font-bold">Your Full Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Chukwuma Obi"
              className="bg-black border border-neutral-850 rounded-sm p-3 text-xs font-semibold text-white focus:border-amber-500 outline-none transition-colors"
            />
          </div>

          <div className="flex flex-col space-y-1">
            <label className="text-xs uppercase text-neutral-400 font-bold">Email Address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. obi@domain.com"
              className="bg-black border border-neutral-850 rounded-sm p-3 text-xs font-semibold text-white focus:border-amber-500 outline-none transition-colors"
            />
          </div>

          <div className="flex flex-col space-y-1">
            <label className="text-xs uppercase text-neutral-400 font-bold">Create Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 6 characters"
                className="w-full bg-black border border-neutral-850 rounded-sm p-3 pr-10 text-xs font-semibold text-white focus:border-amber-500 outline-none transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-white transition-colors focus:outline-none"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </button>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmit}
              className="w-full bg-amber-500 hover:brightness-110 text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded-sm flex items-center justify-center space-x-2 transition-all font-mono cursor-pointer"
            >
              {isSubmit ? <RefreshCw className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
              <span>{isSubmit ? 'Signing up...' : 'Register Anabolic Profile'}</span>
            </button>
          </div>
        </form>

        <div className="space-y-4">
          <div className="flex items-center space-x-2 my-2 text-neutral-605 text-[10px] uppercase font-bold tracking-widest font-mono">
            <span className="h-px bg-neutral-900 flex-grow"></span>
            <span>or join via</span>
            <span className="h-px bg-neutral-900 flex-grow"></span>
          </div>

          <button
            type="button"
            disabled={isGoogleLoading || isAppleLoading || isSubmit}
            onClick={handleGoogleSignup}
            className="w-full bg-[#0A0A0A] border border-neutral-850 hover:bg-neutral-900 hover:border-neutral-700 text-white font-extrabold uppercase text-xs tracking-widest py-3 rounded-sm flex items-center justify-center space-x-2.5 transition-all font-mono cursor-pointer disabled:opacity-50"
          >
            {isGoogleLoading ? (
              <RefreshCw className="h-4 w-4 animate-spin text-amber-500" />
            ) : (
              <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24" fill="currentColor">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05" />
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335" />
              </svg>
            )}
            <span>{isGoogleLoading ? 'Choosing Google Account...' : 'Continue with Google Account'}</span>
          </button>

          <button
            type="button"
            disabled={isGoogleLoading || isAppleLoading || isSubmit}
            onClick={handleAppleSignup}
            className="w-full bg-[#0A0A0A] border border-[#111111] hover:bg-[#111111] hover:border-[#222222] text-white font-extrabold uppercase text-xs tracking-widest py-3.5 rounded-sm flex items-center justify-center space-x-2.5 transition-all font-mono cursor-pointer disabled:opacity-50"
          >
            {isAppleLoading ? (
              <RefreshCw className="h-4 w-4 animate-spin text-amber-500" />
            ) : (
              <svg className="h-4 w-4 shrink-0 fill-current text-white" viewBox="0 0 24 24">
                <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 4.17c.66-.81 1.11-1.93.99-3.06-.96.04-2.13.64-2.82 1.45-.6.69-1.12 1.83-.98 2.94 1.07.08 2.15-.52 2.81-1.33z" />
              </svg>
            )}
            <span>{isAppleLoading ? 'Connecting with Apple...' : 'Continue with Apple Account'}</span>
          </button>
        </div>

        <div className="text-center pt-2 border-t border-neutral-900">
          <span className="text-[9px] font-mono text-neutral-500 uppercase tracking-widest bg-neutral-950 px-2 py-1 rounded inline-block">
            🛡️ Production Database Secure Storage Guard
          </span>
        </div>

        <div className="border-t border-neutral-900 pt-4 text-center text-xs text-neutral-500 space-y-3">
          <div>
            Already registered? <Link to="/auth/login" className="text-amber-500 font-bold hover:underline">Sign In here</Link>
          </div>
          <div className="pt-2 border-t border-neutral-905">
            <Link to="/auth/diagnostic" className="text-amber-500/60 hover:text-amber-500 text-[10px] font-mono hover:underline block">
              🛡️ Having signup issues? Run Health Diagnostics
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
