import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { verifyPasswordResetCode, confirmPasswordReset } from 'firebase/auth';
import { KeyRound, ShieldAlert, CheckCircle, Eye, EyeOff, Loader2, ArrowLeft } from 'lucide-react';
import { motion } from 'motion/react';
import { auth } from '../lib/firebase';
import { translateFirebaseAuthError } from '../lib/authErrors';

export default function ResetPassword() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  // Extract Firebase Action Code parameters
  const oobCode = searchParams.get('oobCode');
  
  const [verifying, setVerifying] = useState(true);
  const [tokenValid, setTokenValid] = useState(false);
  const [emailForCode, setEmailForCode] = useState<string | null>(null);
  
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isSubmit, setIsSubmit] = useState(false);
  const [errorText, setErrorText] = useState<string | null>(null);
  const [successText, setSuccessText] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [countdown, setCountdown] = useState(4);

  // Phase 1: On mount, verify that the oobCode (one-time reset token) is valid
  useEffect(() => {
    if (!oobCode) {
      setVerifying(false);
      setTokenValid(false);
      setErrorText("No secure reset token was detected in your email link. Please request a new link.");
      return;
    }

    const checkCode = async () => {
      try {
        // verifyPasswordResetCode returns the email associated with the link upon success
        const email = await verifyPasswordResetCode(auth, oobCode);
        setEmailForCode(email);
        setTokenValid(true);
      } catch (err: any) {
        console.error("[RESET PASSWORD] Verification of oobCode failed:", err);
        setTokenValid(false);
        setErrorText(
          err.code === 'auth/invalid-action-code' || err.code === 'auth/expired-action-code'
            ? "Your password reset token has expired or has already been used. Firebase action links can only be used once."
            : translateFirebaseAuthError(err.code || 'unknown', err.message)
        );
      } finally {
        setVerifying(false);
      }
    };

    checkCode();
  }, [oobCode]);

  // Phase 2: Handle countdown and auto-redirection on success
  useEffect(() => {
    if (successText && countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (successText && countdown === 0) {
      navigate('/auth/login');
    }
  }, [successText, countdown, navigate]);

  // Submit password change back to Firebase Auth API
  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!oobCode) return;
    
    setErrorText(null);
    setSuccessText(null);

    // Dynamic validations
    if (password.length < 6) {
      setErrorText("Your password must be at least 6 characters long for optimal system security.");
      return;
    }

    if (password !== confirmPassword) {
      setErrorText("Passwords do not match. Please verify both fields.");
      return;
    }

    setIsSubmit(true);
    try {
      // Execute the real secure password reset on Firebase
      await confirmPasswordReset(auth, oobCode, password);
      setSuccessText("🔒 Password successfully reset! Your credentials have been securely updated.");
    } catch (err: any) {
      console.error("[RESET PASSWORD] Confirmation failed:", err);
      setErrorText(translateFirebaseAuthError(err.code || 'unknown', err.message));
    } finally {
      setIsSubmit(false);
    }
  };

  return (
    <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center px-4">
      <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-md w-full space-y-6 text-left shadow-2xl relative">
        <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl"></div>
        
        <div className="text-center">
          <span className="text-[10px] text-amber-500 font-extrabold tracking-widest font-mono uppercase block mb-1">Coach Alex Elite System</span>
          <h2 className="font-bebas text-3xl sm:text-4xl font-extrabold text-white tracking-wider uppercase">
            Reset Password
          </h2>
          <p className="text-xs text-neutral-500 uppercase tracking-widest mt-1">
            Configure secure master credentials
          </p>
        </div>

        {/* LOADING STATE */}
        {verifying && (
          <div className="py-12 flex flex-col items-center justify-center space-y-4 text-center">
            <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
            <p className="text-sm text-neutral-400 font-mono">Verifying secure authentication token...</p>
          </div>
        )}

        {/* ERROR / EXPIRED / INVALID KEY TOKEN STATE */}
        {!verifying && !tokenValid && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="bg-red-950/20 border border-red-900/40 p-4 rounded-sm flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-red-400">Security Check Failed</h4>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  {errorText || "The password reset token is expired, corrupted, or has already been used."}
                </p>
              </div>
            </div>

            <div className="space-y-4 text-xs text-neutral-400 border-t border-neutral-900 pt-4 leading-relaxed">
              <h5 className="font-bold text-neutral-300 font-mono uppercase">Why did this happen?</h5>
              <ul className="list-disc pl-4 space-y-2">
                <li><strong className="text-neutral-300">One-Time Tokens:</strong> Password reset tokens are highly secure, temporary codes generated by Google Firebase. To protect your account from replay attacks, they can only be used once.</li>
                <li><strong className="text-neutral-300">Expiration Time:</strong> Reset links are only active for a limited time context. If you clicked the link hours after requesting it, the token has automatically expired.</li>
                <li><strong className="text-neutral-300">Browser Preprocessing:</strong> Some email clients and browser extensions preprocess URLs to filter threats. This action can silently use the one-time token in the background, causing it to appear "expired" to you.</li>
              </ul>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <Link
                to="/auth/login"
                className="w-full bg-amber-500 hover:bg-amber-600 text-black text-center py-3 font-mono font-bold text-xs uppercase tracking-wider transition-colors rounded-sm"
              >
                Request a New Link
              </Link>
              <Link 
                to="/auth/login" 
                className="w-full hover:bg-neutral-900 text-neutral-400 text-center py-2.5 font-mono text-xs transition-colors rounded-sm flex items-center justify-center gap-2 border border-transparent hover:border-neutral-800"
              >
                <ArrowLeft className="w-4 h-4" /> Return to Login
              </Link>
            </div>
          </motion.div>
        )}

        {/* INPUT FIELDS AND STATUS CONTROLLER (ACTIVE RESET & SUCCESS SCENARIOS) */}
        {!verifying && tokenValid && (
          <div className="space-y-4">
            {/* SUCCESS BANNER */}
            {successText ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-6 py-6 text-center"
              >
                <div className="mx-auto w-12 h-12 bg-emerald-500/10 border border-emerald-500/20 rounded-full flex items-center justify-center mb-2">
                  <CheckCircle className="w-6 h-6 text-emerald-500" />
                </div>
                <div className="space-y-2">
                  <h4 className="text-base font-bold text-emerald-400">Security Log Saved</h4>
                  <p className="text-xs text-neutral-400 leading-relaxed px-2">
                    Your account has been securely locked with your newly configured master credentials.
                  </p>
                </div>
                
                <div className="bg-neutral-900/40 border border-neutral-900 p-3 rounded-sm">
                  <p className="text-[11px] font-mono text-amber-500">
                    Automatically redirecting in <span className="font-bold text-white text-sm">{countdown}</span> seconds...
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => navigate('/auth/login')}
                  className="w-full bg-amber-500 hover:bg-amber-600 text-black py-3 font-mono font-bold text-xs uppercase tracking-widest transition-colors rounded-sm block"
                >
                  Log In Immediately
                </button>
              </motion.div>
            ) : (
              <motion.form 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                onSubmit={handleResetSubmit} 
                className="space-y-4"
              >
                {/* Email indicator */}
                {emailForCode && (
                  <div className="bg-neutral-900/60 border border-neutral-900 px-3 py-2 rounded-sm mb-4">
                    <span className="text-[10px] font-mono text-neutral-500 uppercase block">Account Under Authorization</span>
                    <span className="text-xs font-mono font-bold text-amber-500">{emailForCode}</span>
                  </div>
                )}

                {/* Error Box */}
                {errorText && (
                  <div className="bg-red-950/20 border border-red-900/40 p-3 rounded-sm flex items-start gap-2 text-xs text-red-400">
                    <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{errorText}</span>
                  </div>
                )}

                {/* New Password */}
                <div className="space-y-1.5">
                  <label className="text-neutral-400 text-[10px] uppercase tracking-wider font-mono font-semibold block">
                    New Master Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      placeholder="••••••••"
                      className="w-full bg-neutral-900 hover:bg-neutral-900/80 focus:bg-neutral-900/80 border border-neutral-800 focus:border-amber-500/50 rounded-sm py-2.5 pl-3 pr-10 text-xs font-mono text-white placeholder-neutral-700 outline-none transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-neutral-500 hover:text-white transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-[10px] text-neutral-500 font-mono">Minimum 6 secure alphanumeric characters</p>
                </div>

                {/* Confirm Password */}
                <div className="space-y-1.5">
                  <label className="text-neutral-400 text-[10px] uppercase tracking-wider font-mono font-semibold block">
                    Confirm New Password
                  </label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    placeholder="••••••••"
                    className="w-full bg-neutral-900 hover:bg-neutral-900/80 focus:bg-neutral-900/80 border border-neutral-800 focus:border-amber-500/50 rounded-sm py-2.5 px-3 text-xs font-mono text-white placeholder-neutral-700 outline-none transition-all"
                  />
                </div>

                {/* Form Buttons */}
                <div className="space-y-2 pt-4">
                  <button
                    type="submit"
                    disabled={isSubmit}
                    className="w-full bg-amber-500 hover:bg-amber-600 disabled:bg-amber-500/50 text-black py-3 font-mono font-bold text-xs uppercase tracking-widest transition-colors rounded-sm flex items-center justify-center gap-2"
                  >
                    {isSubmit ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Saving to cloud auth...
                      </>
                    ) : (
                      <>
                        <KeyRound className="w-4 h-4" />
                        Update Credentials
                      </>
                    )}
                  </button>

                  <Link 
                    to="/auth/login" 
                    className="w-full hover:bg-neutral-900 text-neutral-400 text-center py-2 font-mono text-xs transition-colors rounded-sm block"
                  >
                    Cancel and Return
                  </Link>
                </div>
              </motion.form>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
