import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, Dumbbell, Sparkles, RefreshCw, Trophy, Heart } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Logout() {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const [status, setStatus] = useState<'pending' | 'checking' | 'cached' | 'done'>('pending');
  const [counter, setCounter] = useState(3);

  useEffect(() => {
    const performSignOut = async () => {
      try {
        // Step 1: Simulating biometric cache clearance & session tear-down
        setStatus('pending');
        await new Promise((resolve) => setTimeout(resolve, 800));
        
        setStatus('checking');
        await new Promise((resolve) => setTimeout(resolve, 800));

        setStatus('cached');
        // Actual Firebase de-authentication
        await logout();
        await new Promise((resolve) => setTimeout(resolve, 600));

        setStatus('done');
      } catch (err) {
        console.error("Sign out fail-safe triggered:", err);
        // Fail-safe logout
        await logout().catch(() => {});
        setStatus('done');
      }
    };
    performSignOut();
  }, [logout]);

  useEffect(() => {
    if (status === 'done') {
      const timer = setInterval(() => {
        setCounter((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            navigate('/');
            return 0;
          }
          return prev - 1;
        });
      }, 1040);
      return () => clearInterval(timer);
    }
  }, [status, navigate]);

  return (
    <div className="pt-32 pb-16 min-h-screen bg-black text-white flex flex-col items-center justify-center text-center px-4 relative overflow-hidden">
      {/* Decorative ambient background */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-md w-full shadow-2xl relative z-10 space-y-6">
        
        <div className="flex justify-center">
          <div className="w-16 h-16 bg-neutral-900 border border-neutral-800 rounded-full flex items-center justify-center relative animate-pulse">
            <LogOut className="h-6 w-6 text-rose-500" />
            <div className="absolute inset-0 rounded-full border border-rose-500/20 animate-ping"></div>
          </div>
        </div>

        <div className="space-y-2">
          <span className="text-[10px] text-amber-500 font-extrabold tracking-widest font-mono uppercase block">
            Athlete Session De-Authorization
          </span>
          <h2 className="font-bebas text-3xl sm:text-4xl font-extrabold text-white tracking-wider">
            {status !== 'done' ? 'SIGNING OUT SECURELY' : 'SESSION TERMINATED'}
          </h2>
          <p className="text-xs text-neutral-405 max-w-xs mx-auto">
            {status === 'pending' && 'Tearing down OAuth sessions and checking biometrics sync...'}
            {status === 'checking' && 'Clearing athlete local cache files safely...'}
            {status === 'cached' && 'Synchronizing physical records and metrics snapshots...'}
            {status === 'done' && 'Your session has been terminated safely. Fuel up for your next workout!'}
          </p>
        </div>

        {/* Loading/Success Bar */}
        <div className="bg-neutral-900 h-1 w-full rounded-full overflow-hidden">
          <div 
            className={`h-full bg-amber-500 transition-all duration-700 ${
              status === 'pending' ? 'w-1/4' :
              status === 'checking' ? 'w-2/4' :
              status === 'cached' ? 'w-3/4' :
              'w-full bg-emerald-500'
            }`}
          ></div>
        </div>

        {status !== 'done' ? (
          <div className="flex justify-center items-center space-x-2.5 text-xs text-neutral-500 font-mono">
            <RefreshCw className="h-3.5 w-3.5 animate-spin text-amber-500" />
            <span>Securing active user session data...</span>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-sm text-left space-y-2.5">
              <div className="flex items-center space-x-2 text-emerald-400 font-bold text-xs">
                <Trophy className="h-4 w-4 text-emerald-500" />
                <span>Coach Alex Reminder</span>
              </div>
              <p className="text-neutral-450 text-[11px] leading-5">
                "The work is done for today. Get some premium rest, stay hydrated, keep your macronutrients on target, and let's crush the steel again tomorrow. You are building something immortal."
              </p>
            </div>

            <p className="text-[10px] text-neutral-500 uppercase tracking-widest font-mono">
              Redirecting you to Home in <strong className="text-amber-500 text-xs">{counter}s</strong>
            </p>

            <button 
              onClick={() => navigate('/auth/login')}
              className="w-full bg-amber-500 hover:brightness-110 text-black font-extrabold uppercase text-xs tracking-widest py-3 rounded-sm transition-all focus:outline-none cursor-pointer"
            >
              Log Back In Now
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
