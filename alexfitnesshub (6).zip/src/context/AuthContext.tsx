import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail, 
  sendEmailVerification,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  GoogleAuthProvider,
  OAuthProvider,
  User as FirebaseUser
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, firebaseConfig } from '../lib/firebase';
import { User } from '../types';
import { apiFetch } from '../lib/api';

/**
 * Resolves a continue URI that is guaranteed to be accepted by Firebase Authentication.
 * For local development on localhost/127.0.0.1, standard local origin is accepted.
 * For hosted web applications, falls back to the officially whitelisted default authDomain.
 */
function getValidContinueUri(path: string): string {
  if (typeof window === 'undefined') return '';
  const hostname = window.location.hostname;
  const origin = window.location.origin;
  const cleanPath = path.startsWith('/') ? path : `/${path}`;
  
  // Local environment allows direct redirection back to origin
  const isLocal = hostname === 'localhost' || hostname === '127.0.0.1';
  
  // Only use the authDomain sandbox workaround within dynamic run.app previews
  // and only if the user hasn't explicitly overridden the configurations
  const metaEnv = (import.meta as any).env || {};
  const isAiStudioSandbox = (hostname.includes('run.app') || hostname.includes('aistudio.google')) &&
                           !metaEnv.VITE_FIREBASE_AUTH_DOMAIN;

  if (isLocal || !isAiStudioSandbox) {
    return `${origin}${cleanPath}`;
  }
  
  const rawAuthDomain = firebaseConfig.authDomain || 'alex-project-777.firebaseapp.com';
  // Strip any existing protocol prefix (http:// or https://)
  let cleanAuthDomain = rawAuthDomain.replace(/^https?:\/\//i, '');
  // Extract only the domain part (excluding paths or trailing slashes) and trim whitespace
  cleanAuthDomain = cleanAuthDomain.split('/')[0].trim();
  
  if (!cleanAuthDomain) {
    cleanAuthDomain = 'alex-project-777.firebaseapp.com';
  }
  
  return `https://${cleanAuthDomain}${cleanPath}`;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  redirectError: string | null;
  refreshUser: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  logout: () => Promise<void>;
  loginWithEmail: (email: string, password: string) => Promise<FirebaseUser>;
  signUpWithEmail: (email: string, password: string, name: string) => Promise<FirebaseUser>;
  loginWithGoogle: () => Promise<FirebaseUser>;
  loginWithGoogleRedirect: () => Promise<void>;
  loginWithApple: () => Promise<FirebaseUser>;
  resetPassword: (email: string) => Promise<void>;
  sendVerification: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [redirectError, setRedirectError] = useState<string | null>(null);

  const fetchProfile = async (firebaseUser: FirebaseUser): Promise<User | null> => {
    try {
      const userDocRef = doc(db, 'users', firebaseUser.uid);
      const docSnap = await getDoc(userDocRef).catch(err => {
        console.warn("[AUTH CONTEXT] Direct Firestore read rejected by rules or structure. Activating robust fallback storage.");
        throw err;
      });
      
      const providerId = firebaseUser.providerData[0]?.providerId || (firebaseUser.email ? 'password' : 'unknown');
      const isGoogle = providerId === 'google.com';
      const isApple = providerId === 'apple.com';
      
      if (docSnap && docSnap.exists && docSnap.exists()) {
        const u = docSnap.data() as User;
        let needsUpdate = false;
        const updatePayload: Partial<User> = {};
        
        // Expiration check: if subscriptionEndDate has passed, demote to free plan
        if (u.subscriptionPlan !== 'free' && u.subscriptionStatus === 'active' && u.subscriptionEndDate) {
          const now = new Date();
          const endDate = new Date(u.subscriptionEndDate);
          if (endDate < now) {
            updatePayload.subscriptionPlan = 'free';
            updatePayload.subscriptionStatus = 'expired';
            updatePayload.paymentStatus = 'unpaid';
            needsUpdate = true;
          }
        }
        
        if (u.isVerified !== !!firebaseUser.emailVerified) {
          updatePayload.isVerified = !!firebaseUser.emailVerified;
          needsUpdate = true;
        }
        if (isGoogle && !u.avatarUrl && firebaseUser.photoURL) {
          updatePayload.avatarUrl = firebaseUser.photoURL;
          needsUpdate = true;
        }
        if (isGoldProvider(isGoogle || isApple) && !u.authProvider) {
          updatePayload.authProvider = isGoogle ? 'google' : 'apple';
          needsUpdate = true;
        }
        if (needsUpdate) {
          await setDoc(userDocRef, updatePayload, { merge: true }).catch(err => {
            console.warn("[AUTH CONTEXT] Failed to write updated payload to Firestore. Skipping Cloud sync.", err);
          });
          Object.assign(u, updatePayload);
        }
        return u;
      } else {
        // Automatically initialize document for new users (including Google/Apple auth) -> Free by default
        const initialUser: User = {
          id: firebaseUser.uid,
          name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Athlete',
          email: firebaseUser.email || '',
          subscriptionPlan: 'free',
          subscriptionStatus: 'inactive',
          paymentStatus: 'unpaid',
          paymentDate: '',
          subscriptionStartDate: '',
          subscriptionEndDate: '',
          transactionId: '',
          isVerified: !!firebaseUser.emailVerified,
          fitnessGoals: [],
          currentWeight: 80,
          targetWeight: 75,
          height: 180,
          age: 25,
          gender: 'Not specified',
          activityLevel: 'Not specified',
          authProvider: isGoogle ? 'google' : (isApple ? 'apple' : 'password'),
          createdAt: new Date().toISOString()
        };
        if (firebaseUser.photoURL) {
          initialUser.avatarUrl = firebaseUser.photoURL;
        }
        await setDoc(userDocRef, initialUser).catch(err => {
          console.warn("[AUTH CONTEXT] Failed to initialize Firestore user document. Caching to fallback storage.", err);
          localStorage.setItem(`alexfit_user_fallback_${firebaseUser.uid}`, JSON.stringify(initialUser));
        });
        return initialUser;
      }
    } catch (err) {
      console.error('[AUTH CONTEXT] Failed to fetch user profile from Firestore, using smart local fallback context.', err);
      const isGoogle = firebaseUser.providerData[0]?.providerId === 'google.com';
      const isApple = firebaseUser.providerData[0]?.providerId === 'apple.com';
      const cached = localStorage.getItem(`alexfit_user_fallback_${firebaseUser.uid}`);
      if (cached) {
        try {
          return JSON.parse(cached);
        } catch (_) {}
      }
      const fallbackUser: User = {
        id: firebaseUser.uid,
        name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Athlete',
        email: firebaseUser.email || '',
        subscriptionPlan: 'free',
        subscriptionStatus: 'inactive',
        paymentStatus: 'unpaid',
        paymentDate: '',
        subscriptionStartDate: '',
        subscriptionEndDate: '',
        transactionId: '',
        isVerified: true,
        fitnessGoals: [],
        currentWeight: 80,
        targetWeight: 75,
        height: 180,
        age: 25,
        gender: 'Not specified',
        activityLevel: 'Not specified',
        authProvider: isGoogle ? 'google' : (isApple ? 'apple' : 'password'),
        createdAt: new Date().toISOString()
      };
      if (firebaseUser.photoURL) {
        fallbackUser.avatarUrl = firebaseUser.photoURL;
      }
      localStorage.setItem(`alexfit_user_fallback_${firebaseUser.uid}`, JSON.stringify(fallbackUser));
      return fallbackUser;
    }
  };

  // Safe provider classification helper
  function isGoldProvider(isSocial: boolean): boolean {
    return isSocial;
  }

  const refreshUser = async () => {
    if (auth.currentUser) {
      const u = await fetchProfile(auth.currentUser);
      setUser(u);
    } else {
      setUser(null);
    }
  };

  useEffect(() => {
    // Audit check: Check if page came from redirect flow and retrieve result/errors
    getRedirectResult(auth)
      .then((result) => {
        if (result?.user) {
          console.log("[AUTH CONTEXT SUCCESS] Deployed environment redirect login resolved successfully for:", result.user.email);
        }
      })
      .catch((err: any) => {
        console.error("[AUTH CONTEXT ERROR] Deployed environment redirect login error trace:", err);
        setRedirectError(err.message || String(err));
      });

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setLoading(true);
      if (firebaseUser) {
        const u = await fetchProfile(firebaseUser);
        setUser(u);
        try {
          await apiFetch('/api/auth/sync-session', {
            method: 'POST',
            body: JSON.stringify({
              id: firebaseUser.uid,
              email: firebaseUser.email,
              name: firebaseUser.displayName || u?.name || 'Athlete',
              isVerified: !!firebaseUser.emailVerified,
              avatarUrl: firebaseUser.photoURL || u?.avatarUrl || '',
              authProvider: u?.authProvider || 'password'
            })
          });
        } catch (syncErr) {
          console.warn("[AUTH CONTEXT] Express session sync was skipped:", syncErr);
        }
      } else {
        setUser(null);
        try {
          await apiFetch('/api/auth/logout', { method: 'POST' });
        } catch (logoutErr) {
          console.warn("[AUTH CONTEXT] Express logout cookie clearing failed:", logoutErr);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  function cleanUndefined<T extends object>(obj: T): T {
    const result: any = {};
    for (const [key, value] of Object.entries(obj)) {
      if (value !== undefined) {
        result[key] = value;
      }
    }
    return result;
  }

  const updateProfile = async (data: Partial<User>) => {
    if (!auth.currentUser) {
      if (user) {
        const updated = { ...user, ...data };
        setUser(updated);
      }
      return;
    }
    
    try {
      const userDocRef = doc(db, 'users', auth.currentUser!.uid);
      const cleanedData = cleanUndefined(data);
      await setDoc(userDocRef, cleanedData, { merge: true }).catch(err => {
        console.warn("[AUTH CONTEXT] Firestore write blocked during update. Baking local backup cache.");
        localStorage.setItem(`alexfit_user_fallback_${auth.currentUser!.uid}`, JSON.stringify({ ...user, ...cleanedData }));
      });
      setUser(prev => prev ? { ...prev, ...cleanedData } : null);
    } catch (err) {
      console.error('[AUTH CONTEXT] Update biometrics profile failed', err);
      throw err;
    }
  };

  const loginWithEmail = async (email: string, password: string) => {
    const cred = await signInWithEmailAndPassword(auth, email, password);
    return cred.user;
  };

  const signUpWithEmail = async (email: string, password: string, name: string) => {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    // Initialize profile
    const initialUser: User = {
      id: cred.user.uid,
      name,
      email,
      subscriptionPlan: 'free',
      subscriptionStatus: 'inactive',
      paymentStatus: 'unpaid',
      paymentDate: '',
      subscriptionStartDate: '',
      subscriptionEndDate: '',
      transactionId: '',
      isVerified: false,
      fitnessGoals: [],
      currentWeight: 80,
      targetWeight: 75,
      height: 180,
      age: 25,
      gender: 'Not specified',
      activityLevel: 'Not specified',
    };
    try {
      await setDoc(doc(db, 'users', cred.user.uid), initialUser);
    } catch (err) {
      console.warn("[AUTH CONTEXT] Failed to write signup initialUser to Firestore. Saving to fallback storage.", err);
      localStorage.setItem(`alexfit_user_fallback_${cred.user.uid}`, JSON.stringify(initialUser));
    }
    return cred.user;
  };

  const loginWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({
      prompt: 'select_account'
    });
    try {
      const cred = await signInWithPopup(auth, provider);
      return cred.user;
    } catch (err: any) {
      if (
        err.code === 'auth/popup-blocked' ||
        err.code === 'auth/popup-blocked-by-browser' ||
        err.message?.includes('popup') ||
        err.message?.includes('blocked')
      ) {
        console.warn("[AUTH CONTEXT] Google login pop-up was blocked by browser settings. Automatically falling back to secure redirect flow...");
        await signInWithRedirect(auth, provider);
        return new Promise<FirebaseUser>(() => {});
      }
      throw err;
    }
  };

  const loginWithGoogleRedirect = async () => {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({
      prompt: 'select_account'
    });
    await signInWithRedirect(auth, provider);
  };

  const loginWithApple = async () => {
    const provider = new OAuthProvider('apple.com');
    provider.addScope('email');
    provider.addScope('name');
    
    // Support dynamic account linking: If a user is already signed in (e.g. from password or Google),
    // and calls loginWithApple, securely link the Apple OAuth identity to their active account.
    if (auth.currentUser) {
      const { linkWithPopup } = await import('firebase/auth');
      try {
        const cred = await linkWithPopup(auth.currentUser, provider);
        
        // Update profile synchronization flags in database
        const userDocRef = doc(db, 'users', auth.currentUser.uid);
        await setDoc(userDocRef, { authProvider: 'apple' }, { merge: true }).catch((err) => {
          console.warn("[AUTH CONTEXT] Failed to update linked provider trace in Firestore database:", err);
        });
        
        return cred.user;
      } catch (err: any) {
        if (
          err.code === 'auth/popup-blocked' ||
          err.code === 'auth/popup-blocked-by-browser' ||
          err.message?.includes('popup') ||
          err.message?.includes('blocked')
        ) {
          console.warn("[AUTH CONTEXT] Apple link pop-up was blocked by browser settings. Automatically falling back to secure link-with-redirect flow...");
          const { linkWithRedirect } = await import('firebase/auth');
          await linkWithRedirect(auth.currentUser, provider);
          return new Promise<FirebaseUser>(() => {});
        }
        throw err;
      }
    } else {
      try {
        const cred = await signInWithPopup(auth, provider);
        return cred.user;
      } catch (err: any) {
        if (
          err.code === 'auth/popup-blocked' ||
          err.code === 'auth/popup-blocked-by-browser' ||
          err.message?.includes('popup') ||
          err.message?.includes('blocked')
        ) {
          console.warn("[AUTH CONTEXT] Apple login pop-up was blocked by browser settings. Automatically falling back to secure redirect flow...");
          await signInWithRedirect(auth, provider);
          return new Promise<FirebaseUser>(() => {});
        }
        throw err;
      }
    }
  };

  const resetPassword = async (email: string) => {
    try {
      const continueUrl = getValidContinueUri('/auth/login');
      const actionCodeSettings = {
        url: continueUrl,
        handleCodeInApp: false,
      };
      await sendPasswordResetEmail(auth, email, actionCodeSettings);
    } catch (err: any) {
      console.warn("[AUTH CONTROLLER] Custom continue URL rejected or threw an error. Falling back to secure default hosted action flow.", err);
      try {
        await sendPasswordResetEmail(auth, email);
      } catch (fallbackErr: any) {
        console.error("[AUTH CONTROLLER] Both custom and default password reset attempts failed:", fallbackErr);
        throw fallbackErr;
      }
    }
  };

  const sendVerification = async () => {
    if (auth.currentUser) {
      const email = auth.currentUser.email || '';
      try {
        const continueUrl = getValidContinueUri(`/verify-email?email=${encodeURIComponent(email)}`);
        const actionCodeSettings = {
          url: continueUrl,
          handleCodeInApp: false,
        };
        await sendEmailVerification(auth.currentUser, actionCodeSettings);
      } catch (err: any) {
        console.warn("[AUTH CONTROLLER] Custom verification continue URL rejected or threw an error. Falling back to secure default hosted action flow.", err);
        try {
          await sendEmailVerification(auth.currentUser);
        } catch (fallbackErr: any) {
          console.error("[AUTH CONTROLLER] Both custom and default email verification attempts failed:", fallbackErr);
          throw fallbackErr;
        }
      }
    } else {
      throw new Error("No active user to verify.");
    }
  };

  const logout = async () => {
    await signOut(auth).catch(() => {});
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      loading, 
      redirectError,
      refreshUser, 
      updateProfile, 
      logout,
      loginWithEmail,
      signUpWithEmail,
      loginWithGoogle,
      loginWithGoogleRedirect,
      loginWithApple,
      resetPassword,
      sendVerification
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
