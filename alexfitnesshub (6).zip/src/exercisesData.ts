export interface DetailedExercise {
  id: string;
  name: string;
  category: 'gym' | 'home' | 'calisthenics' | 'cardio' | 'functional' | 'military' | 'athletic' | 'yoga' | 'pilates';
  muscleGroup: 'chest' | 'back' | 'shoulders' | 'arms' | 'legs' | 'core' | 'fullbody' | 'cardio' | 'flexibility';
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  primaryMuscles: string;
  secondaryMuscles: string;
  equipment: string;
  instructions: string[];
  mistakes: string[];
  benefits: string[];
  safetyTips: string[];
  beginnerVersion: string;
  advancedVersion: string;
  recommendedSets: {
    fatLoss: string;
    muscleGrowth: string;
    strength: string;
    endurance: string;
  };
  recommendedReps: {
    fatLoss: string;
    muscleGrowth: string;
    strength: string;
    endurance: string;
  };
  restTime: string;
  videoUrl: string;
  imageUrl: string;
  anatomyIllustration: string;
}

export const DETAILED_EXERCISES: DetailedExercise[] = [
  // --- GYM - CHEST ---
  {
    id: "gym-chest-1",
    name: "Barbell Bench Press",
    category: "gym",
    muscleGroup: "chest",
    difficulty: "Intermediate",
    primaryMuscles: "Pectoralis Major (Lower & Mid Sternal Head)",
    secondaryMuscles: "Anterior Deltoids, Triceps Brachii, Serratus Anterior",
    equipment: "Barbell & Flat Bench",
    instructions: [
      "Lie flat on the bench, pulling your scapula backwards and pressing your chest outwards.",
      "Plant both feet firmly into the floor about shoulder-width apart.",
      "Grip the barbell with a pronated, secure grip slightly wider than shoulder-width.",
      "Unrack the barbell, holding it directly above your chest with locked elbows.",
      "Inhale deeply, and slowly lower the barbell down until it gently brushes your mid-chest.",
      "Explode upwards by actively squeezing your chest muscles, expelling air, and returning to high lock."
    ],
    mistakes: [
      "Flaring elbows out to 90 degrees, raising rotator cuff impingement risks.",
      "Bouncing the bar forcefully off the sternum.",
      "Raising the hips or buttocks completely off the bench during the press."
    ],
    benefits: [
      "Maximum upper body mechanical muscular hypertrophy.",
      "Improves bone density in the shoulder girdle and arms.",
      "Builds massive pushing power and tricep mechanical torque."
    ],
    safetyTips: [
      "Always lift with a safety spotter or inside a robust power rack with safety pins.",
      "Maintain a subtle natural arch in the lower spine—do not over-flex.",
      "Ensure thumb is wrapped around the bar; avoid the dangerous suicide grip."
    ],
    beginnerVersion: "Dumbbell Floor Press (restricts shoulder hyperextension)",
    advancedVersion: "Incline Barbell Bench Press with dynamic resistance bands",
    recommendedSets: { fatLoss: "3-4", muscleGrowth: "3-5", strength: "4-6", endurance: "2-4" },
    recommendedReps: { fatLoss: "12-15", muscleGrowth: "8-12", strength: "3-6", endurance: "15-25" },
    restTime: "90 - 180 seconds",
    videoUrl: "https://www.youtube.com/shorts/Gf65Yy0-wGI?feature=share",
    imageUrl: "https://fitnessprogramer.com/wp-content/uploads/2021/02/Barbell-Bench-Press.gif",
    anatomyIllustration: "Pectoralis major, anterior deltoid fibers, and epicranial tricep fascia."
  },
  {
    id: "gym-chest-2",
    name: "Incline Dumbbell Press",
    category: "gym",
    muscleGroup: "chest",
    difficulty: "Intermediate",
    primaryMuscles: "Clavicular Head of Pectoralis Major (Upper Chest)",
    secondaryMuscles: "Anterior Deltoids, Triceps Brachii",
    equipment: "Incline Bench & Dumbbells",
    instructions: [
      "Set an incline bench to an angle of approximately 30 to 45 degrees.",
      "Sit back firmly, holding a pair of heavy dumbbells in your lap.",
      "Kick the dumbbells up sequentially to shoulder level as you lean back.",
      "Start with palms facing forward, elbows tucked at a 45-degree angle.",
      "Press dumbbells upward towards the ceiling, squeezing upper chest fibers.",
      "Control the dumbbells back down slowly until they are parallel with your chest."
    ],
    mistakes: [
      "Setting the inclinability too steep (over 45 degrees targets front shoulders).",
      "Clashing the dumbbells together at the top, losing tension."
    ],
    benefits: [
      "Direct structural targeting of upper shelf chest development.",
      "Eliminates muscle imbalances through unilateral dumbbell stabilization."
    ],
    safetyTips: [
      "Keep feet locked flat on the floor to stabilize hip position.",
      "Discard dumbbells safely to the side if muscular failure occurs."
    ],
    beginnerVersion: "Incline Smith Machine Press",
    advancedVersion: "Incline Dumbbell Press with a deep twist at bottom of contraction",
    recommendedSets: { fatLoss: "3-4", muscleGrowth: "3-5", strength: "3-5", endurance: "2-4" },
    recommendedReps: { fatLoss: "12-15", muscleGrowth: "8-12", strength: "5-8", endurance: "15-20" },
    restTime: "60 - 90 seconds",
    videoUrl: "https://youtu.be/oZVCBM9f8Eo",
    imageUrl: "https://fitnessprogramer.com/wp-content/uploads/2021/02/Incline-Dumbbell-Press.gif",
    anatomyIllustration: "Upper Clavicular Pectoralis fibers with anterior scapular attachments."
  },
  {
    id: "gym-chest-3",
    name: "Pec Dec Machine Fly",
    category: "gym",
    muscleGroup: "chest",
    difficulty: "Beginner",
    primaryMuscles: "Pectoralis Major (Sternal Fibers), Sternal Division",
    secondaryMuscles: "Anterior Deltoid, Coracobrachialis",
    equipment: "Pec Dec Machine",
    instructions: [
      "Adjust the seat so your elbows are resting slightly below shoulder height.",
      "Sit back tightly with your shoulder blades fully retracted into the pad.",
      "Grip the handles, placing your forearms parallel directly against the arm pads.",
      "Bring the handles/pads together in a fluid, wide arc, squeezing your chest.",
      "Hold peak contraction for 1-2 seconds with intense focus.",
      "Slowly allow the machine to return outward to stretch the chest fibers."
    ],
    mistakes: [
      "Allowing the weight stack to slam at the bottom of the movement.",
      "Allowing shoulders to roll forward at the peak of the squeeze."
    ],
    benefits: [
      "Isolates the chest muscle without using stabilizing joints.",
      "Safe and highly effective for training close to complete muscular failure."
    ],
    safetyTips: [
      "Do not stretch backwards too far if you have history of shoulder instability.",
      "Keep the head pressed back against the support cushion."
    ],
    beginnerVersion: "Flat Bench Dumbbell Fly",
    advancedVersion: "Pec Dec Fly with 3-second isometric holds at the maximum squeeze",
    recommendedSets: { fatLoss: "3-4", muscleGrowth: "3-5", strength: "2-3", endurance: "3-4" },
    recommendedReps: { fatLoss: "12-15", muscleGrowth: "10-15", strength: "8-10", endurance: "20-25" },
    restTime: "60 seconds",
    videoUrl: "https://youtu.be/ojEPc8qr7V8",
    imageUrl: "https://fitnessprogramer.com/wp-content/uploads/2021/02/Pec-Deck-Fly.gif",
    anatomyIllustration: "Inner pectoralis major split fibers, sternal head."
  },

  // --- GYM - BACK ---
  {
    id: "gym-back-1",
    name: "Bent-Over Barbell Row",
    category: "gym",
    muscleGroup: "back",
    difficulty: "Intermediate",
    primaryMuscles: "Latissimus Dorsi, Rhomboids, Trapezius (Mid/Lower)",
    secondaryMuscles: "Rear Deltoid, Biceps Brachii, Erector Spinae",
    equipment: "Barbell & Heavy Plates",
    instructions: [
      "Hold the barbell with an overhand or underhand grip, shoulder-width apart.",
      "Hinge forward at the hips, keeping your chest up and lower back totally flat.",
      "Extend your arms fully to let the barbell hang towards your shins.",
      "Pull the barbell up toward your lower stomach, pulling from your elbows.",
      "Squeeze your mid-back at the top contraction.",
      "Slowly lower the barbell back down with full control."
    ],
    mistakes: [
      "Rounding the lower spine, risking lumbar injury.",
      "Using excessive body momentum or swinging torso up and down."
    ],
    benefits: [
      "Builds an immense, thick back and wide Latissimus silhouette.",
      "Reinforces core stabilization and spinal erectors stamina."
    ],
    safetyTips: [
      "Ensure core is actively engaged like a belt throughout the movement.",
      "If lower back aches, reduce the load immediately."
    ],
    beginnerVersion: "Chest-Supported Dumbbell Row",
    advancedVersion: "Pendlay Row (Dead stop from the floor on every rep)",
    recommendedSets: { fatLoss: "3-4", muscleGrowth: "3-5", strength: "4-6", endurance: "2-4" },
    recommendedReps: { fatLoss: "12-15", muscleGrowth: "8-12", strength: "5-8", endurance: "15-20" },
    restTime: "90 seconds",
    videoUrl: "https://youtu.be/SR6T41uBVeM",
    imageUrl: "https://media.tenor.com/AYJ_bNXDvoUAAAAM/workout-muscles.gif",
    anatomyIllustration: "Rhomboids, Middle Trapezius, and Latissimus Dorsi expansion fibers."
  },
  {
    id: "gym-back-2",
    name: "Classic Barbell Deadlift",
    category: "gym",
    muscleGroup: "back",
    difficulty: "Advanced",
    primaryMuscles: "Posterior Chain (Erector Spinae, Gluteus Maximus, Hamstrings)",
    secondaryMuscles: "Latissimus Dorsi, Trapezius, Quadriceps, Core, Grip",
    equipment: "Olympic Barbell & Bumper Plates",
    instructions: [
      "Walk up to the bar; shins should be about 1 inch away from the barbell.",
      "Hinge at the hips and bend knees slightly, gripping the bar securely.",
      "Ensure lower spine is flat, shoulder blades directly over the barbell.",
      "Engage your lats, push the floor away dynamically through your midfoot.",
      "Drive hips forward to stand straight, locking out hips and knees cleanly.",
      "Hinge the hips backwards first to lower the bar back to the floor smoothly."
    ],
    mistakes: [
      "Rounding the back during the heavy pull, risking disk herniation.",
      "Shrugging or hyperextending the spine at the lockout."
    ],
    benefits: [
      "The undisputed king of physical power development.",
      "Engages almost every skeletal muscle in the human body."
    ],
    safetyTips: [
      "Always pull flat-footed—do not lift heels off the ground.",
      "Ditch mixed grip for double overhand if training general strength over pure competition specs."
    ],
    beginnerVersion: "Kettlebell Deadlift, Hex-Bar Deadlift",
    advancedVersion: "Deficit Barbell Deadlift (standing on flat plates)",
    recommendedSets: { fatLoss: "3", muscleGrowth: "3-4", strength: "4-6", endurance: "2" },
    recommendedReps: { fatLoss: "8-10", muscleGrowth: "5-8", strength: "1-5", endurance: "12-15" },
    restTime: "120 - 240 seconds",
    videoUrl: "https://youtu.be/yPqv3ejnZvc",
    imageUrl: "https://fitnessprogramer.com/wp-content/uploads/2021/02/Barbell-Deadlift.gif",
    anatomyIllustration: "Erector spinae column, gluteus complex, biceps femoris."
  },

  // --- GYM - SHOULDERS ---
  {
    id: "gym-shoulders-1",
    name: "Dumbbell Lateral Raise",
    category: "gym",
    muscleGroup: "shoulders",
    difficulty: "Beginner",
    primaryMuscles: "Lateral Deltoids (Side Shoulders)",
    secondaryMuscles: "Anterior Deltoids, Trapezius Upper, Supraspinatus",
    equipment: "Dumbbells",
    instructions: [
      "Stand tall, holding a dumbbell in each hand, palms facing inwards.",
      "Lean forward 5 degrees, and let your arms hang with a slight flex in the elbows.",
      "Raise your arms out to the sides in a wide arc, leading with your elbows.",
      "Raise dumbbells until they are level with your shoulders.",
      "Control the dumbbells back down slowly to stop them before touching hips."
    ],
    mistakes: [
      "Using heavy momentum, swinging the weights upwards using the lower back.",
      "Lifting hands higher than elbows (rotates arm internally, stressing joints)."
    ],
    benefits: [
      "Widens the shoulder silhouette for the highly sought-after V-taper physique.",
      "Direct isolation training for the lateral deltoid fibers."
    ],
    safetyTips: [
      "Avoid lifting weights taller than shoulder height.",
      "Use extremely modest weights—form dictates results over mass here."
    ],
    beginnerVersion: "Seated Cable Lateral Raise",
    advancedVersion: "Leaning Dumbbell Lateral Raise (unilateral, increased stretch range)",
    recommendedSets: { fatLoss: "3-4", muscleGrowth: "3-5", strength: "2-3", endurance: "3-4" },
    recommendedReps: { fatLoss: "12-15", muscleGrowth: "10-15", strength: "8-10", endurance: "20-30" },
    restTime: "45 - 60 seconds",
    videoUrl: "https://youtu.be/XPPfnSEATJA",
    imageUrl: "https://fitnessprogramer.com/wp-content/uploads/2021/02/Dumbbell-Lateral-Raise.gif",
    anatomyIllustration: "Lateral clavicular deltoid fascia."
  },

  // --- GYM - ARMS ---
  {
    id: "gym-arms-1",
    name: "Barbell Bicep Curl",
    category: "gym",
    muscleGroup: "arms",
    difficulty: "Beginner",
    primaryMuscles: "Biceps Brachii (Short Head & Long Head)",
    secondaryMuscles: "Brachialis, Brachioradialis, Forearm Flexors",
    equipment: "Barbell / EZ bar",
    instructions: [
      "Stand upright holding a barbell with an underhand grip, shoulder-width apart.",
      "Keep your elbows pressed firmly near the sides of your ribcage.",
      "Curl the bar upward toward your shoulders by flexing only at the elbows.",
      "Squeeze your biceps tightly at the top contraction point.",
      "Slowly lower the barbell down until your arms are fully extended."
    ],
    mistakes: [
      "Swinging the weight by leaning backwards at the waist.",
      "Letting elbows drift forward, bringing shoulders into the lift."
    ],
    benefits: [
      "Extreme bicep peak development and forearm structural strength.",
      "Builds robust elbow joint integrity for heavy deadlifts."
    ],
    safetyTips: [
      "Stand flat-footed with a neutral chest posture.",
      "Do not swing—keep your core zipped up tightly."
    ],
    beginnerVersion: "Dumbbell Hammer Curl",
    advancedVersion: "Incline Bicep Dumbbell Curl (deepest eccentric stretch possible)",
    recommendedSets: { fatLoss: "3-4", muscleGrowth: "3-5", strength: "2-4", endurance: "2-4" },
    recommendedReps: { fatLoss: "12-15", muscleGrowth: "8-12", strength: "6-8", endurance: "15-25" },
    restTime: "60 - 75 seconds",
    videoUrl: "https://youtu.be/ZQWL7omZh94",
    imageUrl: "https://fitnessprogramer.com/wp-content/uploads/2021/02/Barbell-Curl.gif",
    anatomyIllustration: "Biceps brachii long head, short head, brachialis tendon."
  },

  // --- GYM - LEGS ---
  {
    id: "gym-legs-1",
    name: "Barbell Back Squat",
    category: "gym",
    muscleGroup: "legs",
    difficulty: "Advanced",
    primaryMuscles: "Quadriceps Femoris, Gluteus Maximus",
    secondaryMuscles: "Hamstrings, Calves, Erector Spinae, Abdominals",
    equipment: "Olympic Barbell & Squat Rack",
    instructions: [
      "Rest the barbell on your upper trapezius muscles (avoid resting it on bony vertebrae).",
      "Stand with feet slightly wider than shoulder-width, toes turned outward slightly.",
      "Hinge at the hips and bend knees simultaneously, sitting back to lower your body.",
      "Keep your chest upright and gaze forward.",
      "Drop until your thighs go parallel or deeper into a full squat.",
      "Drive back upward by pushing hard through the center of your feet."
    ],
    mistakes: [
      "Allowing knees to cave inward during the push (valgus collapse).",
      "Allowing absolute heel elevation, shifting load entirely onto kneecaps."
    ],
    benefits: [
      "The premier lower body hyper-trophy builder.",
      "Triggers high natural hormone activation due to massive muscular tension."
    ],
    safetyTips: [
      "Never look down—look forward to keep spinal column natural.",
      "Perform with safety rack bars deployed."
    ],
    beginnerVersion: "Goblet Squat with a single dumbbell at the chest",
    advancedVersion: "Barbell Front Squat (shifted quadriceps emphasis)",
    recommendedSets: { fatLoss: "3-4", muscleGrowth: "3-5", strength: "4-6", endurance: "2-4" },
    recommendedReps: { fatLoss: "12-15", muscleGrowth: "8-12", strength: "3-6", endurance: "15-25" },
    restTime: "120 - 180 seconds",
    videoUrl: "https://youtu.be/-bJIpOq-LWk",
    imageUrl: "https://fitnessprogramer.com/wp-content/uploads/2021/02/BARBELL-SQUAT.gif",
    anatomyIllustration: "Quadriceps rectus femoris, vastus lateralis, medialis, and gluteus maximus."
  },

  // --- HOME WORKOUTS (BODYWEIGHT) ---
  {
    id: "home-1",
    name: "Classic Floor Push-Up",
    category: "home",
    muscleGroup: "chest",
    difficulty: "Beginner",
    primaryMuscles: "Pectoralis Major, Triceps Brachii, Anterior Deltoid",
    secondaryMuscles: "Rectus Abdominis, Serratus Anterior",
    equipment: "None (Bodyweight)",
    instructions: [
      "Place your hands on the floor slightly wider than shoulder-width, fingers pointed forward.",
      "Extend your legs back so you are in a straight-line plank posture.",
      "Keeping your body straight, slowly bend your elbows to lower your chest nearly to the floor.",
      "Do not let the hips sag; keep your core contracted.",
      "Push forcefully away from the floor, returning to front high extension lock."
    ],
    mistakes: [
      "Flaring elbows out horizontally to 90 degrees.",
      "Sagging hips or hyperextending the neck."
    ],
    benefits: [
      "Classic builder for chest, front shoulders, and core stamina.",
      "Convenient—can be done anywhere, anytime without equipment."
    ],
    safetyTips: [
      "Keep hands flat on floor; squeeze abdominal wall to protect lower spine.",
      "Keep shoulders depressed and packed."
    ],
    beginnerVersion: "Incline Push-Ups against a heavy table or bench",
    advancedVersion: "Decline Push-Ups, Diamond Pushups",
    recommendedSets: { fatLoss: "3-4", muscleGrowth: "3-5", strength: "3-4", endurance: "3-5" },
    recommendedReps: { fatLoss: "15-20", muscleGrowth: "12-15", strength: "8-12", endurance: "25-40" },
    restTime: "45 seconds",
    videoUrl: "https://youtu.be/WDIpL0pjun0",
    imageUrl: "https://i.pinimg.com/originals/48/da/79/48da79042a1a23b3060e4fa684b8af90.gif",
    anatomyIllustration: "Anterior pectoralis and tricep long head fascia."
  },
  {
    id: "home-2",
    name: "Air Squats",
    category: "home",
    muscleGroup: "legs",
    difficulty: "Beginner",
    primaryMuscles: "Quadriceps, Gluteus Maximus, Hamstrings",
    secondaryMuscles: "Adductors, Calves, Core",
    equipment: "None (Bodyweight)",
    instructions: [
      "Stand with feet shoulder-width apart, arms raised forward.",
      "Sit back with your hips, keeping your heels flat and back flat.",
      "Lower yourself until your hips drop beneath parallel line.",
      "Squeeze your glutes, push up back to standing."
    ],
    mistakes: [
      "Heels leaving the floor.",
      "Allowing upper torso to fold forward."
    ],
    benefits: [
      "Excellent active recovery, conditioning, and joint resilience.",
      "Builds foundation depth pattern mobility."
    ],
    safetyTips: [
      "Do not collapse knees together.",
      "Keep weight in midfoot."
    ],
    beginnerVersion: "Box Chair Squats (squatting down to a chair)",
    advancedVersion: "Bulgarian Split Squat, Jump Squats",
    recommendedSets: { fatLoss: "3", muscleGrowth: "3-4", strength: "2", endurance: "4-5" },
    recommendedReps: { fatLoss: "20-25", muscleGrowth: "15-20", strength: "10-12", endurance: "30-50" },
    restTime: "30 - 45 seconds",
    videoUrl: "https://youtu.be/iiKn5FiVUjI",
    imageUrl: "https://www.inspireusafoundation.org/wp-content/uploads/2021/06/bodyweight-squat-2.gif",
    anatomyIllustration: "Femoris vastus lateral, glutes complex."
  },

  // --- CALISTHENICS ---
  {
    id: "calisthenics-1",
    name: "Hardcore Bar Muscle-Up",
    category: "calisthenics",
    muscleGroup: "fullbody",
    difficulty: "Advanced",
    primaryMuscles: "Latissimus Dorsi, Triceps Brachii, Pectoralis Major, Core",
    secondaryMuscles: "Deltoids, Grip, Forearms, Rhomboids",
    equipment: "High Pull-Up Bar",
    instructions: [
      "Hang from the high bar with a false grip (palms resting over the top of the bar).",
      "Perform a slight kip pull back to create horizontal leverage clearance.",
      "Pull aggressively upward and downward, driving your hips towards the bar.",
      "Quickly roll your torso forward over the bar, transitioning elbows from pull to push.",
      "Press your body fully upright, locking out your triceps on the top bar dip."
    ],
    mistakes: [
      "Using a standard grip instead of a false grip, blocking transition.",
      "Relying entirely on jerky leg kicks rather than explosive upper back velocity."
    ],
    benefits: [
      "The gold standard calisthenics test of upper body multi-joint power.",
      "Combines explosive pulling power and bodyweight dipping strength."
    ],
    safetyTips: [
      "Warm up wrists and shoulder capsules thoroughly beforehand.",
      "Ensure bar is securely anchored and cannot wobble."
    ],
    beginnerVersion: "Kipping Pull-ups + Static Bar Dips",
    advancedVersion: "Strict Slow Control Muscle-Up (no leg swing or kip)",
    recommendedSets: { fatLoss: "2-3", muscleGrowth: "3", strength: "4-6", endurance: "2" },
    recommendedReps: { fatLoss: "5-8", muscleGrowth: "5-8", strength: "1-4", endurance: "8-12" },
    restTime: "120 seconds",
    videoUrl: "https://youtu.be/KweCZJlwCw0",
    imageUrl: "https://fitnessprogramer.com/wp-content/uploads/2021/03/Chin-Up.gif",
    anatomyIllustration: "Shoulder dynamic stabilizers, latissimus and chest integration."
  },

  // --- CARDIO ---
  {
    id: "cardio-1",
    name: "Treadmill Hill Incline HIIT",
    category: "cardio",
    muscleGroup: "cardio",
    difficulty: "Intermediate",
    primaryMuscles: "Cardiopulmonary System, Calves, Gluteals",
    secondaryMuscles: "Hamstrings, Quadriceps, Arch system",
    equipment: "Treadmill",
    instructions: [
      "Warm up for 5 minutes at flat incline, 4.5 km/h walking speed.",
      "Elevate the incline to 12% and sprint or fast walk upwards.",
      "Hold high speed for 30-45 seconds of absolute heart-rate max.",
      "Lower incline back to 2% and slow walk for 60 seconds of recovery interval.",
      "Repeat the cycle 10 times."
    ],
    mistakes: [
      "Leaning heavily and hanging onto the treadmill side rails.",
      "Slouching shoulders or failing to walk upright."
    ],
    benefits: [
      "Violent fat-burning caloric expenditure and aerobic gas kinetics.",
      "Improves ankle stamina and calves without joint pressure."
    ],
    safetyTips: [
      "Always clip the safety emergency stopper cord to your shirt.",
      "Stay in the center of the treadmill rubber belt."
    ],
    beginnerVersion: "Flat walking or modest 3-5% treadmill incline walking",
    advancedVersion: "Weighted Vest 12-3-30 Protocol",
    recommendedSets: { fatLoss: "4", muscleGrowth: "2", strength: "2", endurance: "5" },
    recommendedReps: { fatLoss: "30 Minutes", muscleGrowth: "15 Minutes", strength: "15 Minutes", endurance: "45 Minutes" },
    restTime: "60 seconds raw walking",
    videoUrl: "https://www.youtube.com/shorts/eJ8SS5V6wBk?feature=share",
    imageUrl: "https://fitnessprogramer.com/wp-content/uploads/2021/06/Treadmill-.gif",
    anatomyIllustration: "Cardiorespiratory lung capacity, vascular expansion nodes."
  },

  // --- FUNCTIONAL FITNESS ---
  {
    id: "functional-1",
    name: "Heavy Farmers Walk",
    category: "functional",
    muscleGroup: "fullbody",
    difficulty: "Beginner",
    primaryMuscles: "Forearm Flexors (Grip Strength), Trapezius, Core",
    secondaryMuscles: "Gluteus Complex, Calves, Tibialis",
    equipment: "Heavy Kettlebells or Heavy Dumbbells",
    instructions: [
      "Squat down cleanly with a flat back and grip two heavy dumbbells.",
      "Stand fully upright, locking your shoulders back and chest outwards.",
      "Walk forward in short, controlled, heel-to-toe steps.",
      "Keep your abdominal wall contracted like a corset to protect your spine.",
      "Walk for 50-100 meters per round."
    ],
    mistakes: [
      "Allowing shoulders to slump forward during the walk.",
      "Taking excessively wide or fast unstable running steps."
    ],
    benefits: [
      "Crushing grip strength and steel-plated upper back development.",
      "Direct athletic hip stabilization transfer to running."
    ],
    safetyTips: [
      "Place the weights down flat on the floor before you release your grip.",
      "Keep path clear of obstacles."
    ],
    beginnerVersion: "Lighter Dumbbell Farmer Walks",
    advancedVersion: "One-Sided Suitcase Carry (extreme lateral obliquity stress)",
    recommendedSets: { fatLoss: "3", muscleGrowth: "3-4", strength: "4-5", endurance: "3-4" },
    recommendedReps: { fatLoss: "60-sec carry", muscleGrowth: "45-sec heavy carry", strength: "30-sec max carry", endurance: "120-sec walk" },
    restTime: "90 seconds",
    videoUrl: "https://youtu.be/8OtwXwrJizk",
    imageUrl: "https://liftmanual.com/wp-content/uploads/2023/04/farmers-walk.gif",
    anatomyIllustration: "Wrist forearm extensors, spinal erector complex and traps."
  },

  // --- MILITARY FITNESS ---
  {
    id: "military-1",
    name: "Combat Loaded Carry Ruck",
    category: "military",
    muscleGroup: "fullbody",
    difficulty: "Advanced",
    primaryMuscles: "Cardiorespiratory Stamina, Posterior Chain, Trapezius",
    secondaryMuscles: "Plantar Fascia, Quadriceps, Core stability",
    equipment: "Heavy Weighted Backpack (Ruck) or Vest",
    instructions: [
      "Load a backpack with 15kg to 30kg of flat weights/sandbags.",
      "Strap the bag tightly against your torso, minimizing any sliding motion.",
      "Walk or jog at a continuous, steady tempo over rugged terrain.",
      "Maintain a forward-leaning posture from the ankles, not the hips."
    ],
    mistakes: [
      "Leaning solely at the waist, placing painful shear force on the lumbar.",
      "Allowing rucksack to bounce aggressively in an unsecured posture."
    ],
    benefits: [
      "Builds robust conditioning and hard-wearing joint structures.",
      "Trains tactical endurance used by elite forces worldwide."
    ],
    safetyTips: [
      "Wear rugged boots with complete ankle support constraints.",
      "Start with very modest weight (10% of bodyweight) before scaling."
    ],
    beginnerVersion: "Unloaded nature hiking or vest-walking",
    advancedVersion: "Loaded Carry with 60-second combat sprints interspersed",
    recommendedSets: { fatLoss: "1", muscleGrowth: "1", strength: "2", endurance: "3" },
    recommendedReps: { fatLoss: "3 Miles", muscleGrowth: "2 Miles", strength: "1 Mile", endurance: "5+ Miles" },
    restTime: "None (continuous tactical stroll)",
    videoUrl: "https://www.youtube.com/shorts/pzImK-CNlmg?feature=share",
    imageUrl: "https://fitnessprogramer.com/wp-content/uploads/2021/07/Run.gif",
    anatomyIllustration: "Ankle stabilizers, hip belt weight sharing pelvic muscles."
  },

  // --- ATHLETIC PERFORMANCE ---
  {
    id: "athletic-1",
    name: "Explosive Box Jump Plyos",
    category: "athletic",
    muscleGroup: "legs",
    difficulty: "Intermediate",
    primaryMuscles: "Femoris Quadriceps, Gluteus, Calves",
    secondaryMuscles: "Hamstrings, Core, Arm Swing Coordinators",
    equipment: "Plyometric Box",
    instructions: [
      "Stand facing a wooden box with feet hip-width apart.",
      "Hinge at the hips, swing your arms backward, and drop into a quarter-squat.",
      "Explode upwards quickly, extending hips, knees, and ankles simultaneously.",
      "Swing arms forward aggressively to capture absolute vertical momentum.",
      "Land soft on top of the box in a semi-squat, absorbing the impact quietly.",
      "Stand fully upright on top of the box, then step down carefully one leg at a time."
    ],
    mistakes: [
      "Jumping down backward off high boxes, exposing Achilles tendon to rupture.",
      "Landing with stiff, straight knees with a loud thump."
    ],
    benefits: [
      "Trains rapid mechanical motor unit firing rates.",
      "Direct vertical leap and absolute sprint speed transfer and reactivity."
    ],
    safetyTips: [
      "Ensure box surface is slip-resistant.",
      "Step down rather than jump to save knees from massive impact shear."
    ],
    beginnerVersion: "Low Step Box Step-ups",
    advancedVersion: "Depth Jumps (dropping off box and bouncing off floor into high jump)",
    recommendedSets: { fatLoss: "3", muscleGrowth: "3", strength: "4-5", endurance: "2-3" },
    recommendedReps: { fatLoss: "10-12", muscleGrowth: "8-10", strength: "3-5", endurance: "15" },
    restTime: "90 seconds to reset nervous system",
    videoUrl: "https://youtu.be/k7dmYdknbac",
    imageUrl: "https://fitnessprogramer.com/wp-content/uploads/2015/07/The-Box-Jump.gif",
    anatomyIllustration: "Stretch-shortening tendon cycle parameters, gastrocnemius spring nodes."
  },

  // --- YOGA ---
  {
    id: "yoga-1",
    name: "Downward Facing Dog",
    category: "yoga",
    muscleGroup: "flexibility",
    difficulty: "Beginner",
    primaryMuscles: "Hamstrings, Calves, Latissimus Dorsi, Posterior Shoulders",
    secondaryMuscles: "Triceps, Wrist stabilizers, Anterior Tibialis",
    equipment: "Sticky Yoga Mat",
    instructions: [
      "Start on your hands and knees in a tabletop position.",
      "Align hands directly beneath shoulders, knees under hips.",
      "Tuck your toes, lift your knees off the floor, and push your hips high towards the ceiling.",
      "Squeeze your chest back towards your thighs, forming an inverted 'V' shape.",
      "Press your heels towards the floor while fully extending your spine.",
      "Take deep, rhythmic nose breaths."
    ],
    mistakes: [
      "Rounding the lower back (if tight, bend knees slightly instead).",
      "Squeezing shoulders to ears, blocking breathing neck channels."
    ],
    benefits: [
      "Relieves tightness in hamstrings and calves immediately.",
      "Decompresses the entire spinal column safely using body weight."
    ],
    safetyTips: [
      "Spread fingers wide to distribute wrist pressure evenly.",
      "Keep gaze focused backward at toes or belly button."
    ],
    beginnerVersion: "Knee-bent Downward Dog",
    advancedVersion: "Single-Leg Three-Legged Downward Dog (extreme core balance)",
    recommendedSets: { fatLoss: "2", muscleGrowth: "1", strength: "2", endurance: "3" },
    recommendedReps: { fatLoss: "5 deep breaths", muscleGrowth: "5 deep breaths", strength: "10 deep breaths", endurance: "15 deep breaths" },
    restTime: "30 seconds",
    videoUrl: "https://youtu.be/ljYDGXjyKNA",
    imageUrl: "https://images.squarespace-cdn.com/content/v1/52e3481ee4b0ce534c3c4ac8/5dd84457-ea47-4902-a28d-1dfb81d71efc/DD+tight+hams.gif",
    anatomyIllustration: "Gastrocnemius and hamstrings fascial sheath lines."
  },

  // --- PILATES ---
  {
    id: "pilates-1",
    name: "Pilates Hundred Core Squeeze",
    category: "pilates",
    muscleGroup: "core",
    difficulty: "Intermediate",
    primaryMuscles: "Transverse Abdominis, Rectus Abdominis, Obliques",
    secondaryMuscles: "Inner Thighs, Neck stabilizers, Hip Flexors",
    equipment: "Comfortable Mat",
    instructions: [
      "Lie on your back on the mat. Lift your legs up to a tabletop position (90-degree bent).",
      "Curl your head, neck, and shoulders up of the mat.",
      "Extend your arms straight out, hovering two inches off the mat, fingers pointing forward.",
      "Vigorously pump your arms up and down 2 inches.",
      "Inhale through the nose for 5 pumps, exhale through the mouth for 5 pumps.",
      "Repeat for 10 full breaths to equal exactly 100 counts."
    ],
    mistakes: [
      "Allowing the lower spine to arch off the mat (must maintain pelvic imprint).",
      "Straining the neck by pulling with jaw instead of high abdominal tuck."
    ],
    benefits: [
      "Fierce core strength stamina and waist cinching.",
      "Improves respiratory coordination with intense active core bracing."
    ],
    safetyTips: [
      "If your neck is fatigued, place your head flat on the mat for support.",
      "Force your lower navel backwards into the spine during exhalation."
    ],
    beginnerVersion: "Pilates Hundred with feet resting flat on floor",
    advancedVersion: "Pilates Hundred with legs fully extended at 45 degrees",
    recommendedSets: { fatLoss: "3", muscleGrowth: "2", strength: "3", endurance: "4" },
    recommendedReps: { fatLoss: "100 pumps", muscleGrowth: "100 pumps", strength: "100 pumps", endurance: "100 pumps" },
    restTime: "45 seconds",
    videoUrl: "https://youtu.be/ayQoxw8sRTk",
    imageUrl: "https://www.doyou.com/wp-content/uploads/2017/02/chest-lift-3242.gif",
    anatomyIllustration: "Transverse abdominis and pelvic floor girdle muscles."
  }
];
