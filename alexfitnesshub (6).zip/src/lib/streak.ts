import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { UserStreak } from '../types';
import { addNotificationToHistory } from './notifications';
import { apiFetch } from './api';

/**
 * Fetch a user's current workout streak details
 */
export async function getUserStreak(userId: string): Promise<UserStreak | null> {
  const path = `userStreaks/${userId}`;
  try {
    const docRef = doc(db, 'userStreaks', userId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as UserStreak;
    }
    
    // Auto-create initial blank streak row if first load
    const initialStreak: UserStreak = {
      id: userId,
      userId,
      currentStreak: 0,
      longestStreak: 0,
      totalCompletedWorkouts: 0,
      totalActiveDays: 0,
      updatedAt: new Date().toISOString()
    };
    await setDoc(docRef, initialStreak);
    return initialStreak;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
    return null;
  }
}

/**
 * Update user streak when they perform active events (complete workout, log meal, update progress)
 * Consistently validates dates and computes current & longest streaks securely.
 */
export async function updateStreakOnAction(
  userId: string, 
  actionType: 'workout' | 'meal' | 'progress' | 'general'
): Promise<{ streak: UserStreak; milestoneReached: string | null }> {
  const path = `userStreaks/${userId}`;
  try {
    const docRef = doc(db, 'userStreaks', userId);
    const snap = await getDoc(docRef);
    
    const today = new Date().toISOString().split('T')[0];
    const yesterdayDate = new Date();
    yesterdayDate.setDate(yesterdayDate.getDate() - 1);
    const yesterday = yesterdayDate.toISOString().split('T')[0];
    
    let currentStreak = 0;
    let longestStreak = 0;
    let totalCompletedWorkouts = 0;
    let totalActiveDays = 0;
    let lastWorkoutDate = '';
    let lastMealLogDate = '';
    let lastActiveDate = '';
    
    let isNewRecord = true;
    
    if (snap.exists()) {
      const existing = snap.data() as UserStreak;
      currentStreak = existing.currentStreak || 0;
      longestStreak = existing.longestStreak || 0;
      totalCompletedWorkouts = existing.totalCompletedWorkouts || 0;
      totalActiveDays = existing.totalActiveDays || 0;
      lastWorkoutDate = existing.lastWorkoutDate || '';
      lastMealLogDate = existing.lastMealLogDate || '';
      lastActiveDate = existing.lastActiveDate || '';
      isNewRecord = false;
    }
    
    let milestoneReached: string | null = null;
    let notificationTitle = '';
    let notificationBody = '';
    
    // Process core streak calendar
    if (lastActiveDate === today) {
      // Already logged an activity today, keep streak identical
      if (actionType === 'workout' && lastWorkoutDate !== today) {
        totalCompletedWorkouts += 1;
        lastWorkoutDate = today;
      } else if (actionType === 'meal' && lastMealLogDate !== today) {
        lastMealLogDate = today;
      }
    } else if (lastActiveDate === yesterday) {
      // Continuous action consecutive day!
      currentStreak += 1;
      totalActiveDays += 1;
      
      if (currentStreak > longestStreak) {
        longestStreak = currentStreak;
      }
      
      if (actionType === 'workout') {
        totalCompletedWorkouts += 1;
        lastWorkoutDate = today;
      } else if (actionType === 'meal') {
        lastMealLogDate = today;
      }
      
      lastActiveDate = today;
      
      // Determine milestones reached
      if (currentStreak === 3) {
        milestoneReached = '3-Day Fire! 🥉';
        notificationTitle = '🥉 3-DAY STREAK CATALYST';
        notificationBody = `🔥 Phenomenal work! You logged activities three days in a row. Keep pushing!`;
      } else if (currentStreak === 7) {
        milestoneReached = '7-Day Athlete! 🥈';
        notificationTitle = '🥈 7-DAY ELITE TRANSFORMATION';
        notificationBody = `🏆 Spectacular! You have hit a full 1-week training streak count! Coach Alex is proud.`;
      } else if (currentStreak === 15) {
        milestoneReached = '15-Day Ultimate! 🥇';
        notificationTitle = '🥇 15-DAY ABSOLUTE BEAST';
        notificationBody = `⚡ Unbelievable consistency! Peak somatic hypertrophic progression unlocked.`;
      } else if (currentStreak === 30) {
        milestoneReached = '30-Day Master! 👑';
        notificationTitle = '👑 30-DAY ABSOLUTE LEGEND';
        notificationBody = `🌟 Outstanding workout lifestyle! You maintained consistency for a solid month.`;
      } else {
        // Daily standard notification feedback
        notificationTitle = '🔥 STREAK INCREMENT';
        notificationBody = `You are on a ${currentStreak} day streak. Keep going and crush today\'s challenges!`;
      }
    } else {
      // First log ever, or missed yesterday (streak broke)
      const hadStreakBefore = currentStreak > 0;
      currentStreak = 1;
      totalActiveDays += 1;
      if (longestStreak === 0) {
        longestStreak = 1;
      }
      
      if (actionType === 'workout') {
        totalCompletedWorkouts += 1;
        lastWorkoutDate = today;
      } else if (actionType === 'meal') {
        lastMealLogDate = today;
      }
      
      lastActiveDate = today;
      
      if (hadStreakBefore) {
        notificationTitle = '⚡ BACK ON THE REBOUND';
        notificationBody = `You missed yesterday\'s consistency, but you are back on track today! Streak restored to 1.`;
      } else {
        notificationTitle = '🚀 WORKOUT JOURNEY CAPTAIN';
        notificationBody = `Congratulations on launching your premium workout logging streak today! Maintain it daily.`;
      }
    }
    
    const updatedStreak: UserStreak = {
      id: userId,
      userId,
      currentStreak,
      longestStreak,
      totalCompletedWorkouts,
      totalActiveDays,
      lastWorkoutDate,
      lastMealLogDate,
      lastActiveDate,
      updatedAt: new Date().toISOString()
    };
    
    await setDoc(docRef, updatedStreak);
    
    // Add persistent message into user's inbox
    if (notificationTitle && notificationBody) {
      await addNotificationToHistory(userId, notificationTitle, notificationBody, actionType === 'workout' ? 'workout' : 'streak');
    }

    // Call server to trigger streak achievement email dispatch
    try {
      await apiFetch('/api/auth/send-streak-email', {
        method: 'POST',
        body: JSON.stringify({
          userId,
          currentStreak,
          longestStreak,
          milestoneReached
        })
      });
    } catch (err) {
      console.warn("[STREAK EMAIL EXCEPTION] Background notifier trace handled gracefully:", err);
    }
    
    return { streak: updatedStreak, milestoneReached };
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
    const fallbackStreak: UserStreak = {
      id: userId,
      userId,
      currentStreak: 1,
      longestStreak: 1,
      totalCompletedWorkouts: 1,
      totalActiveDays: 1,
      updatedAt: new Date().toISOString()
    };
    return { streak: fallbackStreak, milestoneReached: null };
  }
}
