import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Support dynamic production environment variables (Vite exposed with high priority)
const metaEnv = (import.meta as any).env || {};

const activeConfig = {
  projectId: "alex-project-777",
  appId: "1:990644348112:web:dd3b5d43190f913185ead5",
  apiKey: "AIzaSyCN-LfNHvWpZK9d8wDqKhlPGjgsJa0MscQ",
  authDomain: "alex-project-777.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-e2b1ccac-2ecb-4b46-96be-6ad4f63c5cef",
  storageBucket: "alex-project-777.firebasestorage.app",
  messagingSenderId: "990644348112",
  measurementId: "G-EQX8ZMEB94"
};

const firebaseConfig = {
  apiKey: metaEnv.VITE_FIREBASE_API_KEY || activeConfig.apiKey,
  authDomain: metaEnv.VITE_FIREBASE_AUTH_DOMAIN || activeConfig.authDomain,
  projectId: metaEnv.VITE_FIREBASE_PROJECT_ID || activeConfig.projectId,
  storageBucket: metaEnv.VITE_FIREBASE_STORAGE_BUCKET || activeConfig.storageBucket,
  messagingSenderId: metaEnv.VITE_FIREBASE_MESSAGING_SENDER_ID || activeConfig.messagingSenderId,
  appId: metaEnv.VITE_FIREBASE_APP_ID || activeConfig.appId,
  measurementId: metaEnv.VITE_FIREBASE_MEASUREMENT_ID || activeConfig.measurementId || "",
  firestoreDatabaseId: metaEnv.VITE_FIREBASE_DATABASE_ID || activeConfig.firestoreDatabaseId || "(default)"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export { firebaseConfig };

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
    },
    operationType,
    path
  };
  console.error('[FIRESTORE ERROR DETECTED]: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}
