export async function apiFetch<T = any>(path: string, options: RequestInit = {}, retries = 2): Promise<T> {
  const baseUrl = (import.meta as any).env?.VITE_API_BASE_URL || '';
  const url = path.startsWith('http') ? path : `${baseUrl}${path}`;
  
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  } as Record<string, string>;
  
  let attempt = 0;
  while (true) {
    try {
      const res = await fetch(url, {
        ...options,
        headers,
      });
      
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Express server responded with code ${res.status}`);
      }
      
      const payload = await res.json();
      return payload as T;
    } catch (err: any) {
      attempt++;
      if (attempt <= retries) {
        const delay = attempt * 1000;
        console.warn(`[API FETCH FAIL] Preflight/Request failed for ${path}. Retrying in ${delay}ms... (Attempt ${attempt}/${retries})`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      console.error(`[API FETCH HARD FAILURE] Path ${path} collapsed after ${attempt} retry loops.`, err);
      // Format details cleanly for the user UI
      const readableMessage = err instanceof Error ? err.message : String(err);
      throw new Error(readableMessage || "API Connection offline. Please confirm server internet connection or CORS configs.");
    }
  }
}

/**
 * Resolves external image and GIF URLs through our server-side image proxy
 * to prevent Referrer, CORS, and hotlinking blocks (specifically for Pinterest / pinimg).
 */
export function getMediaProxyUrl(url?: string): string {
  if (!url) return '';
  if (
    url.startsWith('/') || 
    url.startsWith('data:') || 
    url.startsWith('blob:') || 
    url.startsWith('./')
  ) {
    return url;
  }
  if (url.startsWith('http://') || url.startsWith('https://')) {
    // Avoid proxying our own domain
    if (typeof window !== 'undefined' && url.startsWith(window.location.origin)) {
      return url;
    }
    // Route fitnessprogramer.com through the robust, free global images.weserv.nl proxy 
    // to instantly render interactive animated GIFs directly in the browser
    if (url.includes('fitnessprogramer.com')) {
      return `https://images.weserv.nl/?url=${encodeURIComponent(url)}`;
    }
    return `/api/proxy-image?url=${encodeURIComponent(url)}`;
  }
  return url;
}

/**
 * Normalizes YouTube video URLs to their respective /embed/ form
 * to prevent X-Frame-Options SAMEORIGIN block issues when rendered inside an iframe.
 */
export function getYouTubeEmbedUrl(url?: string): string {
  if (!url) return '';
  
  if (url.includes('/embed/')) {
    return url;
  }
  
  // Handle shorts e.g. https://www.youtube.com/shorts/Gf65Yy0-wGI?feature=share
  if (url.includes('/shorts/')) {
    const parts = url.split('/shorts/');
    if (parts[1]) {
      const id = parts[1].split('?')[0].split('&')[0];
      return `https://www.youtube.com/embed/${id}`;
    }
  }

  // Handle youtu.be/ID
  if (url.includes('youtu.be/')) {
    const parts = url.split('youtu.be/');
    if (parts[1]) {
      const id = parts[1].split('?')[0].split('&')[0];
      return `https://www.youtube.com/embed/${id}`;
    }
  }
  
  // Handle youtube.com/watch?v=ID
  if (url.includes('v=')) {
    try {
      const urlObj = new URL(url);
      const id = urlObj.searchParams.get('v');
      if (id) {
        return `https://www.youtube.com/embed/${id}`;
      }
    } catch (e) {
      // Fallback regex or split
      const match = url.match(/[?&]v=([^&#]+)/);
      if (match && match[1]) {
        return `https://www.youtube.com/embed/${match[1]}`;
      }
    }
  }
  
  return url;
}
