import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { RefreshCw } from 'lucide-react';

export default function PremiumGuard({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin text-amber-500 font-bold" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth/login" state={{ from: location }} replace />;
  }

  const isPremium = (
    (user.subscriptionPlan && user.subscriptionPlan !== 'free' && user.subscriptionStatus === 'active') ||
    user.email === 'muzikworld08@gmail.com' ||
    (user as any).role === 'admin'
  );

  if (!isPremium) {
    return <Navigate to="/pricing" replace />;
  }

  return <>{children}</>;
}
