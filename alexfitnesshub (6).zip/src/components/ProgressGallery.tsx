import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Camera, 
  Calendar, 
  Scale, 
  Plus, 
  Trash2, 
  Lock, 
  Sparkles, 
  Dumbbell, 
  RefreshCw, 
  ShieldCheck,
  Image as ImageIcon
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { collection, query, where, getDocs, setDoc, doc, deleteDoc, onSnapshot } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { ProgressEntry } from '../types';

// Curated safe actual athlete aesthetic progression presets to prevent "fake/empty placeholder" syndrome
const PRESET_PHOTOS = [
  {
    name: "Athletic Abs",
    url: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=600",
    desc: "Core definitions & lean fat-shred milestone"
  },
  {
    name: "Lifting Session",
    url: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=600",
    desc: "Heavy mechanical tension alignment tracking"
  },
  {
    name: "Conditioning Progress",
    url: "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=600",
    desc: "Somatic training stamina milestones"
  },
  {
    name: "Muscular Arms",
    url: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=600",
    desc: "Hypertrophy pump and bicep progression"
  },
  {
    name: "Stretching Flow",
    url: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=600",
    desc: "Flexibility & spinal posture health entry"
  },
  {
    name: "Heavy Steel Pull",
    url: "https://images.unsplash.com/photo-1605296867304-46d5465a25f1?q=80&w=600",
    desc: "Back thickness overload tracking"
  }
];

export default function ProgressGallery() {
  const navigate = useNavigate();
  const { user: currentUser } = useAuth();
  
  const [entries, setEntries] = useState<ProgressEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Form status state
  const [weight, setWeight] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [photoUrl, setPhotoUrl] = useState('');
  const [waterIntake, setWaterIntake] = useState('3.0');
  const [chest, setChest] = useState('');
  const [waist, setWaist] = useState('');
  const [biceps, setBiceps] = useState('');
  const [selectedPreset, setSelectedPreset] = useState<number | null>(null);
  
  const [errTex, setErrTex] = useState<string | null>(null);
  const [succTex, setSuccTex] = useState<string | null>(null);

  // Fetch logged progress photos from Firestore for authenticated user
  useEffect(() => {
    if (!currentUser) {
      setLoading(false);
      return;
    }

    setLoading(true);
    const path = 'progress';
    try {
      const q = query(
        collection(db, path), 
        where('userId', '==', currentUser.id)
      );

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const list: ProgressEntry[] = [];
        snapshot.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as ProgressEntry);
        });
        
        // Sort by date reverse chronological (newest first)
        const sorted = list.sort((a, b) => {
          return new Date(b.date).getTime() - new Date(a.date).getTime();
        });
        
        setEntries(sorted);
        setLoading(false);
      }, (error) => {
        handleFirestoreError(error, OperationType.GET, path);
        setLoading(false);
      });

      return () => unsubscribe();
    } catch (err: any) {
      console.error("[GALLERY FETCH SYSTEM FAULT]", err);
      setLoading(false);
    }
  }, [currentUser]);

  const selectPresetImage = (index: number, url: string) => {
    setSelectedPreset(index);
    setPhotoUrl(url);
  };

  const handleAddPhotoLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!weight) {
      setErrTex("Weight is mandatory for biometric progress logging!");
      return;
    }
    if (!photoUrl) {
      setErrTex("Please select a physical progress photo preset or input a custom image URL first!");
      return;
    }

    setIsSubmitting(true);
    setErrTex(null);
    setSuccTex(null);

    const docId = `prog-${Date.now()}`;
    const path = `progress/${docId}`;
    
    try {
      const newEntryObj: ProgressEntry = {
        id: docId,
        userId: currentUser.id,
        date: date || new Date().toISOString().split('T')[0],
        weight: Number(weight),
        photoUrl: photoUrl,
        waterIntakeLiters: Number(waterIntake) || 3.0,
        chest: chest ? Number(chest) : undefined,
        waist: waist ? Number(waist) : undefined,
        biceps: biceps ? Number(biceps) : undefined
      };

      await setDoc(doc(db, 'progress', docId), newEntryObj);
      
      // Reset form on success
      setWeight('');
      setPhotoUrl('');
      setChest('');
      setWaist('');
      setBiceps('');
      setSelectedPreset(null);
      setSuccTex("🎉 Visual physical milestone logged securely into cloud database!");
    } catch (err: any) {
      console.error("[FIRESTORE PHOTO SAVE FAILURE]", err);
      setErrTex("Failed to save progress snapshot: Please check security restrictions or try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteEntry = async (id: string) => {
    if (!window.confirm("Are you absolutely sure you want to delete this physical tracking entry from your dashboard?")) {
      return;
    }

    const path = `progress/${id}`;
    try {
      await deleteDoc(doc(db, 'progress', id));
      setSuccTex("🗑️ Progression item and image deleted permanently.");
    } catch (err: any) {
      console.error("[FIRESTORE PHOTO DELETE FAILURE]", err);
      setErrTex("Failed to erase entry. Verify that you own the resource.");
    }
  };

  if (!currentUser) {
    return (
      <div className="bg-neutral-950 border border-neutral-900 rounded-lg p-8 text-center max-w-xl mx-auto space-y-6">
        <div className="w-16 h-16 bg-neutral-900 border border-neutral-800 rounded-full flex items-center justify-center mx-auto">
          <Lock className="h-6 w-6 text-amber-500" />
        </div>
        <div className="space-y-2">
          <h3 className="font-bebas text-2xl tracking-wider text-white uppercase italic">
            SECURE ACCESS REQUIRED
          </h3>
          <p className="text-xs text-neutral-400 max-w-sm mx-auto leading-relaxed">
            Unification security checks prevent guest users from viewing personal biometric snapshots or uploaded progress galleries. Sign in to lock in your metrics.
          </p>
        </div>
        <div className="flex gap-4 justify-center pt-2">
          <button 
            onClick={() => navigate('/auth/login')}
            className="bg-amber-500 hover:bg-amber-600 text-black text-xs font-black uppercase tracking-widest px-6 py-3 rounded transition-colors cursor-pointer"
          >
            Access Login Portal
          </button>
          <button 
            onClick={() => navigate('/auth/signup')}
            className="border border-white/10 hover:bg-white/5 text-white text-xs font-bold uppercase tracking-widest px-6 py-3 rounded transition-colors cursor-pointer"
          >
            Register Account
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      
      {/* Logger form container */}
      <div className="bg-neutral-950 border border-neutral-900 rounded-lg p-6 sm:p-8 space-y-6 relative shadow-2xl">
        <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl"></div>
        
        <div className="flex items-center justify-between border-b border-neutral-900 pb-4">
          <div className="flex items-center space-x-2.5">
            <Camera className="h-5 w-5 text-amber-500" />
            <div>
              <h3 className="font-bebas text-xl text-white tracking-wider uppercase font-bold">Log Visual Physical Milestone</h3>
              <p className="text-[10px] text-neutral-500 uppercase font-mono tracking-wider">Commit body parameters & shape photo</p>
            </div>
          </div>
          <div className="flex items-center space-x-1.5 text-emerald-500 text-[10px] font-mono select-none px-2.5 py-1 bg-emerald-500/10 rounded-full border border-emerald-500/20">
            <ShieldCheck className="h-4 w-4 animate-pulse" />
            <span className="font-bold uppercase tracking-widest">TLS 1.3 SECURED</span>
          </div>
        </div>

        {errTex && (
          <div className="p-3.5 bg-rose-500/10 border border-rose-500/20 text-rose-500 text-xs rounded uppercase font-mono tracking-wide">
            ⚠️ {errTex}
          </div>
        )}

        {succTex && (
          <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded uppercase font-mono tracking-wide">
            ✓ {succTex}
          </div>
        )}

        <form onSubmit={handleAddPhotoLog} className="space-y-6 text-left">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            
            <div className="flex flex-col space-y-1">
              <label className="text-[10px] uppercase text-neutral-400 font-bold font-mono">Weight (kg) <span className="text-amber-500">*</span></label>
              <div className="relative">
                <Scale className="absolute left-3.5 top-1/2 transform -translate-y-1/2 h-3.5 w-3.5 text-neutral-500" />
                <input
                  type="number"
                  step="0.1"
                  required
                  placeholder="e.g. 84.5"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  className="bg-black border border-neutral-850 rounded p-2.5 pl-10 text-xs text-white outline-none focus:border-amber-500 w-full"
                />
              </div>
            </div>

            <div className="flex flex-col space-y-1">
              <label className="text-[10px] uppercase text-neutral-400 font-bold font-mono">Select Log Date</label>
              <div className="relative">
                <Calendar className="absolute left-3.5 top-1/2 transform -translate-y-1/2 h-3.5 w-3.5 text-neutral-500" />
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="bg-black border border-neutral-850 rounded p-2.5 pl-10 text-xs text-white outline-none focus:border-amber-500 w-full"
                />
              </div>
            </div>

            <div className="flex flex-col space-y-1">
              <label className="text-[10px] uppercase text-neutral-400 font-bold font-mono">Hydration Tracker (L)</label>
              <input
                type="number"
                step="0.1"
                placeholder="e.g. 3.5"
                value={waterIntake}
                onChange={(e) => setWaterIntake(e.target.value)}
                className="bg-black border border-neutral-850 rounded p-2.5 text-xs text-white outline-none focus:border-amber-500"
              />
            </div>

          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="flex flex-col space-y-1">
              <label className="text-[10px] uppercase text-neutral-500 font-mono font-bold">Chest Line (cm)</label>
              <input
                type="number"
                placeholder="e.g. 102"
                value={chest}
                onChange={(e) => setChest(e.target.value)}
                className="bg-black border border-neutral-850 rounded p-2.5 text-xs text-white outline-none focus:border-amber-500"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <label className="text-[10px] uppercase text-neutral-500 font-mono font-bold">Waist Line (cm)</label>
              <input
                type="number"
                placeholder="e.g. 88"
                value={waist}
                onChange={(e) => setWaist(e.target.value)}
                className="bg-black border border-neutral-850 rounded p-2.5 text-xs text-white outline-none focus:border-amber-500"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <label className="text-[10px] uppercase text-neutral-500 font-mono font-bold">Bicep Size (cm)</label>
              <input
                type="number"
                placeholder="e.g. 39.5"
                value={biceps}
                onChange={(e) => setBiceps(e.target.value)}
                className="bg-black border border-neutral-850 rounded p-2.5 text-xs text-white outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Preset Photo Selection Grid */}
          <div className="space-y-2">
            <label className="text-[10px] uppercase text-neutral-400 font-extrabold tracking-widest font-mono flex items-center space-x-1">
              <Sparkles className="h-3.5 w-3.5 text-amber-500 animate-pulse" />
              <span>Choose High-Integrity Athlete Photo Preset</span>
            </label>
            
            <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 w-full">
              {PRESET_PHOTOS.map((pres, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => selectPresetImage(idx, pres.url)}
                  className={`relative h-20 bg-neutral-900 border rounded-md overflow-hidden transition-all group shrink-0 cursor-pointer ${
                    selectedPreset === idx 
                      ? 'border-amber-500 ring-2 ring-amber-500/20 scale-[0.98]' 
                      : 'border-white/5 hover:border-amber-500/30'
                  }`}
                >
                  <img
                    src={pres.url}
                    alt={pres.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-x-0 bottom-0 bg-black/80 py-1 text-center truncate">
                    <span className="text-[8px] font-mono text-neutral-300 uppercase tracking-widest font-bold">
                      {pres.name}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Custom photo URL fallback */}
          <div className="flex flex-col space-y-1.5">
            <label className="text-[10px] uppercase text-neutral-550 font-bold font-mono">Or input Custom Tracked Image URL</label>
            <div className="relative">
              <ImageIcon className="absolute left-3.5 top-1/2 transform -translate-y-1/2 h-3.5 w-3.5 text-neutral-500" />
              <input
                type="url"
                placeholder="https://images.unsplash.com/your-custom-progress-photo.jpg"
                value={photoUrl}
                onChange={(e) => {
                  setPhotoUrl(e.target.value);
                  setSelectedPreset(null);
                }}
                className="bg-black border border-neutral-850 rounded p-2.5 pl-10 text-xs text-white outline-none focus:border-amber-500 w-full font-mono"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-amber-500 hover:bg-amber-600 disabled:bg-neutral-800 disabled:text-neutral-500 text-black font-black uppercase text-xs tracking-widest py-3.5 rounded-sm transition-all flex items-center justify-center space-x-2 font-mono cursor-pointer"
          >
            {isSubmitting ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>Syncing biometric locker...</span>
              </>
            ) : (
              <>
                <Plus className="h-4 w-4" />
                <span>Secure-Log Visual Milestone</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Progress Photos Display Area */}
      <div className="space-y-6">
        <h3 className="font-bebas text-2xl text-white tracking-widest uppercase italic text-left flex items-center space-x-2">
          <Dumbbell className="h-5 w-5 text-amber-500" />
          <span>My Secure Visual Conversion History</span>
        </h3>

        {loading ? (
          <div className="p-16 border border-neutral-900 bg-neutral-950/60 rounded-lg text-center flex flex-col items-center justify-center space-y-3">
            <RefreshCw className="h-6 w-6 animate-spin text-amber-500" />
            <p className="text-xs uppercase tracking-widest text-neutral-500 font-mono">Re-Authenticating secure photo tokens...</p>
          </div>
        ) : entries.filter(p => p.photoUrl).length === 0 ? (
          <div className="border border-dashed border-neutral-900 bg-neutral-950/40 rounded-lg p-12 text-center text-xs text-neutral-500 uppercase tracking-widest font-mono space-y-2">
            <div>📷 Vault Currently is Empty</div>
            <div className="text-[10px] text-neutral-600 font-light font-sans normal-case">
              You haven't committed any transformation photos to your secure cloud tracker yet. Use the log console above to establish your physical history records!
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {entries.filter(p => p.photoUrl).map((p) => (
              <div 
                key={p.id} 
                className="bg-neutral-950 border border-neutral-900 rounded-lg overflow-hidden group hover:border-amber-500/30 transition-all duration-300 flex flex-col relative justify-between"
              >
                {/* Photo area */}
                <div className="h-64 overflow-hidden relative bg-neutral-900 flex items-center justify-center">
                  <img
                    src={p.photoUrl}
                    alt={`Milestone date: ${p.date}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />
                  <div className="absolute top-3 right-3">
                    <button
                      onClick={() => handleDeleteEntry(p.id)}
                      className="bg-black/85 hover:bg-rose-600 text-neutral-400 hover:text-white p-2 rounded-full border border-white/5 hover:border-rose-500 transition-colors cursor-pointer"
                      title="Erase log permanently"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <div className="absolute bottom-3 left-3 bg-black/80 px-2.5 py-1 rounded-sm border border-white/10">
                    <span className="text-[9px] font-mono font-bold text-amber-500 uppercase tracking-wider">
                      📆 {p.date}
                    </span>
                  </div>
                </div>

                {/* Info parameters area */}
                <div className="p-4 sm:p-5 text-left bg-neutral-950/90 border-t border-neutral-900 space-y-3">
                  <div className="flex justify-between items-center bg-black/50 border border-white/5 p-3 rounded font-mono text-[11px]">
                    <div className="flex flex-col">
                      <span className="text-neutral-550 uppercase text-[8px] font-bold">Weight</span>
                      <strong className="text-white text-sm">{p.weight} kg</strong>
                    </div>
                    {p.waterIntakeLiters && (
                      <div className="flex flex-col border-l border-white/5 pl-3">
                        <span className="text-neutral-550 uppercase text-[8px] font-bold">Water</span>
                        <strong className="text-amber-500 text-sm">{p.waterIntakeLiters}L</strong>
                      </div>
                    )}
                  </div>

                  {/* Body tape parameters */}
                  {(p.chest || p.waist || p.biceps) && (
                    <div className="grid grid-cols-3 gap-1.5 pt-1 text-center font-mono text-[9px] text-neutral-400">
                      {p.chest && (
                        <div className="bg-black border border-white/5 py-1 px-1.5 rounded">
                          <span className="text-neutral-500 mr-0.5">CHEST:</span>
                          <strong className="text-white">{p.chest}cm</strong>
                        </div>
                      )}
                      {p.waist && (
                        <div className="bg-black border border-white/5 py-1 px-1.5 rounded">
                          <span className="text-neutral-500 mr-0.5">WAIST:</span>
                          <strong className="text-white">{p.waist}cm</strong>
                        </div>
                      )}
                      {p.biceps && (
                        <div className="bg-black border border-white/5 py-1 px-1.5 rounded">
                          <span className="text-neutral-500 mr-0.5">ARM:</span>
                          <strong className="text-white">{p.biceps}cm</strong>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="pt-2 flex justify-between items-center text-[9px] font-mono text-neutral-550 uppercase">
                    <span>ALEXFITNESSHUB Biometric</span>
                    <span className="text-emerald-500 font-bold">✓ SECURED</span>
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
