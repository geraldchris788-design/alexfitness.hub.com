import React from 'react';
import { Link } from 'react-router-dom';
import { Dumbbell, Instagram, Youtube, Twitter, Facebook, Sparkles } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black border-t border-white/10 text-white/50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-gold rounded-sm flex items-center justify-center">
                <div className="w-3 h-3 bg-black rotate-45"></div>
              </div>
              <span className="font-bebas text-xl font-black tracking-tighter uppercase italic text-white leading-none">
                ALEXFITNESS<span className="text-gold">HUB</span>
              </span>
            </div>
            <p className="text-xs leading-relaxed text-neutral-400">
              A premium, world-class athletic transformation hub powered by advanced AI coaching algorithms, custom-made exercises, and custom nutrition guides.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="#" className="hover:text-gold transition-colors"><Instagram className="h-4 w-4" /></a>
              <a href="#" className="hover:text-gold transition-colors"><Youtube className="h-4 w-4" /></a>
              <a href="#" className="hover:text-gold transition-colors"><Twitter className="h-4 w-4" /></a>
              <a href="#" className="hover:text-gold transition-colors"><Facebook className="h-4 w-4" /></a>
            </div>
          </div>

          <div>
            <h3 className="font-bebas text-md font-bold tracking-widest text-white mb-4">TRAINING TRACKS</h3>
            <ul className="space-y-2 text-xs uppercase tracking-wider">
              <li><Link to="/gym-workouts" className="hover:text-gold transition-colors">Gym Hypertrophy</Link></li>
              <li><Link to="/home-workouts" className="hover:text-gold transition-colors">Home Conditioning</Link></li>
              <li><Link to="/calisthenics" className="hover:text-gold transition-colors">Military Calisthenics</Link></li>
              <li><Link to="/cardio" className="hover:text-gold transition-colors">Intense Cardio & HIIT</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-bebas text-md font-bold tracking-widest text-white mb-4">AI PLATFORM</h3>
            <ul className="space-y-2 text-xs uppercase tracking-wider">
              <li><Link to="/ai-coach" className="hover:text-gold transition-colors">AI Digital Coach</Link></li>
              <li><Link to="/meal-plans" className="hover:text-gold transition-colors">Custom Meal Generator</Link></li>
              <li><Link to="/transformations" className="hover:text-gold transition-colors">Transformation Logs</Link></li>
              <li><Link to="/pricing" className="hover:text-gold transition-colors">Premium Pricing</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-bebas text-md font-bold tracking-widest text-white mb-4">HUB CORNER</h3>
            <ul className="space-y-2 text-xs uppercase tracking-wider">
              <li><Link to="/about" className="hover:text-gold transition-colors">Our History</Link></li>
              <li><Link to="/blog" className="hover:text-gold transition-colors">Fitness Blog & Science</Link></li>
              <li><Link to="/contact" className="hover:text-gold transition-colors">Support Helpline</Link></li>
              <li className="flex items-center space-x-1 pt-1.5 text-[10px] text-gold font-bold">
                <Sparkles className="h-3.5 w-3.5" />
                <span>Monnify Secured Gateway</span>
              </li>
            </ul>
          </div>

        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-[10px] uppercase tracking-wider">
          <div>
            &copy; {new Date().getFullYear()} ALEXFITNESSHUB. All Rights Reserved. Designed for extreme results.
          </div>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link to="/auth/diagnostic" className="hover:text-gold transition-colors">Diagnostics Console</Link>
            <a href="#" className="hover:text-gold transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-gold transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-gold transition-colors">Sitemap & Robots</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
