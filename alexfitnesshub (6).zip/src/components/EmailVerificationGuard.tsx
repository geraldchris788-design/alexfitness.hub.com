import React, { useState } from 'react';
import { Mail, RefreshCw, ShieldAlert, LogOut, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../lib/api';

export default function EmailVerificationGuard({ children }: { children: React.ReactNode }) {
  const { user, logout, refreshUser } = useAuth();
  const [isResending, setIsResending] = useState(false);
  const [resendStatus, setResendStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  if (!user) {
    return <>{children}</>;
  }

  if (user.isVerified) {
    return <>{children}</>;
  }

  const handleResend = async () => {
    setIsResending(true);
    setResendStatus('idle');
    setStatusMessage('');
    try {
      // Trigger verification dispatch in backend/Firebase Auth
      const response = await apiFetch<any>('/api/auth/resend-verification', {
        method: 'POST',
        body: JSON.stringify({ email: user.email })
      });

      if (response && response.success) {
        setResendStatus('success');
        setStatusMessage(response.message || '📬 A new verified link has been dispatched to your inbox.');
      } else {
        setResendStatus('error');
        setStatusMessage(response?.error || 'Failed to dispatch verification email. Try again in 60 seconds.');
      }
    } catch (e: any) {
      console.error(e);
      setResendStatus('error');
      setStatusMessage(e.message || 'Error occurred while contacting authorization node.');
    } finally {
      setIsResending(false);
    }
  };

  const handleRefreshStatus = async () => {
    setIsRefreshing(true);
    try {
      await refreshUser();
    } catch (e) {
      console.error("Failed refreshing user session", e);
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 bg-black text-white py-16">
      <div className="bg-neutral-950 border border-neutral-900 p-8 sm:p-10 max-w-md w-full rounded-md shadow-2xl relative overflow-hidden text-center space-y-6">
        <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl pointer-events-none"></div>
        
        <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/25 text-amber-500 rounded-full flex items-center justify-center mx-auto animate-pulse">
          <Mail className="h-7 w-7" />
        </div>

        <div className="space-y-2">
          <span className="text-[10px] text-amber-500 font-mono tracking-widest uppercase font-bold bg-amber-500/10 border border-amber-500/25 px-2.5 py-1 rounded inline-block">
            ACCESS RESTRICTED
          </span>
          <h2 className="font-bebas text-3xl font-extrabold uppercase tracking-widest text-white">
            Verify Your Email Address
          </h2>
          <p className="text-neutral-400 text-xs sm:text-xs leading-relaxed max-w-sm mx-auto">
            Welcome, <span className="text-white font-bold">{user.name}</span>! Access to Coach Alex's master workout systems, meal matrices, in-app logs, and premium AI engine is locked until your elite email is verified.
          </p>
        </div>

        <div className="bg-neutral-900/60 border border-neutral-900 rounded p-4 text-left font-mono text-[11px] text-neutral-450 space-y-1.5 leading-relaxed">
          <div><span className="text-amber-500 font-bold">ATHLETE:</span> {user.name}</div>
          <div><span className="text-amber-500 font-bold">EMAIL:</span> {user.email}</div>
          <div><span className="text-amber-500 font-bold">STATUS:</span> <span className="text-amber-500 font-bold">PENDING VERIFICATION</span></div>
        </div>

        {resendStatus === 'success' && (
          <div className="flex space-x-2 p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded text-xs text-left leading-relaxed">
            <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-500 mt-0.5" />
            <span>{statusMessage}</span>
          </div>
        )}

        {resendStatus === 'error' && (
          <div className="flex space-x-2 p-3 bg-rose-500/10 border border-rose-500/20 text-rose-500 rounded text-xs text-left leading-relaxed">
            <ShieldAlert className="h-5 w-5 shrink-0 text-rose-400 mt-0.5" />
            <span>{statusMessage}</span>
          </div>
        )}

        <div className="space-y-3 pt-2">
          <button
            onClick={handleRefreshStatus}
            disabled={isRefreshing}
            className="w-full bg-amber-500 hover:brightness-110 text-black font-extrabold uppercase text-xs tracking-widest py-3 rounded-sm flex items-center justify-center gap-2 transition-all font-mono cursor-pointer disabled:opacity-50"
          >
            {isRefreshing ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
            <span>{isRefreshing ? 'CHECKING...' : 'I HAVE VERIFIED MY EMAIL'}</span>
          </button>

          <button
            onClick={handleResend}
            disabled={isResending}
            className="w-full bg-neutral-900 border border-neutral-850 hover:bg-neutral-850 text-white font-bold uppercase text-[11px] tracking-widest py-3 rounded-sm flex items-center justify-center gap-2 transition-all font-mono cursor-pointer disabled:opacity-50"
          >
            {isResending ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Mail className="h-4 w-4" />
            )}
            <span>{isResending ? 'SENDING LINK...' : 'RESEND VERIFICATION LINK'}</span>
          </button>
        </div>

        <div className="pt-2 border-t border-neutral-900 flex justify-between items-center text-[10px] font-mono text-neutral-500">
          <span>Check spam / junk folder</span>
          <button
            onClick={() => logout()}
            className="text-rose-500 hover:text-rose-400 flex items-center gap-1 uppercase font-bold hover:underline transition-all"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </div>
  );
}
