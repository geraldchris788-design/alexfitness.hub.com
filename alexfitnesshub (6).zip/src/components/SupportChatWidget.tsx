import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, X, Send, RefreshCw, User, Shield } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../lib/api';

interface Message {
  id: string;
  chatSessionId: string;
  senderName: string;
  senderEmail: string;
  message: string;
  senderRole: 'user' | 'admin';
  timestamp: string;
  read: boolean;
}

export default function SupportChatWidget() {
  const { user: authUser } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [loading, setLoading] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  // Guest inputs if user is not logged in and wants to introduce themselves
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Generate or read persistent Session ID
  const chatSessionIdRef = useRef<string>('');

  useEffect(() => {
    let sid = localStorage.getItem('alexfit_chat_sid');
    if (!sid) {
      sid = authUser ? authUser.id : `guest_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      localStorage.setItem('alexfit_chat_sid', sid);
    } else if (authUser && sid.startsWith('guest_')) {
      // Upgrade guest session to authenticated session
      sid = authUser.id;
      localStorage.setItem('alexfit_chat_sid', sid);
    }
    chatSessionIdRef.current = sid;
  }, [authUser]);

  // Fetch chat history
  const fetchChats = async (quiet = false) => {
    if (!chatSessionIdRef.current) return;
    if (!quiet) setLoading(true);
    try {
      const data = await apiFetch<any[]>(`/api/support/chats?chatSessionId=${chatSessionIdRef.current}&role=user`);
      if (data) {
        setMessages(data);
        
        // Count unread admin messages when the widget is CLOSED
        if (!isOpen) {
          const unreadNum = data.filter((m: Message) => m.senderRole === 'admin' && !m.read).length;
          setUnreadCount(unreadNum);
        } else {
          setUnreadCount(0);
        }
      }
    } catch (err) {
      console.error("Support chat polling fail:", err);
    } finally {
      if (!quiet) setLoading(false);
    }
  };

  // Poll chats periodically
  useEffect(() => {
    fetchChats();
    const interval = setInterval(() => {
      fetchChats(true);
    }, 4500);
    return () => clearInterval(interval);
  }, [isOpen, authUser]);

  // Handle open of chat -> clears unread
  useEffect(() => {
    if (isOpen) {
      setUnreadCount(0);
      scrollToBottom();
      // Trigger a fetch when opened to mark messages as read in the backend
      fetchChats(true);
    }
  }, [isOpen]);

  // Scroll to bottom helper
  const scrollToBottom = () => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 80);
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const sessionToken = chatSessionIdRef.current;
    const name = authUser ? (authUser.name || 'Athlete') : (guestName.trim() || 'Guest Athlete');
    const email = authUser ? authUser.email : guestEmail.trim();

    setIsSending(true);
    const textToSend = inputText;
    setInputText('');

    try {
      await apiFetch<any>('/api/support/send', {
        method: 'POST',
        body: JSON.stringify({
          chatSessionId: sessionToken,
          senderName: name,
          senderEmail: email,
          message: textToSend,
          senderRole: 'user'
        })
      });

      if (!authUser && (guestName || guestEmail)) {
        setFormSubmitted(true);
      }
      await fetchChats(true);
    } catch (err) {
      console.error("Failed to send support message:", err);
    } finally {
      setIsSending(false);
    }
  };

  // Check if we need to show guest info form first
  const showIntroForm = !authUser && !formSubmitted && messages.length === 0;

  return (
    <div className="fixed bottom-6 right-6 z-50 font-sans select-none">
      {/* Mini Chat Toggle Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          id="support-chat-launcher"
          className="bg-amber-500 hover:bg-amber-600 text-black p-4 rounded-full shadow-2xl flex items-center justify-center relative transition-all duration-300 transform hover:scale-105 active:scale-95 group border border-amber-600/30"
          title="Open Coach Support Chat"
        >
          <MessageSquare className="h-6 w-6" />
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-500 ease-out font-bold text-xs uppercase tracking-wider pl-0 group-hover:pl-2 whitespace-nowrap">
            Support Chat
          </span>
          {unreadCount > 0 && (
            <span id="support-chat-badge" className="absolute -top-1 -right-1 bg-red-600 outline outline-2 outline-black text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center animate-bounce">
              {unreadCount}
            </span>
          )}
        </button>
      )}

      {/* Main Support Window */}
      {isOpen && (
        <div
          id="support-chat-panel"
          className="bg-neutral-950 border border-neutral-900 rounded-xl shadow-2xl w-80 sm:w-96 h-[500px] flex flex-col overflow-hidden transition-all duration-300 transform translate-y-0 text-left border-amber-500/20"
        >
          {/* Header */}
          <div className="bg-neutral-900 border-b border-neutral-850 p-4 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500">
                <Shield className="h-4 w-4" />
              </div>
              <div>
                <h4 className="text-xs font-black uppercase text-white tracking-wider flex items-center gap-1.5">
                  ALEXFIT SUPPORT <span className="inline-block w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
                </h4>
                <p className="text-[10px] text-neutral-400 font-mono">Real-time Connection to Lead Coach</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-1">
              <button
                onClick={() => fetchChats(false)}
                disabled={loading}
                className="text-neutral-500 hover:text-white p-1 rounded transition-colors"
                title="Sync Chat"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin text-amber-500' : ''}`} />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="text-neutral-500 hover:text-neutral-200 p-1 rounded transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Messages Body */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-black/40 scrollbar-thin scrollbar-thumb-neutral-900 scrollbar-track-transparent">
            {showIntroForm ? (
              <div className="bg-neutral-900/40 border border-neutral-850 p-4 rounded text-center my-auto space-y-3">
                <span className="text-[10px] uppercase font-mono text-amber-500 font-bold block">Introduce Yourself</span>
                <p className="text-[11px] text-neutral-400 leading-relaxed font-light">
                  Type your name or email so our training administrator can route and address your concerns with personalized accuracy!
                </p>
                <div className="space-y-2 text-left">
                  <input
                    type="text"
                    placeholder="Enter Your Name (e.g. Kola)"
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    className="w-full bg-black border border-neutral-800 rounded p-2 text-xs text-white focus:border-amber-500 outline-none"
                  />
                  <input
                    type="email"
                    placeholder="Enter Your Email"
                    value={guestEmail}
                    onChange={(e) => setGuestEmail(e.target.value)}
                    className="w-full bg-black border border-neutral-800 rounded p-2 text-xs text-white focus:border-amber-500 outline-none"
                  />
                </div>
                <button
                  onClick={() => setFormSubmitted(true)}
                  className="w-full bg-amber-500/20 hover:bg-amber-500/30 text-amber-500 border border-amber-500/40 text-[10px] font-bold uppercase tracking-wider py-2 rounded-sm transition-all"
                >
                  Start Guest Chat
                </button>
              </div>
            ) : messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-2">
                <span className="text-2xl">👋</span>
                <h5 className="font-bebas text-lg text-white font-bold tracking-wide">Hub Support Active</h5>
                <p className="text-[11px] text-neutral-500 max-w-[220px]">
                  Send a message to our coaching desk. Responses are pushed to your screen immediately!
                </p>
              </div>
            ) : (
              messages.map((msg) => {
                const isAdmin = msg.senderRole === 'admin';
                return (
                  <div key={msg.id} className={`flex flex-col ${isAdmin ? 'items-start' : 'items-end'}`}>
                    {/* Tiny header labels */}
                    <div className="flex items-center space-x-1 mb-1 text-[9px] uppercase font-bold tracking-wider text-neutral-500 font-mono">
                      {isAdmin ? (
                        <>
                          <Shield className="h-2.5 w-2.5 text-amber-500" />
                          <span className="text-amber-500">Lead Coach Admin</span>
                        </>
                      ) : (
                        <>
                          <User className="h-2.5 w-2.5" />
                          <span>{msg.senderName}</span>
                        </>
                      )}
                      <span>•</span>
                      <span>
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    {/* Text block */}
                    <div className={`p-3 rounded-lg max-w-[85%] text-xs leading-relaxed break-words font-sans
                      ${isAdmin 
                        ? 'bg-neutral-900 border border-neutral-850 text-white rounded-tl-none' 
                        : 'bg-amber-500 text-black font-semibold rounded-tr-none'
                      }`}
                    >
                      {msg.message}
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Bottom Chat Inputs */}
          <form onSubmit={handleSendMessage} className="p-3 border-t border-neutral-900 bg-neutral-950 flex items-center space-x-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask us anything here..."
              disabled={isSending}
              className="flex-1 bg-black border border-neutral-800 rounded-lg p-2.5 text-xs text-white outline-none focus:border-amber-500 transition-colors disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={isSending || !inputText.trim()}
              className="bg-amber-500 hover:bg-amber-600 text-black p-2.5 rounded-lg transition-all flex items-center justify-center shadow hover:scale-105 active:scale-95 disabled:opacity-50 shrink-0"
            >
              {isSending ? (
                <span className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin"></span>
              ) : (
                <Send className="h-4 w-4" />
              )}
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
