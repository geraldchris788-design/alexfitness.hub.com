import 'dotenv/config';
import admin from 'firebase-admin';
import { getFirestore } from 'firebase-admin/firestore';
import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import nodemailer from 'nodemailer';
import { MongoClient } from 'mongodb';
import { sendEmail, renderEmailTemplate, globalSimulatedInboxes, registerEmailDbCallback } from './emailService';
import { MONNIFY_CONFIG } from './monnifyConfig';

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Path to our light JSON database
const DB_PATH = path.join(process.cwd(), 'db.json');

// Interface for DB
interface DatabaseSchema {
  users: any[];
  workouts: any[];
  meals: any[];
  progress: any[];
  payments: any[];
  questionsLog: any[];
  supportChats?: any[];
  emailLogs?: any[];
}

// Ensure local db exists with seed data
function loadDB(): DatabaseSchema {
  const initialSchema: DatabaseSchema = {
    users: [],
    workouts: [],
    meals: [],
    progress: [],
    payments: [],
    questionsLog: [],
    supportChats: [],
    emailLogs: []
  };

  try {
    if (fs.existsSync(DB_PATH)) {
      const data = fs.readFileSync(DB_PATH, 'utf-8');
      const loaded: DatabaseSchema = JSON.parse(data);
      
      // Strict Purge of synthetic mock details to comply with Requirement 2
      loaded.users = (loaded.users || []).filter(u => u.id !== 'demo-user');
      loaded.workouts = (loaded.workouts || []).filter(w => w.userId !== 'demo-user');
      loaded.meals = (loaded.meals || []).filter(m => m.userId !== 'demo-user');
      loaded.progress = (loaded.progress || []).filter(p => p.userId !== 'demo-user');
      loaded.supportChats = loaded.supportChats || [];

      fs.writeFileSync(DB_PATH, JSON.stringify(loaded, null, 2), 'utf-8');
      return loaded;
    }
  } catch (err) {
    console.error("Failed to read database, resetting to default schema", err);
  }
  
  fs.writeFileSync(DB_PATH, JSON.stringify(initialSchema, null, 2), 'utf-8');
  return initialSchema;
}

let mongoClient: MongoClient | null = null;
let mongoDb: any = null;

async function saveDB(newDb: DatabaseSchema) {
  db = newDb;
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error("Failed to write local backup database", err);
  }
  
  if (mongoDb) {
    try {
      const collection = mongoDb.collection('alexfit_data');
      await collection.updateOne(
        { type: 'db_state' },
        { $set: { data: db } },
        { upsert: true }
      );
      console.log("[DATABASE SYSTEM] Synchronized update securely to MongoDB.");
    } catch (err) {
      console.error("[DATABASE SYSTEM] MongoDB write synchronization failed.", err);
    }
  }

  if (adminDb && db.payments) {
    db.payments.forEach((paymentRecord: any) => {
      if (paymentRecord && paymentRecord.id) {
        syncToFirestore('payments', paymentRecord.id, paymentRecord);
      }
    });
  }

  if (adminDb && db.emailLogs) {
    db.emailLogs.forEach((logRecord: any) => {
      if (logRecord && logRecord.id) {
        syncToFirestore('emailLogs', logRecord.id, logRecord);
      }
    });
  }
}

async function initMongoDB() {
  const uri = process.env.MONGODB_URI;
  if (uri && uri !== "") {
    try {
      console.log(`[DATABASE SYSTEM] Attempting real-world MongoDB connection...`);
      mongoClient = new MongoClient(uri);
      await mongoClient.connect();
      mongoDb = mongoClient.db();
      console.log("[DATABASE SYSTEM] Connection to MongoDB established successfully.");
      
      const collection = mongoDb.collection('alexfit_data');
      const doc = await collection.findOne({ type: 'db_state' });
      if (doc && doc.data) {
        // Hydrate in-memory state with MongoDB data
        db = doc.data;
        console.log("[DATABASE SYSTEM] Successfully loaded application state from MongoDB.");
      } else {
        await collection.updateOne(
          { type: 'db_state' },
          { $set: { data: db } },
          { upsert: true }
        );
        console.log("[DATABASE SYSTEM] Seeded initial database state to MongoDB collections.");
      }
    } catch (err) {
      console.error("[DATABASE SYSTEM] Real-world MongoDB connection failed. Operating with secure JSON-DB driver.", err);
    }
  }
}

// ----------------------------------------------------------------------------
// SECURITY HELPERS (Hashing, Rate Limiting, JWT Simulation, CSRF Checks)
// ----------------------------------------------------------------------------

function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password + '_alexfit_secret_salt_2271').digest('hex');
}

// In-memory sliding rate limiter bypassed to prevent reverse-proxy lockout blocks on Cloud Run
function rateLimiter(req: express.Request, res: express.Response, next: express.NextFunction) {
  next();
}

// CSRF Protection Simulated Validation Logger
function csrfProtection(req: express.Request, res: express.Response, next: express.NextFunction) {
  // Only target actual API routes to avoid cluttering logs with static web assets
  if (!req.path.startsWith('/api')) {
    return next();
  }
  // Checks for mock tokens or custom client requests metadata
  const csrfToken = req.headers['x-csrf-token'];
  console.log(`[CSRF PROTECTION ACTIVE]: Verifying safety signature for path ${req.path}. Header Token: ${csrfToken || 'NONE/CLIENT_SPA_RESOLVED'}`);
  next();
}

app.use(rateLimiter);
app.use(csrfProtection);

// MONGODB CONNECTION STATE (Checks env and establishes or logs)
const mongodbUriExists = !!process.env.MONGODB_URI;
console.log(`[DATABASE SYSTEM] MONGODB_URI presence verified: ${mongodbUriExists}. Falling back safely to high-performance local db.json if Atlas not connected.`);

// Initialize database
let db = loadDB();
initMongoDB();

// Resend / SMTP email delivery logger hook
registerEmailDbCallback(async (logEntry) => {
  db.emailLogs = db.emailLogs || [];
  const existingIdx = db.emailLogs.findIndex(l => l.id === logEntry.id);
  if (existingIdx > -1) {
    db.emailLogs[existingIdx] = { ...db.emailLogs[existingIdx], ...logEntry };
  } else {
    db.emailLogs.unshift(logEntry);
  }
  if (db.emailLogs.length > 100) {
    db.emailLogs.pop();
  }
  await saveDB(db);
});

// Initialize Firebase Admin SDK
let adminDb: admin.firestore.Firestore | null = null;
try {
  const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
  let projectId: string | null = process.env.VITE_FIREBASE_PROJECT_ID || process.env.FIREBASE_PROJECT_ID || null;
  let databaseId: string | null = process.env.VITE_FIREBASE_DATABASE_ID || process.env.FIREBASE_DATABASE_ID || null;

  let staticFirebaseConfig: any = {};
  if (fs.existsSync(configPath)) {
    staticFirebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    if (!projectId) projectId = staticFirebaseConfig.projectId;
    if (!databaseId) databaseId = staticFirebaseConfig.firestoreDatabaseId;
  }

  // Check for local service account key file
  const serviceKeyPath = path.join(process.cwd(), 'firebase-service-key.json');
  const hasServiceKey = fs.existsSync(serviceKeyPath);
  const isProductionOrRender = process.env.RENDER === 'true' || process.env.NODE_ENV === 'production';
  if (!hasServiceKey && !isProductionOrRender && (projectId === 'alexproject777' || projectId === 'alex-project-777' || projectId === 'auspicious-album-qszp9')) {
    projectId = 'auspicious-album-qszp9';
    databaseId = 'ai-studio-e2b1ccac-2ecb-4b46-96be-6ad4f63c5cef';
    console.log(`[FIREBASE ADMIN] Sandbox environment detected. Routing to auto-authorized platform sandbox: ${projectId}`);
  }

  let serviceAccount: any = null;
  if (hasServiceKey) {
    try {
      const sa = JSON.parse(fs.readFileSync(serviceKeyPath, 'utf8'));
      // Only use service account if it matches the current active projectId
      if (sa && sa.project_id && sa.project_id === staticFirebaseConfig.projectId) {
        serviceAccount = sa;
      } else {
        console.warn(`[FIREBASE ADMIN] Service key project mismatch (key: ${sa?.project_id}, active: ${staticFirebaseConfig.projectId}). Ignoring key to avoid conflicts.`);
      }
    } catch (_) {}
  }

  if (serviceAccount && serviceAccount.project_id) {
    const adminApp = admin.initializeApp({
      credential: admin.credential.cert(serviceAccount)
    });
    const dbId = databaseId || '(default)';
    adminDb = dbId && dbId !== '(default)' ? getFirestore(adminApp, dbId) as any : getFirestore(adminApp) as any;
    console.log(`[FIREBASE ADMIN] Initialized successfully with cert for project: ${serviceAccount.project_id}, database: ${dbId}`);
    hydrateFromFirestore();
  } else if (projectId) {
    // Fallback if no valid service account key matching current project (e.g. running in Cloud Run container with auto ADC)
    // To prevent project-mismatch permission errors in containers, we try initializing without options to let ADC resolve the host project
    let adminApp: any;
    if (admin.apps.length > 0) {
      adminApp = admin.apps[0];
      console.log(`[FIREBASE ADMIN] Reusing existing authorized Firebase app instance.`);
    } else {
      try {
        adminApp = admin.initializeApp();
        console.log(`[FIREBASE ADMIN] Initialized implicitly with host container credentials.`);
      } catch (_) {
        adminApp = admin.initializeApp({
          projectId: projectId
        });
        console.log(`[FIREBASE ADMIN] Initialized with config credentials for project: ${projectId}`);
      }
    }
    const dbId = databaseId || '(default)';
    adminDb = dbId && dbId !== '(default)' ? getFirestore(adminApp, dbId) as any : getFirestore(adminApp) as any;
    console.log(`[FIREBASE ADMIN] Configured target database: ${dbId}`);
    hydrateFromFirestore();
  } else {
    console.warn("[FIREBASE ADMIN] No valid config or certificate found. Offline operation only.");
  }
} catch (adminErr) {
  console.error("[FIREBASE ADMIN ERROR] Initialization failed:", adminErr);
}

function mergeLists(localList: any[], remoteList: any[]): any[] {
  const mergedMap = new Map();
  (localList || []).forEach(item => {
    if (item && item.id) mergedMap.set(item.id, item);
  });
  (remoteList || []).forEach(item => {
    if (item && item.id) mergedMap.set(item.id, item);
  });
  return Array.from(mergedMap.values());
}

async function hydrateFromFirestore() {
  if (!adminDb) return;
  console.log("[FIREBASE ADMIN] Hydrating local database with records from live Firestore...");
  try {
    // Hydrate users
    const usersSnap = await adminDb.collection('users').get();
    const usersList: any[] = [];
    usersSnap.forEach(docSnap => {
      usersList.push(docSnap.data());
    });
    if (usersList.length > 0) {
      db.users = mergeLists(db.users, usersList);
    }

    // Hydrate workouts
    const workoutsSnap = await adminDb.collection('workouts').get();
    const workoutsList: any[] = [];
    workoutsSnap.forEach(docSnap => {
      workoutsList.push(docSnap.data());
    });
    if (workoutsList.length > 0) {
      db.workouts = mergeLists(db.workouts, workoutsList);
    }

    // Hydrate meals
    const mealsSnap = await adminDb.collection('meals').get();
    const mealsList: any[] = [];
    mealsSnap.forEach(docSnap => {
      mealsList.push(docSnap.data());
    });
    if (mealsList.length > 0) {
      db.meals = mergeLists(db.meals, mealsList);
    }

    // Hydrate progress
    const progressSnap = await adminDb.collection('progress').get();
    const progressList: any[] = [];
    progressSnap.forEach(docSnap => {
      progressList.push(docSnap.data());
    });
    if (progressList.length > 0) {
      db.progress = mergeLists(db.progress, progressList);
    }

    // Hydrate supportChats
    const chatsSnap = await adminDb.collection('supportChats').get();
    const chatsList: any[] = [];
    chatsSnap.forEach(docSnap => {
      chatsList.push(docSnap.data());
    });
    if (chatsList.length > 0) {
      if (!db.supportChats) db.supportChats = [];
      db.supportChats = mergeLists(db.supportChats, chatsList);
    }

    // Hydrate payments
    const paymentsSnap = await adminDb.collection('payments').get();
    const paymentsList: any[] = [];
    paymentsSnap.forEach(docSnap => {
      paymentsList.push(docSnap.data());
    });
    if (paymentsList.length > 0) {
      db.payments = mergeLists(db.payments, paymentsList);
    }

    // Hydrate emailLogs
    const emailLogsSnap = await adminDb.collection('emailLogs').get();
    const emailLogsList: any[] = [];
    emailLogsSnap.forEach(docSnap => {
      emailLogsList.push(docSnap.data());
    });
    if (emailLogsList.length > 0) {
      db.emailLogs = mergeLists(db.emailLogs || [], emailLogsList);
    }

    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf-8');
    console.log("[FIREBASE ADMIN] Local database fully hydrated and synchronized with Firestore.");
  } catch (err) {
    console.error("[FIREBASE ADMIN HYDRATION ERROR]", err);
  }
}

async function syncToFirestore(collectionName: string, docId: string, data: any) {
  if (!adminDb) return;
  try {
    const cleaned = { ...data };
    if ('password' in cleaned) {
      delete cleaned.password;
    }
    await adminDb.collection(collectionName).doc(docId).set(cleaned, { merge: true });
    console.log(`[FIREBASE ADMIN] Successfully synced document ${docId} to Firestore collection ${collectionName}.`);
  } catch (err) {
    console.error(`[FIREBASE ADMIN SYNC ERROR] Failed to sync ${docId} to collection ${collectionName}:`, err);
  }
}

// Initialize GoogleGenAI client lazily to avoid startup crash if key is missing
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
      aiClient = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
  }
  return aiClient;
}

// ----------------------------------------------------------------------------
// INTERACTIVE EMAIL SANDBOX & EMAIL SERVICES DEFINED SECURELY IN emailService.ts
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// API ROUTES
// ----------------------------------------------------------------------------

// 1. Health check
app.get('/api/health', (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// Helper to get category-relevant aesthetic fallbacks to avoid duplicate generic image displays
function getFallbackImage(url: string): string {
  const norm = url.toLowerCase();
  
  if (norm.includes('squat') || norm.includes('legs') || norm.includes('lunge') || norm.includes('quad') || norm.includes('calf') || norm.includes('hamstring') || norm.includes('leg-press') || norm.includes('leg-curl') || norm.includes('leg-extension')) {
    return 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?q=80&w=600&auto=format&fit=crop'; // Deep squat leg motivation
  }
  if (norm.includes('bench') || norm.includes('press') || norm.includes('chest') || norm.includes('pushup') || norm.includes('push-up') || norm.includes('pec')) {
    return 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=600&auto=format&fit=crop'; // Push up chest
  }
  if (norm.includes('row') || norm.includes('deadlift') || norm.includes('pullup') || norm.includes('pull-up') || norm.includes('lat') || norm.includes('back') || norm.includes('chinup') || norm.includes('chin-up')) {
    return 'https://images.unsplash.com/photo-1603398938378-e54eab446dde?q=80&w=600&auto=format&fit=crop'; // Deadlift pull-up back
  }
  if (norm.includes('shoulder') || norm.includes('raise') || norm.includes('deltoid') || norm.includes('military')) {
    return 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=600&auto=format&fit=crop'; // Shoulder press
  }
  if (norm.includes('curl') || norm.includes('tricep') || norm.includes('bicep') || norm.includes('arm')) {
    return 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?q=80&w=600&auto=format&fit=crop'; // Arms bicep curl
  }
  if (norm.includes('plank') || norm.includes('ab') || norm.includes('core') || norm.includes('situp') || norm.includes('crunch')) {
    return 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=600&auto=format&fit=crop'; // Core abs
  }
  if (norm.includes('run') || norm.includes('cardio') || norm.includes('treadmill') || norm.includes('jump') || norm.includes('box')) {
    return 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?q=80&w=600&auto=format&fit=crop'; // Running cardio
  }
  if (norm.includes('yoga') || norm.includes('stretch') || norm.includes('pilates') || norm.includes('downward')) {
    return 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=600&auto=format&fit=crop'; // Stretching
  }
  
  // Default general high-quality gym image
  return 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=600&auto=format&fit=crop';
}

// 1.5 Image and GIF Proxy Route to bypass hotlinking, CORS, and Referer blocks from Pinterest/Pinimg and FitnessProgramer
app.get('/api/proxy-image', async (req, res) => {
  const imageUrl = req.query.url;
  if (!imageUrl || typeof imageUrl !== 'string') {
    return res.status(400).send('Image URL is required');
  }

  // Security: only allow proxying valid http/https remote image resources
  if (!imageUrl.startsWith('http://') && !imageUrl.startsWith('https://')) {
    return res.status(400).send('Invalid image URL protocol');
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12000); // 12 second timeout

    // Derive host-specific referer check bypass
    let referer = '';
    try {
      const parsedUrl = new URL(imageUrl);
      referer = `${parsedUrl.protocol}//${parsedUrl.host}/`;
    } catch {
      // Avoid breaking if URL cannot be parsed
    }

    const response = await fetch(imageUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'image/*, */*',
        'Referer': referer // Match host origin to bypass security check spoofing
      },
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Failed to fetch remote source image: ${response.status} ${response.statusText}`);
    }

    const contentType = response.headers.get('content-type') || 'image/jpeg';
    
    // Cache on client / CDN to optimize load times and reduce load on target server
    res.setHeader('Content-Type', contentType);
    res.setHeader('Cache-Control', 'public, max-age=172800'); // Cache for 48 hours

    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    res.send(buffer);
  } catch (err: any) {
    console.warn(`[IMAGE PROXY WARNING]: Failed to proxy image ${imageUrl} (falling back to alternative): ${err.message}`);
    
    // Fallback to images.weserv.nl for high probability of successful load
    if (!imageUrl.includes('weserv.nl')) {
      return res.redirect(`https://images.weserv.nl/?url=${encodeURIComponent(imageUrl)}`);
    }

    // Serving highly aesthetic category-specific workout graphic fallback from Unsplash
    res.redirect(getFallbackImage(imageUrl));
  }
});

// In-memory rate limiter specifically for verification email resends (60-second cooldown per email)
const lastResendTimeByEmail = new Map<string, number>();

// Transactional Delivery Board - Retrieve email log history for full visibility
app.get('/api/auth/simulated-emails', (req, res) => {
  res.json(globalSimulatedInboxes);
});

// Database email delivery history retrieval
app.get('/api/auth/email-logs', (req, res) => {
  res.json(db.emailLogs || []);
});

// Send streak achievement email
app.post('/api/auth/send-streak-email', async (req, res) => {
  const { userId, currentStreak, longestStreak, milestoneReached } = req.body;
  if (!userId) return res.status(400).json({ error: "Missing userId" });
  
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ error: "User not found" });
  
  const quotes = [
    "Consistency is the absolute key to permanent evolution. What we log today, we master tomorrow.",
    "The translation of sweat into steel happens daily. Never break the chain!",
    "Your future self is begging you not to quit today. Excellent work maintaining this momentum!",
    "Success is not owned, it is leased, and rent is due every single day. Keep crushing it!"
  ];
  const quote = quotes[Math.floor(Math.random() * quotes.length)];
  
  const streakHtml = renderEmailTemplate('streak_achievement', {
    name: user.name,
    currentStreak: currentStreak || 1,
    longestStreak: longestStreak || 1,
    milestone: milestoneReached,
    motivationalQuote: quote
  });
  
  sendEmail({
    to: user.email,
    subject: `Congratulations on Your Fitness Streak`,
    html: streakHtml,
    text: `Congratulations on hitting a ${currentStreak || 1}-day activity streak with ALEXFITNESSHUB!`,
    type: 'streak_achievement'
  }).catch(e => console.error(e));
  
  res.json({ success: true, message: "Streak achievement email queued successfully!" });
});

// Send weekly progress report email
app.post('/api/auth/send-weekly-report', async (req, res) => {
  const { userId, workoutsCount, caloriesBurned, completedGoalsCount, activeDays, progressWeightChange } = req.body;
  if (!userId) return res.status(400).json({ error: "Missing userId" });
  
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ error: "User not found" });
  
  const today = new Date();
  const lastWeek = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  
  const reportHtml = renderEmailTemplate('weekly_report', {
    name: user.name,
    workoutsCount: workoutsCount || 0,
    caloriesBurned: caloriesBurned || 0,
    completedGoalsCount: completedGoalsCount || 0,
    activeDays: activeDays || 0,
    progressWeightChange: progressWeightChange || "0.0 kg",
    weekStart: lastWeek.toLocaleDateString(),
    weekEnd: today.toLocaleDateString()
  });
  
  sendEmail({
    to: user.email,
    subject: `Your Weekly Fitness Progress`,
    html: reportHtml,
    text: `Your weekly fitness report is ready. You completed ${workoutsCount || 0} workouts!`,
    type: 'weekly_report'
  }).catch(e => console.error(e));
  
  res.json({ success: true, message: "Weekly progress report email dispatched successfully!" });
});

// Send daily workout reminder email
app.post('/api/auth/send-workout-reminder', async (req, res) => {
  const { userId, splitName } = req.body;
  if (!userId) return res.status(400).json({ error: "Missing userId" });
  
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ error: "User not found" });
  
  const reminderHtml = renderEmailTemplate('workout_reminder', {
    name: user.name,
    splitName: splitName || "Compound Hypertrophy (Full Body)",
    dashboardUrl: process.env.APP_URL ? `${process.env.APP_URL}/dashboard` : undefined
  });
  
  sendEmail({
    to: user.email,
    subject: `Workout Reminder: Time to Crush Your Goals!`,
    html: reminderHtml,
    text: `Workout reminder from Coach Alex. Today's target: ${splitName || 'Compound Hypertrophy'}`,
    type: 'workout_reminder'
  }).catch(e => console.error(e));
  
  res.json({ success: true, message: "Workout reminder email dispatched successfully!" });
});

// Resend Verification Email Hook
app.post('/api/auth/resend-verification', (req, res) => {
  const { email } = req.body;
  if (!email || typeof email !== 'string') {
    return res.status(400).json({ error: "A valid account email address is required" });
  }

  // Basic email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: "Invalid email format payload" });
  }

  const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (!user) {
    return res.status(404).json({ error: "No user found with this email" });
  }

  if (user.isVerified) {
    return res.status(400).json({ error: "This email address is already verified and active. You can log in." });
  }

  // Rate Limiting Prevention against spam and abuse
  const now = Date.now();
  const lastTime = lastResendTimeByEmail.get(email.toLowerCase()) || 0;
  const cooldownPeriod = 60 * 1000; // 60 seconds
  if (now - lastTime < cooldownPeriod) {
    const secondsRemaining = Math.ceil((cooldownPeriod - (now - lastTime)) / 1000);
    return res.status(429).json({
      error: `Please wait ${secondsRemaining} second(s) before requesting another verification link.`
    });
  }

  // Generate cryptographically secure token & expiration (24 Hour TTL)
  const rawToken = crypto.randomBytes(32).toString('hex');
  const hashedToken = crypto.createHash('sha256').update(rawToken).digest('hex');

  user.verificationToken = hashedToken;
  user.verificationTokenExpiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24 hours expiry
  saveDB(db);

  // Set rate limiter timestamp
  lastResendTimeByEmail.set(email.toLowerCase(), now);

  // Dynamic absolute host name translation
  const protocol = req.headers['x-forwarded-proto'] || 'http';
  const host = req.headers.host;
  const origin = process.env.APP_URL ? process.env.APP_URL : `${protocol}://${host}`;
  const verifyUrl = `${origin}/verify-email?token=${rawToken}&email=${encodeURIComponent(user.email)}`;

  const html = renderEmailTemplate('verify', {
    name: user.name,
    verifyUrl: verifyUrl
  });
  
  const text = `Verify your ALEXFITNESSHUB account by loading this URL in your browser: ${verifyUrl}`;
  
  sendEmail({
    to: user.email,
    subject: `🔑 Confirm Your ALEXFITNESSHUB Account Verification Session`,
    html,
    text,
    type: 'verify'
  }).catch(e => console.error("Resend error async dispatch failed", e));

  console.log(`[EMAIL DISPATCH] Secure verification token refreshed and resent for ${user.email}.`);
  res.json({ success: true, message: "A fresh cryptographic verification link has been dispatched. Check your inbox!" });
});

// Complete Account Verification API endpoint
app.get('/api/auth/verify', (req, res) => {
  const { token, email } = req.query;
  if (!token || !email || typeof token !== 'string' || typeof email !== 'string') {
    return res.status(400).json({ error: "Both a validation token and registered account email are required." });
  }

  const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (!user) {
    return res.status(400).json({ error: "Invalid registration state. User record not found." });
  }

  // Already verified graceful resolution
  if (user.isVerified) {
    return res.json({ success: true, message: "Your account has already been verified! You can proceed to login." });
  }

  // Hash incoming token with SHA-256 and match
  const hashedIncoming = crypto.createHash('sha256').update(token).digest('hex');
  
  if (user.verificationToken !== hashedIncoming) {
    return res.status(400).json({ error: "The email verification security signature is invalid or has already been used." });
  }

  // Expiration check (24 Hours)
  const tokenExpiry = Number(user.verificationTokenExpiresAt || 0);
  if (Date.now() > tokenExpiry) {
    return res.status(400).json({ error: "Your verification token has expired. Please log in to request a fresh token link." });
  }

  // Finalize verification state
  user.isVerified = true;
  user.verificationToken = null;
  user.verificationTokenExpiresAt = null;
  saveDB(db);

  // Send Welcome Email
  const protocol = req.headers['x-forwarded-proto'] || 'http';
  const host = req.headers.host;
  const loginUrl = `${protocol}://${host}/auth/login`;

  const welcomeHtml = renderEmailTemplate('welcome', {
    name: user.name,
    userId: user.id,
    email: user.email,
    loginUrl: loginUrl
  });
  
  const welcomeText = `Welcome, ${user.name}! Your ALEXFITNESSHUB account is fully activated. Launch your profile at: ${loginUrl}`;
  
  sendEmail({
    to: user.email,
    subject: `🔥 Welcome to ALEXFITNESSHUB Elite Community!`,
    html: welcomeHtml,
    text: welcomeText,
    type: 'welcome'
  }).catch(e => console.error("Welcome email async dispatch failed", e));

  console.log(`[VERIFY MASTER] Cryptographic verification success for ${user.email}. welcome letter issued.`);
  res.json({ success: true, message: "Excellent! Your email has been successfully verified. You can now login to your personal performance logs." });
});

// Forgot / Reset Password Channel
app.post('/api/auth/forgot-password', (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: "Email address required" });

  const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (!user) return res.status(404).json({ error: "Email not registered with ALEXFITNESSHUB" });

  const resetToken = `reset-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  user.resetPasswordToken = resetToken;
  saveDB(db);

  const resetHtml = renderEmailTemplate('reset', {
    name: user.name,
    resetUrl: `/verify-payment?resetToken=${resetToken}&email=${user.email}`
  });
  const resetText = `Your password reset code is ${resetToken}`;
  sendEmail({
    to: user.email,
    subject: `🔐 ALEXFITNESSHUB Secure Password Reset Request`,
    html: resetHtml,
    text: resetText,
    type: 'reset'
  }).catch(e => console.error("Forgot password async dispatch error", e));

  console.log(`[EMAIL SYSTEM] Password Reset link dispatched successfully to user inbox for: ${user.email}`);
  res.json({ success: true, message: "Secure recovery link dispatched to your registered email!" });
});

app.post('/api/auth/reset-password', (req, res) => {
  const { email, resetToken, newPassword } = req.body;
  if (!email || !resetToken || !newPassword) {
    return res.status(400).json({ error: "Missing email, token, or password payload" });
  }

  const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.resetPasswordToken === resetToken);
  if (!user) return res.status(400).json({ error: "Invalid reset token or email details" });

  // Update password with hash
  user.password = hashPassword(newPassword);
  user.resetPasswordToken = null;
  saveDB(db);

  console.log(`[EMAIL SYSTEM] Password updated successfully for: ${user.email}`);
  res.json({ success: true, message: "Your account password has been safely updated. Please login." });
});

// Helper functions for HTTP Cookie authentication sessions
function getUserIdFromRequest(req: any): string | null {
  // 1. Check cookies securely and cleanly
  const cookieHeader = req.headers.cookie || '';
  const cookies: Record<string, string> = {};
  cookieHeader.split(';').forEach((c: string) => {
    const parts = c.trim().split('=');
    if (parts.length >= 2) {
      cookies[parts[0].trim()] = parts.slice(1).join('=').trim();
    }
  });

  const sessionCookie = cookies['alexfit_session'];
  if (sessionCookie) {
    const sessionToken = decodeURIComponent(sessionCookie);
    if (sessionToken.startsWith('sess-')) {
      const parts = sessionToken.split('-');
      if (parts[1]) return parts[1];
    }
  }
  
  // 2. Check Bearer Authorization header
  const authHeader = req.headers.authorization || '';
  if (authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    if (token.startsWith('sess-')) {
      const parts = token.split('-');
      if (parts[1]) return parts[1];
    }
  }
  return null;
}

function isPremiumUser(user: any): boolean {
  if (!user) return false;
  const isTestOrAdmin = user.email === 'muzikworld08@gmail.com' || user.role === 'admin';
  if (isTestOrAdmin) return true;
  return user.subscriptionPlan !== 'free' && user.subscriptionStatus === 'active';
}

function activatePremiumSubscription(user: any, planType: string, txId: string) {
  let monthsToAdd = 1;
  let selectedPlan: 'free' | 'monthly' | 'yearly' = 'monthly';
  const planLower = (planType || '').toLowerCase();
  
  if (planLower.includes('year') || planLower.includes('annual')) {
    monthsToAdd = 12;
    selectedPlan = 'yearly';
  } else {
    const match = planLower.match(/(\d+)\s*month/);
    if (match) {
      monthsToAdd = parseInt(match[1]);
    }
  }
  
  const startDate = new Date();
  const endDate = new Date();
  endDate.setMonth(startDate.getMonth() + monthsToAdd);
  
  user.subscriptionPlan = selectedPlan;
  user.subscriptionStatus = 'active';
  user.paymentStatus = 'paid';
  user.paymentDate = startDate.toISOString();
  user.subscriptionStartDate = startDate.toISOString();
  user.subscriptionEndDate = endDate.toISOString();
  user.transactionId = txId || `tx-${Date.now()}`;
  
  return user;
}

function setSessionCookie(res: any, userId: string) {
  const sessionToken = `sess-${userId}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  res.setHeader('Set-Cookie', `alexfit_session=${encodeURIComponent(sessionToken)}; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=2592000`);
  return sessionToken;
}

function clearSessionCookie(res: any) {
  res.setHeader('Set-Cookie', `alexfit_session=; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=0`);
}

// 2. Authentication APIs
app.get('/api/auth/me', (req, res) => {
  const userId = getUserIdFromRequest(req);
  if (!userId) {
    return res.status(401).json({ error: "Unauthorized session" });
  }
  const user = db.users.find(u => u.id === userId);
  if (!user) {
    return res.status(401).json({ error: "User session not found" });
  }

  // Automatic subscription expiration check
  if (user.subscriptionPlan && user.subscriptionPlan !== 'free' && user.subscriptionStatus === 'active' && user.subscriptionEndDate) {
    const now = new Date();
    const endDate = new Date(user.subscriptionEndDate);
    if (endDate < now) {
      user.subscriptionPlan = 'free';
      user.subscriptionStatus = 'expired';
      user.paymentStatus = 'unpaid';
      saveDB(db);
      syncToFirestore('users', user.id, user);
      console.log(`[SUBSCRIPTION SYSTEM] Auto-expired subscription for user ${user.email}.`);
    }
  }

  // Auto-verify user session if they are somehow not marked verified yet
  if (user.isVerified !== true) {
    user.isVerified = true;
    saveDB(db);
    syncToFirestore('users', user.id, user);
  }
  res.json({ user });
});

app.post('/api/auth/logout', (req, res) => {
  clearSessionCookie(res);
  res.json({ success: true, message: "Logged out successfully" });
});

app.post('/api/auth/sync-session', (req, res) => {
  const { id, email, name, isVerified, avatarUrl, authProvider } = req.body;
  if (!id || !email) {
    return res.status(400).json({ error: "Missing required session synchronization parameters: id and email" });
  }

  let user = db.users.find(u => u.id === id || u.email.toLowerCase() === email.toLowerCase());
  if (!user) {
    user = {
      id,
      name: name.trim(),
      email: email.toLowerCase(),
      password: hashPassword(crypto.randomBytes(16).toString('hex')), // unique placeholder password
      subscriptionPlan: "free",
      subscriptionStatus: "inactive",
      paymentStatus: "unpaid",
      paymentDate: "",
      subscriptionStartDate: "",
      subscriptionEndDate: "",
      transactionId: "",
      isVerified: isVerified || false,
      verificationToken: null,
      verificationTokenExpiresAt: null,
      fitnessGoals: [],
      currentWeight: 80,
      targetWeight: 75,
      height: 175,
      age: 25,
      gender: "Not specified",
      activityLevel: "Not specified",
      avatarUrl: avatarUrl || "",
      authProvider: authProvider || "password",
      createdAt: new Date().toISOString()
    };
    db.users.push(user);
  } else {
    // Sync newly provided profile pic or authentication provider info
    if (avatarUrl && !user.avatarUrl) {
      user.avatarUrl = avatarUrl;
    }
    if (authProvider && !user.authProvider) {
      user.authProvider = authProvider;
    }
    if (!user.createdAt) {
      user.createdAt = new Date().toISOString();
    }
    // Check if subscription needs expiration here too
    if (user.subscriptionPlan && user.subscriptionPlan !== 'free' && user.subscriptionStatus === 'active' && user.subscriptionEndDate) {
      const now = new Date();
      const endDate = new Date(user.subscriptionEndDate);
      if (endDate < now) {
        user.subscriptionPlan = 'free';
        user.subscriptionStatus = 'expired';
        user.paymentStatus = 'unpaid';
        console.log(`[SUBSCRIPTION SYSTEM] Auto-expired subscription for synced user ${user.email}.`);
      }
    }

    // Keep user state synchronized with Firebase
    if (user.id !== id) {
      const oldId = user.id;
      user.id = id;
      
      // Remap all historical data references from the old local ID to their new Firebase UID
      db.workouts = (db.workouts || []).map(w => w.userId === oldId ? { ...w, userId: id } : w);
      db.meals = (db.meals || []).map(m => m.userId === oldId ? { ...m, userId: id } : m);
      db.progress = (db.progress || []).map(p => p.userId === oldId ? { ...p, userId: id } : p);
      db.payments = (db.payments || []).map(pay => pay.userId === oldId ? { ...pay, userId: id } : pay);
      if (db.supportChats) {
        db.supportChats = db.supportChats.map(c => c.chatSessionId === oldId ? { ...c, chatSessionId: id } : c);
      }
      console.log(`[DYNAMIC MIGRATION] Remapped historical collections for user ${email} from old ID ${oldId} to new Firebase UID ${id}.`);
    }
    if (isVerified !== undefined) {
      user.isVerified = isVerified;
    }
  }

  saveDB(db);
  syncToFirestore('users', user.id, user);
  const token = setSessionCookie(res, user.id);
  res.json({ success: true, user, token });
});

app.post('/api/auth/send-welcome-email', (req, res) => {
  const { email, name } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Missing required parameter: email" });
  }

  const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  const useName = name || (user ? user.name : 'Athlete');

  const protocol = req.headers['x-forwarded-proto'] || 'http';
  const host = req.headers.host;
  const loginUrl = process.env.APP_URL ? `${process.env.APP_URL}/auth/login` : `${protocol}://${host}/auth/login`;

  const welcomeHtml = renderEmailTemplate('welcome', {
    name: useName,
    email: email,
    loginUrl: loginUrl
  });
  
  const welcomeText = `Welcome, ${useName}! Your ALEXFITNESSHUB account is fully activated. Launch your profile at: ${loginUrl}`;
  
  sendEmail({
    to: email,
    subject: `🔥 Welcome to ALEXFITNESSHUB Elite Community!`,
    html: welcomeHtml,
    text: welcomeText,
    type: 'welcome'
  }).catch(e => console.error("Welcome email async dispatch failed", e));

  res.json({ success: true, message: "Welcome email dispatched successfully!" });
});

app.post('/api/auth/register', (req, res) => {
  const { name, email, password } = req.body;
  
  // High-Integrity Input Validation
  if (!name || typeof name !== 'string' || name.trim().length === 0) {
    return res.status(400).json({ error: "Missing or invalid parameter: name" });
  }
  if (!email || typeof email !== 'string') {
    return res.status(400).json({ error: "Missing or invalid parameter: email" });
  }
  if (!password || typeof password !== 'string' || password.length < 6) {
    return res.status(400).json({ error: "Invalid password. Security requires a minimum of 6 characters." });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: "Invalid email syntax format." });
  }

  const existing = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return res.status(400).json({ error: "Email already exists in our master register." });
  }

  // Cryptographically secure random tokens
  const rawToken = crypto.randomBytes(32).toString('hex');
  const hashedToken = crypto.createHash('sha256').update(rawToken).digest('hex');

  const newUser = {
    id: `u-${Date.now()}`,
    name: name.trim(),
    email: email.toLowerCase(),
    password: hashPassword(password), // Hashed securely
    subscriptionPlan: "free",
    subscriptionStatus: "inactive",
    paymentStatus: "unpaid",
    paymentDate: "",
    subscriptionStartDate: "",
    subscriptionEndDate: "",
    transactionId: "",
    isVerified: false, // Must verify email to access protected features
    verificationToken: hashedToken,
    verificationTokenExpiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours expiry
    fitnessGoals: [],
    currentWeight: 80,
    targetWeight: 75,
    height: 175,
    age: 25,
    gender: "Not specified",
    activityLevel: "Not specified",
    lastDevice: req.headers['user-agent'] || 'Unknown Device'
  };

  db.users.push(newUser);
  saveDB(db);
  syncToFirestore('users', newUser.id, newUser);

  // Dynamic absolute host name translation (with referer fallback to handle reverse proxy routing gracefully)
  const protocol = req.headers['x-forwarded-proto'] || 'http';
  const host = req.headers.host;
  let origin = process.env.APP_URL ? process.env.APP_URL : `${protocol}://${host}`;
  if (!process.env.APP_URL && req.headers.referer) {
    try {
      const parsedReferer = new URL(req.headers.referer);
      origin = parsedReferer.origin;
    } catch (_) {}
  }
  const verifyUrl = `${origin}/verify-email?token=${rawToken}&email=${encodeURIComponent(newUser.email)}`;

  // Dispatch Verification Email
  const regHtml = renderEmailTemplate('verify', {
    name: newUser.name,
    verifyUrl: verifyUrl
  });
  const regText = `Verify your ALEXFITNESSHUB account by loading this URL in your browser: ${verifyUrl}`;
  
  sendEmail({
    to: newUser.email,
    subject: `Verify Your Email Address`,
    html: regHtml,
    text: regText,
    type: 'verify'
  }).catch(e => console.error("Register email async dispatch failed", e));

  // Dispatch Welcome Email immediately upon registration (Welcome to ALEXFITNESSHUB)
  const welcomeHtml = renderEmailTemplate('welcome', {
    name: newUser.name,
    email: newUser.email,
    loginUrl: `${origin}/auth/login`,
    verifyUrl: verifyUrl
  });

  sendEmail({
    to: newUser.email,
    subject: `Welcome to ALEXFITNESSHUB`,
    html: welcomeHtml,
    text: `Welcome to ALEXFITNESSHUB, ${newUser.name}! Please finalize your verification here: ${verifyUrl}`,
    type: 'welcome'
  }).catch(e => console.error("Welcome email async dispatch failed", e));

  console.log(`[SIGN UP SUCCESS] Verification Email generated successfully for ${newUser.email}`);

  // Automatically sign the user in with a secure session cookie
  const token = setSessionCookie(res, newUser.id);
  res.status(201).json({ user: newUser, token });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: "Email and password required" });

  const hashedInput = hashPassword(password);
  
  // Try hashed matching, fallback to exact matching for backwards-compatibility of pre-saved seeds
  const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase() && (u.password === hashedInput || u.password === password));
  
  if (!user) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  // Check for device alterations and dispatch security login alerts
  const currentDevice = (req.headers['user-agent'] || 'Unknown Device').toString();
  const currentIp = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '102.89.23.4').toString();

  if (user.lastDevice && user.lastDevice !== currentDevice) {
    const alertHtml = renderEmailTemplate('login_alert', {
      name: user.name,
      device: currentDevice,
      date: new Date().toLocaleDateString(),
      time: new Date().toUTCString().split(' ')[4] + ' UTC',
      ip: currentIp
    });

    sendEmail({
      to: user.email,
      subject: `New Login Detected`,
      html: alertHtml,
      text: `Security alert: We detected a new sign-in to your Coach Alex account from a different device: ${currentDevice}`,
      type: 'login_alert'
    }).catch(e => console.error("New device login alert dispatch failed", e));
  }

  user.lastDevice = currentDevice;
  saveDB(db);

  const token = setSessionCookie(res, user.id);
  res.json({ user, token });
});

// Real Google Authentication URLs & Redirections
app.get('/api/auth/google/url', (req, res) => {
  const client_id = process.env.GOOGLE_CLIENT_ID || '142133221996-fakeclientid.apps.googleusercontent.com';
  const protocol = req.headers['x-forwarded-proto'] || 'http';
  const host = req.headers.host;
  const redirectUri = process.env.APP_URL ? `${process.env.APP_URL}/auth/callback` : `${protocol}://${host}/auth/callback`;
  
  const params = new URLSearchParams({
    client_id: client_id,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'openid email profile',
    access_type: 'offline',
    prompt: 'consent'
  });
  
  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
  res.json({ url: authUrl });
});

app.get(['/auth/callback', '/auth/callback/'], async (req, res) => {
  const { code } = req.query;
  if (!code || typeof code !== 'string') {
    return res.send(`
      <html>
        <body style="background-color: #030303; color: #FFFFFF; font-family: sans-serif; text-align: center; padding-top: 50px;">
          <h2 style="color: #EF4444;">❌ AUTHENTICATION CODE EXCEPTION</h2>
          <p>No authorization code was returned by Google. Returning to registration...</p>
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'OAUTH_AUTH_FAILURE', error: 'No authorization code returned from Google.' }, '*');
              window.close();
            } else {
              window.location.href = '/auth/login';
            }
          </script>
        </body>
      </html>
    `);
  }

  try {
    const client_id = process.env.GOOGLE_CLIENT_ID || '';
    const client_secret = process.env.GOOGLE_CLIENT_SECRET || '';
    const protocol = req.headers['x-forwarded-proto'] || 'http';
    const host = req.headers.host;
    const redirectUri = process.env.APP_URL ? `${process.env.APP_URL}/auth/callback` : `${protocol}://${host}/auth/callback`;

    // Exchange authorization code for access tokens
    const response = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id,
        client_secret,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code'
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Google token exchange failed: ${errorText}`);
    }

    const tokenData = await response.json();
    const accessToken = tokenData.access_token;

    // Fetch athlete profile info via Google Userinfo API
    const userInfoResponse = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${accessToken}` }
    });

    if (!userInfoResponse.ok) {
      throw new Error('Failed to retrieve verified user information from Google.');
    }

    const googleUser = await userInfoResponse.json();
    const email = (googleUser.email || '').toLowerCase();
    const name = googleUser.name || 'Google Athlete';

    if (!email) {
      throw new Error('Google oauth profile did not provide an email address.');
    }

    // Find existing profile or register a new verified account
    let user = db.users.find(u => u.email.toLowerCase() === email);
    let isNewUser = false;
    
    if (!user) {
      isNewUser = true;
      user = {
        id: `u-${Date.now()}`,
        name: name.trim(),
        email: email,
        googleId: googleUser.sub,
        password: hashPassword(crypto.randomBytes(16).toString('hex')), // Secure unique placeholder password
        subscriptionStatus: "free",
        isVerified: true, // Google accounts come as verified
        verificationToken: null,
        verificationTokenExpiresAt: null,
        fitnessGoals: [],
        currentWeight: 80,
        targetWeight: 75,
        height: 175,
        age: 25,
        gender: "Not specified",
        activityLevel: "Not specified",
        avatar: googleUser.picture || ''
      };
      db.users.push(user);
    } else {
      // Bind Google Account link if not already bound
      if (!user.googleId) {
        user.googleId = googleUser.sub;
      }
      user.isVerified = true; // Auto-verify email
    }
    saveDB(db);

    // Set high-security session cookie inside parent frame
    setSessionCookie(res, user.id);

    // Send postMessage signal and close popups
    res.send(`
      <html>
        <body style="background-color: #030303; color: #FFFFFF; font-family: sans-serif; text-align: center; padding-top: 60px; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 400px; margin: 0 auto; background-color: #0F0F0F; border: 1px solid #1F1F1F; padding: 30px; border-radius: 4px;">
            <h2 style="color: #F59E0B; font-size: 16px; letter-spacing: 1px; text-transform: uppercase;">🔒 SESSION AUTHORIZED</h2>
            <p style="font-size: 13px; color: #A3A3A3; line-height: 1.5; margin: 15px 0;">Authentication finalized for <b>${user.name}</b>. This window will now self-dismiss and redirect your primary portal.</p>
            <div style="width: 24px; height: 24px; border: 3px solid #F59E0B; border-top-color: transparent; border-radius: 50%; margin: 20px auto; animation: spin 1s infinite linear;"></div>
          </div>
          <style>@keyframes spin { 100% { transform: rotate(360deg); } }</style>
          <script>
            setTimeout(() => {
              if (window.opener) {
                window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS', userId: '${user.id}' }, '*');
                window.close();
              } else {
                window.location.href = '/dashboard';
              }
            }, 1000);
          </script>
        </body>
      </html>
    `);
  } catch (error: any) {
    console.error("Google Auth processing error caught:", error);
    res.send(`
      <html>
        <body style="background-[#030303] text-white font-sans text-center pt-10;">
          <p style="color: #EF4444; font-weight: bold;">Authentication Processing Aborted</p>
          <p style="color: #888888; font-size: 12px;">${error.message || 'Verification signature mismatch.'}</p>
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'OAUTH_AUTH_FAILURE', error: '${error.message || 'Callback mapping failure'}' }, '*');
              window.close();
            } else {
              window.location.href = '/auth/login?error=' + encodeURIComponent('${error.message || 'Auth failure'}');
            }
          </script>
        </body>
      </html>
    `);
  }
});

// 3. Profile settings APIs
app.post('/api/profile/update', (req, res) => {
  const { userId, fitnessGoals, currentWeight, targetWeight, height, age, gender, activityLevel } = req.body;
  const userIndex = db.users.findIndex(u => u.id === userId);
  
  if (userIndex === -1) {
    return res.status(404).json({ error: "User not found" });
  }

  db.users[userIndex] = {
    ...db.users[userIndex],
    fitnessGoals: fitnessGoals || db.users[userIndex].fitnessGoals,
    currentWeight: currentWeight !== undefined ? Number(currentWeight) : db.users[userIndex].currentWeight,
    targetWeight: targetWeight !== undefined ? Number(targetWeight) : db.users[userIndex].targetWeight,
    height: height !== undefined ? Number(height) : db.users[userIndex].height,
    age: age !== undefined ? Number(age) : db.users[userIndex].age,
    gender: gender || db.users[userIndex].gender,
    activityLevel: activityLevel || db.users[userIndex].activityLevel
  };
  
  // Log a progress metric automatically
  const activeUser = db.users[userIndex];
  const progressDate = new Date().toISOString().split('T')[0];
  const existingProg = db.progress.find(p => p.userId === userId && p.date === progressDate);
  if (existingProg) {
    existingProg.weight = activeUser.currentWeight;
  } else {
    db.progress.push({
      id: `p-${Date.now()}`,
      userId,
      date: progressDate,
      weight: activeUser.currentWeight || 80,
      waterIntakeLiters: 2.0,
      chest: 100, waist: 88, hips: 98, biceps: 36, thighs: 56
    });
  }

  saveDB(db);
  syncToFirestore('users', userId, db.users[userIndex]);
  const targetProgLog = db.progress.find(p => p.userId === userId && p.date === progressDate);
  if (targetProgLog) {
    syncToFirestore('progress', targetProgLog.id, targetProgLog);
  }
  res.json({ success: true, user: db.users[userIndex] });
});

// 4. Progress history APIs
app.get('/api/progress/history', (req, res) => {
  const { userId } = req.query;
  if (!userId) return res.status(400).json({ error: "No userId provided" });
  
  const userProgress = db.progress.filter(p => p.userId === userId);
  res.json(userProgress);
});

app.post('/api/progress/add', (req, res) => {
  const { userId, date, weight, waterIntakeLiters, chest, waist, hips, biceps, thighs } = req.body;
  if (!userId) return res.status(400).json({ error: "No userId provided" });

  const progressEntry = {
    id: `p-${Date.now()}`,
    userId,
    date: date || new Date().toISOString().split('T')[0],
    weight: Number(weight) || 75,
    waterIntakeLiters: Number(waterIntakeLiters) || 2,
    chest: Number(chest) || undefined,
    waist: Number(waist) || undefined,
    hips: Number(hips) || undefined,
    biceps: Number(biceps) || undefined,
    thighs: Number(thighs) || undefined
  };

  db.progress.push(progressEntry);
  saveDB(db);
  syncToFirestore('progress', progressEntry.id, progressEntry);
  res.status(201).json(progressEntry);
});

// 5. Workout and Meal Logger APIs
app.get('/api/workouts/history', (req, res) => {
  const { userId } = req.query;
  const userWorkouts = db.workouts.filter(w => w.userId === userId);
  res.json(userWorkouts);
});

app.post('/api/workouts/add', (req, res) => {
  const { userId, date, name, duration, caloriesBurned, exercises } = req.body;
  const newWorkout = {
    id: `w-${Date.now()}`,
    userId,
    date: date || new Date().toISOString().split('T')[0],
    name,
    duration: Number(duration) || 45,
    caloriesBurned: Number(caloriesBurned) || 300,
    exercises: exercises || []
  };

  db.workouts.push(newWorkout);
  saveDB(db);
  syncToFirestore('workouts', newWorkout.id, newWorkout);
  res.status(201).json(newWorkout);
});

app.get('/api/meals/history', (req, res) => {
  const { userId } = req.query;
  const userMeals = db.meals.filter(m => m.userId === userId);
  res.json(userMeals);
});

app.post('/api/meals/add', (req, res) => {
  const { userId, date, mealType, foodItems } = req.body;
  const newMeal = {
    id: `m-${Date.now()}`,
    userId,
    date: date || new Date().toISOString().split('T')[0],
    mealType,
    foodItems: foodItems || []
  };

  db.meals.push(newMeal);
  saveDB(db);
  syncToFirestore('meals', newMeal.id, newMeal);
  res.status(201).json(newMeal);
});

// 5.2 Live Support Chat System
app.get('/api/support/chats', (req, res) => {
  try {
    const { chatSessionId } = req.query;
    if (!chatSessionId || typeof chatSessionId !== 'string') {
      return res.status(400).json({ error: "chatSessionId query parameter is required" });
    }
    
    // Defensive sanitization of supportChats to eliminate nulls or corrupted entries
    db.supportChats = (db.supportChats || []).filter(c => c && typeof c === 'object' && typeof c.chatSessionId === 'string');
    
    const sessionChats = db.supportChats.filter(c => c.chatSessionId === chatSessionId);
    
    const role = req.query.role || 'user';
    let modified = false;
    db.supportChats.forEach(c => {
      if (c.chatSessionId === chatSessionId) {
        if (role === 'admin' && c.senderRole === 'user' && !c.read) {
          c.read = true;
          modified = true;
        } else if (role === 'user' && c.senderRole === 'admin' && !c.read) {
          c.read = true;
          modified = true;
        }
      }
    });

    if (modified) {
      saveDB(db);
    }

    res.json(sessionChats);
  } catch (err: any) {
    console.error("[SUPPORT CHATS GET ERROR]:", err);
    res.status(500).json({ error: err.message || "Failed to retrieve support chats" });
  }
});

app.post('/api/support/send', (req, res) => {
  try {
    const { chatSessionId, senderName, senderEmail, message, senderRole } = req.body;
    
    if (!chatSessionId || !message) {
      return res.status(400).json({ error: "chatSessionId and message fields are required" });
    }

    db.supportChats = (db.supportChats || []).filter(c => c && typeof c === 'object' && typeof c.chatSessionId === 'string');

    const newChat = {
      id: `msg-${Date.now()}`,
      chatSessionId,
      senderName: senderName || 'Guest Athlete',
      senderEmail: senderEmail || '',
      message,
      senderRole: senderRole || 'user',
      timestamp: new Date().toISOString(),
      read: false
    };

    db.supportChats.push(newChat);
    saveDB(db);
    syncToFirestore('supportChats', newChat.id, newChat);
    res.status(201).json(newChat);
  } catch (err: any) {
    console.error("[SUPPORT CHATS SEND ERROR]:", err);
    res.status(500).json({ error: err.message || "Failed to send support chat message" });
  }
});

app.get('/api/support/admin/sessions', (req, res) => {
  try {
    db.supportChats = (db.supportChats || []).filter(c => c && typeof c === 'object' && typeof c.chatSessionId === 'string');
    
    const sessionsMap: Record<string, any> = {};
    
    db.supportChats.forEach(c => {
      const id = c.chatSessionId;
      if (!sessionsMap[id]) {
        sessionsMap[id] = {
          chatSessionId: id,
          senderName: 'Guest Athlete',
          senderEmail: '',
          lastMessage: '',
          lastTimestamp: '',
          unreadCount: 0
        };
      }
      
      if (c.senderRole === 'user') {
        sessionsMap[id].senderName = c.senderName;
        sessionsMap[id].senderEmail = c.senderEmail;
      }
      
      if (c.senderRole === 'user' && !c.read) {
        sessionsMap[id].unreadCount += 1;
      }

      sessionsMap[id].lastMessage = c.message;
      sessionsMap[id].lastTimestamp = c.timestamp;
    });

    const sessionsList = Object.values(sessionsMap).sort((a: any, b: any) => {
      return new Date(b.lastTimestamp).getTime() - new Date(a.lastTimestamp).getTime();
    });

    res.json(sessionsList);
  } catch (err: any) {
    console.error("[SUPPORT CHATS ADMIN SESSIONS ERROR]:", err);
    res.status(500).json({ error: err.message || "Failed to retrieve support sessions" });
  }
});

app.post('/api/support/admin/reply', (req, res) => {
  try {
    const { chatSessionId, message } = req.body;
    if (!chatSessionId || !message) {
      return res.status(400).json({ error: "chatSessionId and message are required" });
    }

    db.supportChats = (db.supportChats || []).filter(c => c && typeof c === 'object' && typeof c.chatSessionId === 'string');

    const newChat = {
      id: `msg-${Date.now()}`,
      chatSessionId,
      senderName: 'Lead Coach Admin',
      senderEmail: 'muzikworld08@gmail.com',
      message,
      senderRole: 'admin',
      timestamp: new Date().toISOString(),
      read: false
    };

    db.supportChats.push(newChat);
    saveDB(db);
    syncToFirestore('supportChats', newChat.id, newChat);
    res.status(201).json(newChat);
  } catch (err: any) {
    console.error("[SUPPORT CHATS ADMIN REPLY ERROR]:", err);
    res.status(500).json({ error: err.message || "Failed to post support reply" });
  }
});

// 5.5 Nutrition Intelligence & Food Description Analyzer
app.post('/api/nutrition/analyze', async (req, res) => {
  const { foodInput } = req.body;
  if (!foodInput || typeof foodInput !== 'string') {
    return res.status(400).json({ error: "Food description description input is required" });
  }

  const authUserId = getUserIdFromRequest(req);
  if (!authUserId) {
    return res.status(401).json({ error: "PREMIUM_LOCKED", message: "Authentication required to consult nutrition engine." });
  }
  const userObj = db.users.find(u => u.id === authUserId);
  if (!userObj || !isPremiumUser(userObj)) {
    return res.status(403).json({ error: "PREMIUM_LOCKED", message: "Only premium tier workout subscribers can invoke nutrition engine analysis!" });
  }

  const ai = getGeminiClient();
  if (ai) {
    try {
      const prompt = `Under Premium Sports Dietetics, you are a world-class calorie and macronutrient estimation engine.
Analyze this user food input description and estimate its nutritional values for 1 typical serving (or the exact portions/counts described):
Food Input: "${foodInput}"

Provide the response in EXCLUSIVELY a single valid JSON object containing exactly the following keys:
{
  "name": "Standardized name with portion details",
  "calories": estimated_calories_in_kcal,
  "protein": estimated_protein_in_grams,
  "carbs": estimated_carbs_in_grams,
  "fat": estimated_fat_in_grams
}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "OBJECT",
            properties: {
              name: { type: "STRING", description: "Standardized food name and serving description" },
              calories: { type: "INTEGER", description: "Estimated total calories in kcal" },
              protein: { type: "INTEGER", description: "Estimated protein in grams" },
              carbs: { type: "INTEGER", description: "Estimated carbohydrates in grams" },
              fat: { type: "INTEGER", description: "Estimated fats in grams" },
            },
            required: ["name", "calories", "protein", "carbs", "fat"]
          }
        }
      });

      const jsonText = response.text || "{}";
      const cleaned = jsonText.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleaned);
      return res.json({ status: "success", data: parsed });
    } catch (err: any) {
      console.error("[NUTRITION ANALYZER] Gemini error, switching to rule-based fallback:", err);
    }
  }

  // Local rule-based/regex fallback when Gemini is or offline
  console.log("[NUTRITION ANALYZER] Using intelligent offline local fallbacks");
  const fallbackFoods = [
    { regex: /egg/i, name: "Boiled Egg (Single)", calories: 75, protein: 6, carbs: 0.6, fat: 5 },
    { regex: /rice/i, name: "White/Jollof Rice (1 Cup)", calories: 350, protein: 7, carbs: 75, fat: 2 },
    { regex: /chicken/i, name: "Grilled Chicken Breast (150g)", calories: 250, protein: 35, carbs: 0, fat: 5.5 },
    { regex: /yam/i, name: "Boiled Yam (Slice)", calories: 120, protein: 1.5, carbs: 28, fat: 0.1 },
    { regex: /plantain/i, name: "Boiled/Roasted Plantain (Single)", calories: 150, protein: 1.3, carbs: 32, fat: 0.4 },
    { regex: /beef/i, name: "Lean Beef Steak (150g)", calories: 280, protein: 32, carbs: 0, fat: 12 },
    { regex: /fish/i, name: "Grilled Croaker Fish (200g)", calories: 190, protein: 30, carbs: 0, fat: 7.5 },
    { regex: /banana/i, name: "Banana (Medium)", calories: 89, protein: 1.1, carbs: 23, fat: 0.3 },
    { regex: /oat/i, name: "Rolled Oats (1 Cup)", calories: 300, protein: 11, carbs: 54, fat: 5 },
    { regex: /bean/i, name: "Brown Beans (Boiled, 1 Cup)", calories: 340, protein: 22, carbs: 60, fat: 1 },
    { regex: /shake/i, name: "Protein Shake (1 Scoop)", calories: 140, protein: 25, carbs: 3, fat: 1.5 },
  ];

  const matched = fallbackFoods.find(f => f.regex.test(foodInput));
  if (matched) {
    return res.json({
      status: "success",
      data: {
        name: `${foodInput} (Estimated as ${matched.name})`,
        calories: matched.calories,
        protein: matched.protein,
        carbs: matched.carbs,
        fat: matched.fat
      }
    });
  }

  // Completely neutral default if nothing matches at all
  return res.json({
    status: "success",
    data: {
      name: foodInput,
      calories: 120,
      protein: 5,
      carbs: 20,
      fat: 3
    }
  });
});

// Helper to obtain Monnify Access Token
async function getMonnifyAccessToken(): Promise<string> {
  const { baseUrl, apiKey, secretKey } = MONNIFY_CONFIG;
  if (!apiKey || !secretKey) {
    throw new Error('MONNIFY_API_KEY or MONNIFY_SECRET_KEY is not defined in environment variables');
  }
  const basicAuth = Buffer.from(`${apiKey}:${secretKey}`).toString('base64');
  console.log(`[MONNIFY AUTH] Requesting token from ${baseUrl}/api/v1/auth/login`);
  
  const authRes = await fetch(`${baseUrl}/api/v1/auth/login`, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${basicAuth}`,
      'Content-Type': 'application/json'
    }
  });

  if (!authRes.ok) {
    const errText = await authRes.text();
    throw new Error(`Monnify Auth Endpoint rejected request with status ${authRes.status}: ${errText}`);
  }

  const data = await authRes.json() as any;
  if (data.requestSuccessful === true && data.responseBody?.accessToken) {
    return data.responseBody.accessToken;
  }
  throw new Error(`Failed to obtain Access Token: ${data.responseMessage || 'Empty body response'}`);
}

// 6. Payment APIs - Monnify Portal real integration
app.post(['/api/payment/initiate', '/api/payment/initialize'], async (req, res) => {
  const { userId, planType, amount, email, customerName } = req.body;
  const payerEmail = (email || '').trim().toLowerCase();
  
  if (!payerEmail) {
    return res.status(400).json({ error: "Customer email is required for transaction initialization" });
  }

  const txRef = `ALX-FIT-${Date.now()}`;
  console.log(`[MONNIFY] Initializing payment. PlanType: ${planType}, Amount: ${amount}, Email: ${payerEmail}`);

  // Safe lazy check for missing keys to implement error-safe dynamic sandbox model fallback
  const { apiKey, secretKey, contractCode } = MONNIFY_CONFIG;
  const isDemoOrMissingKeys = !apiKey || apiKey.startsWith('YOUR_') || apiKey === '' || !secretKey || secretKey.startsWith('YOUR_') || secretKey === '' || !contractCode;

  if (isDemoOrMissingKeys) {
    console.warn("[MONNIFY] API/Secret Keys are missing or placeholders. Activating server-side graceful sandbox simulation fallback.");
    const paymentRecord = {
      id: `pay-${Date.now()}`,
      userId: userId || 'anonymous',
      transactionReference: `sim-${Date.now()}`,
      paymentReference: txRef,
      amount: Number(amount),
      customerEmail: payerEmail,
      customerName: customerName || req.body.name || 'Athlete Name',
      status: "pending",
      paymentMethod: "pending",
      planType: planType || 'Elite',
      createdAt: new Date().toISOString(),
      paidAt: null
    };

    db.payments.push(paymentRecord);
    await saveDB(db);

    return res.json({
      status: "success",
      isSimulated: true,
      message: "Initialized in sandbox simulator mode (keys missing)",
      paymentReference: txRef,
      checkoutUrl: "",
      transactionReference: paymentRecord.transactionReference,
      amount,
      email: payerEmail,
      apiKey: "MK_TEST_MOCK_API_KEY",
      contractCode: "MOCK_CONTRACT_CODE"
    });
  }

  try {
    // 1. Get Access Token
    const accessToken = await getMonnifyAccessToken();

    // 2. Prepare Payload
    const monnifyPayload = {
      amount: Number(amount),
      customerName: customerName || req.body.name || 'Athlete Client',
      customerEmail: payerEmail,
      paymentReference: txRef,
      paymentDescription: `ALEXFITNESSHUB Subscription: ${planType || 'Elite Tier'}`,
      currencyCode: "NGN",
      contractCode: MONNIFY_CONFIG.contractCode,
      redirectUrl: `${process.env.APP_URL || 'http://localhost:3000'}/dashboard`
    };

    console.log(`[MONNIFY] Sending transaction payload to Monnify:`, JSON.stringify(monnifyPayload));

    // 3. Request Monnify to initialize
    const initRes = await fetch(`${MONNIFY_CONFIG.baseUrl}/api/v1/merchant/transactions/init-transaction`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(monnifyPayload)
    });

    if (!initRes.ok) {
      const errText = await initRes.text();
      console.error(`[MONNIFY ERROR] Init transaction rejected:`, errText);
      return res.status(initRes.status).json({ error: `Monnify Initialization Rejected: ${errText}` });
    }

    const initData = await initRes.json() as any;
    console.log(`[MONNIFY SUCCESS] Transaction response data:`, JSON.stringify(initData));

    if (initData.requestSuccessful && initData.responseBody) {
      const { transactionReference, checkoutUrl, paymentReference } = initData.responseBody;

      // 4. Save record with "pending" status in database
      const paymentRecord = {
        id: `pay-${Date.now()}`,
        userId: userId || 'anonymous',
        transactionReference: transactionReference || '',
        paymentReference: paymentReference || txRef,
        amount: Number(amount),
        customerEmail: payerEmail,
        customerName: customerName || req.body.name || 'Athlete Name',
        status: "pending",
        paymentMethod: "pending",
        planType: planType || 'Elite',
        createdAt: new Date().toISOString(),
        paidAt: null
      };

      db.payments.push(paymentRecord);
      await saveDB(db);

      // Return details to frontend
      return res.json({
        status: "success",
        message: "Transaction initialized successfully",
        paymentReference: paymentReference || txRef,
        checkoutUrl,
        transactionReference,
        amount,
        email: payerEmail,
        apiKey: MONNIFY_CONFIG.apiKey,
        contractCode: MONNIFY_CONFIG.contractCode
      });
    } else {
      return res.status(400).json({ error: initData.responseMessage || "Failed to initialize checkout session with Monnify" });
    }

  } catch (error: any) {
    console.error(`[MONNIFY] SDK/API failed to run complete initialization:`, error);
    return res.status(500).json({ error: `Internal payment error: ${error.message}` });
  }
});

// Legacy POST validator / Instant Upgrade verify Simulation (Fallback/Local Test Helper)
app.post('/api/payment/verify', async (req, res) => {
  const { reference, userId, planType, amount, paymentStatus, transactionReference } = req.body;
  
  const userIndex = db.users.findIndex(u => u.id === userId);
  if (userIndex !== -1) {
    const user = db.users[userIndex];
    activatePremiumSubscription(user, planType, transactionReference || reference);
    
    // Save completed payment log
    db.payments.push({
      id: `pay-${Date.now()}`,
      userId,
      amount: Number(amount),
      paymentReference: reference,
      transactionReference: transactionReference || '',
      reference,
      status: "completed",
      paymentMethod: "CARD",
      createdAt: new Date().toISOString(),
      paidAt: new Date().toISOString(),
      date: new Date().toISOString(),
      planType
    });
    
    let normalPrice = '₦' + (planType?.toLowerCase().includes('yearly') ? '300,000' : '₦25,000');
    let savings = '0%';
    let planDesc = "Monthly Elite Tier";

    if (planType?.toLowerCase().includes('yearly')) {
      savings = '₦30,000 Discount Saved';
      planDesc = "Annual Champion Tier";
    } else if (planType?.toLowerCase().includes('months') || planType?.toLowerCase().includes('monthly')) {
      const match = planType.match(/(\d+)\s*months/i);
      const multiply = match ? parseInt(match[1]) : 1;
      normalPrice = '₦' + (multiply * 25000).toLocaleString();
      if (multiply > 1) {
        savings = '5% Multi-Month Discount';
        planDesc = `${multiply} Months Premium Bundle`;
      }
    }

    try {
      const subHtml = renderEmailTemplate('subscription', {
        name: user.name,
        planName: planDesc
      });
      sendEmail({
        to: user.email,
        subject: `🎖️ ALEXFITNESSHUB: Subscription Active - Premium Unlocked`,
        html: subHtml,
        text: `Your ${planDesc} has been activated.`,
        type: 'subscription'
      }).catch(e => console.error(e));

      const receiptHtml = renderEmailTemplate('receipt', {
        name: user.name,
        transId: reference,
        email: user.email,
        date: new Date().toISOString().split('T')[0],
        normalPrice,
        savings,
        amount: Number(amount).toLocaleString()
      });
      sendEmail({
        to: user.email,
        subject: `🧾 ALEXFITNESSHUB: Monnify Instant Payment Receipt`,
        html: receiptHtml,
        text: `Receipt Reference: ${reference}`,
        type: 'receipt'
      }).catch(e => console.error(e));
    } catch (emailErr) {
      console.error(emailErr);
    }
    
    await saveDB(db);
    return res.json({ success: true, user: db.users[userIndex] });
  }

  res.status(404).json({ error: "User not found" });
});

// 5. BACKEND — Payment Verification (Fallback/Manual query validation)
app.get('/api/payment/verify/:transactionReference', async (req, res) => {
  const { transactionReference } = req.params;
  console.log(`[MONNIFY] Manual verification query requested: ${transactionReference}`);

  try {
    const token = await getMonnifyAccessToken();
    const queryUrl = `${MONNIFY_CONFIG.baseUrl}/api/v2/merchant/transactions/query?transactionReference=${encodeURIComponent(transactionReference)}`;
    
    const queryRes = await fetch(queryUrl, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (!queryRes.ok) {
      const errText = await queryRes.text();
      return res.status(queryRes.status).json({ success: false, error: `Monnify verification query failed: ${errText}` });
    }

    const verifyData = await queryRes.json() as any;
    console.log("[MONNIFY VERIFY RESPONSE]", JSON.stringify(verifyData));

    if (verifyData.requestSuccessful === true && verifyData.responseBody) {
      const { paymentStatus, paymentReference, customer, amountPaid, paymentMethod, paidOn } = verifyData.responseBody;

      if (paymentStatus === 'PAID') {
        const paymentIndex = db.payments.findIndex(p => p.paymentReference === paymentReference || p.transactionReference === transactionReference);
        
        if (paymentIndex !== -1) {
          db.payments[paymentIndex].status = "completed";
          db.payments[paymentIndex].paymentMethod = paymentMethod || 'CARD';
          db.payments[paymentIndex].paidAt = paidOn || new Date().toISOString();
          
          const uId = db.payments[paymentIndex].userId;
          const userIndex = db.users.findIndex(u => u.id === uId || u.email.toLowerCase() === customer?.email?.toLowerCase());
          if (userIndex !== -1) {
            activatePremiumSubscription(db.users[userIndex], db.payments[paymentIndex].planType || "Elite Tier", transactionReference || paymentReference);
            
            // Trigger confirmation emails if possible
            const user = db.users[userIndex];
            const planDesc = db.payments[paymentIndex].planType || "Elite Tier";
            try {
              const subHtml = renderEmailTemplate('subscription', {
                name: user.name,
                planName: planDesc
              });
              sendEmail({
                to: user.email,
                subject: `🎖️ ALEXFITNESSHUB: Subscription Active - Premium Verified`,
                html: subHtml,
                text: `Your ${planDesc} has been activated.`,
                type: 'subscription'
              }).catch(e => console.error(e));
            } catch (err) {
              console.error(err);
            }
          }
          await saveDB(db);
        } else {
          // Fallback log creation
          const userIndex = db.users.findIndex(u => u.email.toLowerCase() === customer?.email?.toLowerCase());
          const userId = userIndex !== -1 ? db.users[userIndex].id : 'anonymous';
          const newPayment = {
            id: `pay-${Date.now()}`,
            userId,
            transactionReference: transactionReference || '',
            paymentReference: paymentReference || '',
            amount: Number(amountPaid),
            customerEmail: customer?.email || '',
            customerName: customer?.name || 'Athlete Name',
            status: "completed",
            paymentMethod: paymentMethod || 'CARD',
            planType: "Elite Tier",
            createdAt: new Date().toISOString(),
            paidAt: paidOn || new Date().toISOString()
          };
          db.payments.push(newPayment);
          if (userIndex !== -1) {
            activatePremiumSubscription(db.users[userIndex], "Elite Tier", transactionReference || paymentReference);
          }
          await saveDB(db);
        }
        return res.json({ success: true, paymentStatus, verified: true });
      } else {
        return res.json({ success: false, paymentStatus, verified: false });
      }
    }
    return res.status(400).json({ success: false, error: "Empty database query payload response" });
  } catch (error: any) {
    console.error("[MONNIFY FALLBACK] Manual verify exception code caught:", error);
    return res.status(500).json({ success: false, error: error.message });
  }
});

// Secure Monnify Webhook listener with HMAC SHA512 signature verification
app.post('/api/payment/webhook', async (req, res) => {
  const secretKey = MONNIFY_CONFIG.secretKey;
  const customSignature = req.headers['monnify-signature'];
  
  console.log(`[MONNIFY WEBHOOK RECEIVED] Checking premium upgrade triggers...`);
  
  if (secretKey && customSignature) {
    const rawBody = JSON.stringify(req.body);
    const computedSignature = crypto
      .createHmac('sha512', secretKey)
      .update(rawBody)
      .digest('hex');
      
    if (computedSignature === customSignature) {
      console.log("[MONNIFY WEBHOOK] Signature validation verified successfully.");
      const { paymentStatus, paymentReference, transactionReference, customer, amountPaid, paymentMethod, paidOn } = req.body;
      
      if (paymentStatus === 'PAID') {
        const paymentIndex = db.payments.findIndex(p => p.paymentReference === paymentReference || p.transactionReference === transactionReference);
        
        if (paymentIndex !== -1) {
          // Idempotency: skip if already marked as completed
          if (db.payments[paymentIndex].status === "completed") {
            console.log(`[MONNIFY WEBHOOK] Transaction ${paymentReference} is already completed. Ignoring duplicate hook.`);
            return res.json({ status: "success", info: "already completed" });
          }

          db.payments[paymentIndex].status = "completed";
          db.payments[paymentIndex].transactionReference = transactionReference || db.payments[paymentIndex].transactionReference;
          db.payments[paymentIndex].paymentMethod = paymentMethod || "CARD";
          db.payments[paymentIndex].paidAt = paidOn || new Date().toISOString();
          
          const uId = db.payments[paymentIndex].userId;
          const userIndex = db.users.findIndex(u => u.id === uId || u.email.toLowerCase() === customer?.email?.toLowerCase());
          if (userIndex !== -1) {
            activatePremiumSubscription(db.users[userIndex], db.payments[paymentIndex].planType || "Elite Tier", transactionReference || paymentReference);
            
            const user = db.users[userIndex];
            const planDesc = db.payments[paymentIndex].planType || "Elite Tier";
            try {
              const subHtml = renderEmailTemplate('subscription', {
                name: user.name,
                planName: planDesc
              });
              sendEmail({
                to: user.email,
                subject: `🎖️ ALEXFITNESSHUB: Subscription Active - Premium Unlocked`,
                html: subHtml,
                text: `Your ${planDesc} has been activated.`,
                type: 'subscription'
              }).catch(e => console.error("Email send fail inside webhook", e));
            } catch (err) {
              console.error("[MONNIFY WEBHOOK] Email broadcast system exception:", err);
            }
          }
          await saveDB(db);
          console.log(`[MONNIFY WEBHOOK] Successful payment processed. Database synced!`);
        } else {
          console.log(`[MONNIFY WEBHOOK] Active payment verified but reference ${paymentReference} was not pre-logged. Creating fallback record.`);
          const userIndex = db.users.findIndex(u => u.email.toLowerCase() === customer?.email?.toLowerCase());
          const userId = userIndex !== -1 ? db.users[userIndex].id : 'anonymous';
          const fallbackRecord = {
            id: `pay-${Date.now()}`,
            userId,
            transactionReference: transactionReference || '',
            paymentReference: paymentReference || '',
            amount: Number(amountPaid),
            customerEmail: customer?.email || '',
            customerName: customer?.name || 'Athlete Name',
            status: "completed",
            paymentMethod: paymentMethod || "CARD",
            planType: "Elite Tier",
            createdAt: new Date().toISOString(),
            paidAt: paidOn || new Date().toISOString()
          };
          db.payments.push(fallbackRecord);
          if (userIndex !== -1) {
            activatePremiumSubscription(db.users[userIndex], "Elite Tier", transactionReference || paymentReference);
          }
          await saveDB(db);
        }
      }
      return res.status(200).json({ status: "success", validated: true });
    } else {
      console.error("[MONNIFY WEBHOOK] Security Exception: Invalid signature header!");
      return res.status(400).json({ error: "Invalid signature" });
    }
  }
  
  console.log("[MONNIFY WEBHOOK] Request lacking authentication signature context.");
  return res.status(400).json({ error: "Missing signature context headers" });
});

// 7. AI Platform Coach with actual Gemini integration
app.post('/api/coach/ask', async (req, res) => {
  const { message, userId, goalSearch } = req.body;
  
  const authUserId = getUserIdFromRequest(req) || userId;
  if (!authUserId) return res.status(400).json({ error: "authentication required to consult coach" });
  
  const userObj = db.users.find(u => u.id === authUserId);
  if (!userObj) return res.status(404).json({ error: "Authenticated user profile not found in master register" });

  // PREMIUM PROTECTION CONSTRAINT
  if (!isPremiumUser(userObj)) {
    return res.status(403).json({ error: "PREMIUM_LOCKED", message: "Only premium tier workout subscribers can invoke AI platform consults!" });
  }

  const ai = getGeminiClient();

  // Create prompt rich in context of the platform setup
  let prompt = "";
  if (goalSearch) {
    if (goalSearch.toLowerCase().includes('diet') || goalSearch.toLowerCase().includes('meal') || goalSearch.toLowerCase().includes('nutrition')) {
      prompt = `Under absolute Premium Dietitian Protocol, you are the Head Anabolic Dietitian of ALEXFITNESSHUB.
      The user requested a highly professional, customized meal plan with target specifications: "${goalSearch}".
      User Context:
      - Weight: ${userObj.currentWeight || '82'}kg (Target: ${userObj.targetWeight || '75'}kg)
      - Fitness Goals: ${userObj.fitnessGoals?.join(', ') || 'Muscle hypertrophy & Fat-Loss'}
      - Activity Level: ${userObj.activityLevel || 'Active'}
      
      Generate a professional, exceptionally detailed gourmet meal and macro schedule conforming to the requested constraints.
      Include:
      1. METABOLIC RATIOS CHART: Daily total target Calories, Protein, Carbs, Fats, and hydration.
      2. CHEF'S ELITE DAILY MENUS:
         - BREAKFAST: (Gourmet style, e.g. Coconut-Vanilla Protein Oatmeal with chia seeds and soft-boiled egg whites)
         - MID-MORNING SHIELD: (High protein recovery snack, e.g. Plain Greek yogurt with active cultures, honey and raw walnuts)
         - ANABOLIC RECOVERY LUNCH: (Premium high-protein Nigerian meal, e.g. Air-fried Croaker Fish with grilled sweet potatoes and a spinach salad, or Grilled Lemon Chicken with whole jollof brown rice)
         - PEAK PERFORMANCE PM SNACK: (Kettlebell snack e.g. Moi Moi or baked bean cakes with light whey isolate)
         - REPAIR & REBUILD DINNER: (E.g. Tender grilled beef sirloin with garden herbs, pan-seared Brussels sprouts, and steamed asparagus)
      3. SCIENTIFIC PREP TIPS: Seasoning tips to increase thermogenesis (turmeric, garlic, ginger, pepper), and using olive sprays.
      
      Style your response beautifully in standard Markdown tables.`;
    } else {
      prompt = `The user clicked/searched the target goal: "${goalSearch}".
      Create a highly customized elite training and meal protocol matching ALEXFITNESSHUB premium aesthetics.
      User context:
      - Weight: ${userObj.currentWeight || '80'}kg (Target: ${userObj.targetWeight || '75'}kg)
      - Fitness Goal Preference: ${userObj.fitnessGoals?.join(', ') || 'Not set'}
      - Activity Level: ${userObj.activityLevel || 'Moderate'}
      
      Your response must contain:
      1. A premium Bebas Neue-style workout routine split (with precise exercises, sets, reps).
      2. A premium diet schedule (incorporating delicious Nigerian foods like boiled plantains, grilled fish, sweet potatoes, and global food options like salmon, oats, Greek yogurt).
      3. Custom target calories, carbs, protein, and fat.
      4. Pro Coach motivation and tips.
      Please write and style your response beautifully in standard Markdown.`;
    }
  } else {
    prompt = `You are the lead AI Fitness Coach on ALEXFITNESSHUB, a world-class premium fitness coaching platform.
    User Question: "${message}"
    User context:
    - Name: ${userObj.name}
    - Subscription status: ${userObj.subscriptionStatus}
    - Goals: ${userObj.fitnessGoals?.join(', ')}
    - Details: ${userObj.currentWeight}kg, height: ${userObj.height}cm, age: ${userObj.age}
    
    Provide a professional, extremely motivating, and science-backed answer. Focus on body recomposition, calorie budgeting, and exact exercise execution tip. Keep structure clean using bold sections and bullet lists.`;
  }

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are the head AI Fitness Coach on ALEXFITNESSHUB. You speak with ultimate authority, military precision, and inspiring premium fitness coach tone. You recommend optimal ratios, compounds lifts, traditional Nigerian high-protein meals such as roasted fish, Moi Moi, boiled yams and global items like oats, salmon, lean steaks. Avoid generic non-committal answers and provide exact plans.",
        }
      });
      
      const responseText = response.text || "Fitness plan generated successfully.";
      
      // Save query log
      db.questionsLog.push({
        id: `q-${Date.now()}`,
        userId: userObj.id,
        prompt,
        response: responseText,
        date: new Date().toISOString()
      });
      saveDB(db);

      return res.json({ answer: responseText });
    } catch (err: any) {
      console.error("Gemini API call failed", err);
      // Fallback below
    }
  }

  // Graceful highly detailed mock responses for local / offline test or fallback cases
  console.log("Using intelligent rules-based local engine for premium response");
  let responseText = `### MOCK CORE ENGINE SUCCESS: ALEXFITNESSHUB PERSONALIZED BLUEPRINT\n\n`;
  if (goalSearch) {
    responseText += `#### TARGET TRANSFORMATION: **${goalSearch.toUpperCase()}**\n\n`;
    responseText += `*Generated under Premium Protocol rules for Coach ${userObj.name}*\n\n`;
    
    if (goalSearch.toLowerCase().includes('diet') || goalSearch.toLowerCase().includes('meal') || goalSearch.toLowerCase().includes('nutrition')) {
      responseText += `##### 1. METABOLIC NUTRIENT CHART (PRECISE METRIC Ratios)\n\n`;
      responseText += `| Nutrient Dimension | Target Ratio | Primary Function |\n`;
      responseText += `| :--- | :--- | :--- |\n`;
      responseText += `| **Daily Energy Limit** | ${goalSearch.includes('1500') ? '1,500 kcal' : goalSearch.includes('2200') ? '2,200 kcal' : goalSearch.includes('2600') ? '2,600 kcal' : goalSearch.includes('3200') ? '3,200 kcal' : '1,800 kcal'} | Controlled target weight rate |\n`;
      responseText += `| **Protein Density** | 165 grams (35%) | Preservation of lean muscle fibers |\n`;
      responseText += `| **Complex Carbs** | 175 grams (40%) | Clean sustained glycogen fuel |\n`;
      responseText += `| **Hormonal Fats** | 50 grams (25%) | Essential lipid homeostasis |\n`;
      responseText += `| **System Hydration** | 3.0 Liters daily | Micro-cellular muscle plumbing |\n\n`;
      
      responseText += `##### 2. CHEF'S ELITE NUTRITION MATRIX\n\n`;
      responseText += `| Meal Category | Spec & Portion | Active Nutrient Metrics | Ingredients & Prep Methods |\n`;
      responseText += `| :--- | :--- | :--- | :--- |\n`;
      responseText += `| **BREAKFAST** | Coconut Protein Power Oats | 450 kcal \| 32g Protein | Combine 70g rolled oats with 30g whey isolate. Top with 10g flaked coconut, 5g chia seeds, and 3 hard-boiled egg whites. |\n`;
      responseText += `| **MID-MORNING** | Greek Pro-Yogurt Shield | 180 kcal \| 15g Protein | 150g raw fat-free unsweetened Greek yogurt. Mix with 1 tsp raw organic honey and 10g crushed almonds. |\n`;
      responseText += `| **RECOVERY LUNCH** | Grilled Croaker with Yam | 480 kcal \| 38g Protein | 180g of premium grilled Croaker fish seasoned with garlic, turmeric and cayenne. Serve with 120g boiled sweet potato slabs and steamed fresh pumpkin leaf veggies. |\n`;
      responseText += `| **PM GROWTH SNACK** | Baked Moi Moi & Akara | 210 kcal \| 16g Protein | 150g baked bean pudding (Moi Moi) loaded with egg whites. Steam or oven bake to avoid oxidized vegetable oil frying. |\n`;
      responseText += `| **REBUILD DINNER** | Pan-Seared Lemon Chicken | 440 kcal \| 45g Protein | 200g of skinless chicken breast pan-seared in 1 spray olive oil. Season with rosemary, lemon squeeze and serve with a mountain of fresh green garden broccoli and cucumbers. |\n\n`;
      
      responseText += `##### 3. SCIENTIFIC THERMOGENESIS CODES\n`;
      responseText += `* **Thermic Spice Squeeze**: Season all dinners with fresh grated ginger and cayenne pepper. This holds a documented 5% metabolic rate elevation due to elevated core heat kinetics.\n`;
      responseText += `* **Clean Cooking Protocol**: Avoid palm oils or deep shallow pan frying. Swap with low-pressure air fryers or high-grade non-stick pans with avocado oil spray.`;
    } else {
      responseText += `##### 1. ELITE TRAINING SCHEDULE\n`;
      if (goalSearch.toLowerCase().includes('chest') || goalSearch.toLowerCase().includes('shoulders') || goalSearch.toLowerCase().includes('arms')) {
        responseText += `- **Day 1: Heavy Push Dominance (Strength)**\n  * Flat Dumbbell Bench Press: 4 Sets x 6-8 Reps (2 min rest)\n  * Standing Overhead Military Press: 3 Sets x 8 Reps\n  * Incline Barbell Press: 3 Sets x 10 Reps\n  * Cable Chest Crossover (Low to High): 3 Sets x 12 Reps\n- **Day 2: Hypertrophy Arms & Delts (Pump)**\n  * Lateral Dumbbell Raises: 4 Sets x 15 Reps (60s rest)\n  * Alternate Bicep Dumbbell Curls: 3 Sets x 12 Reps\n  * Over-head Tricep Rope Extension: 3 Sets x 12 Reps\n- **Day 3: Strategic Recovery / 12-3-30 Treadmill Protocol**\n  * 12 Incline, 3.0 mph Speed, 30 Minutes. Solid fat burning focus.`;
      } else if (goalSearch.toLowerCase().includes('legs')) {
        responseText += `- **Day 1: Lower Body Mechanical Loading**\n  * Standing Back Barbell Squats: 4 Sets x 8 Reps (Deep parallel)\n  * Romanian Barbell Deadlifts: 3 Sets x 10 Reps (Hamstring stretch focus)\n  * Walking Lunges (Stepping): 3 Sets x 20 Steps total\n  * Standing Calf Raises: 4 Sets x 15 Reps (Squeeze top for 2s)`;
      } else if (goalSearch.toLowerCase().includes('military') || goalSearch.toLowerCase().includes('conditioning')) {
        responseText += `- **Day 1: Special Forces Calisthenics Engine**\n  * Pushups (Perfect military cadence): 5 Sets x Max Reps (Target 50 per set)\n  * Pullups (Strict dead-hang): 4 Set x 8-12 Reps\n  * Military Style Planks: 3 Gaps of 90 Seconds\n  * Tactical 3km Run: Maintain pace under 5:15/km`;
      } else {
        responseText += `- **Day 1: Full-Body Athletic Conditioning**\n  * Deadlift (Strength Baseline): 3 Sets x 5 Reps\n  * Perfect Pushups: 4 Sets x 20 Reps\n  * Dumbbell Goblet Squats: 3 Sets x 12 Reps\n  * Hanging Core Leg Raises: 3 Sets x 15 Reps`;
      }
      
      responseText += `\n\n##### 2. NUTRITION PLAN (HIGH PROTEIN BLUEPRINT)\n`;
      responseText += `- **Breakfast (Oatmeal Power Bowl)**: 70g Oats + 2 Boiled Eggs + 1 Scoop Greek Yogurt. (450 kcal | 28g Protein)\n`;
      responseText += `- **Lunch (Premium Nigerian Recovery)**: 150g Grilled Croaker Fish with Roasted Sweet Potato slices and a large garden salad. (380 kcal | 31g Protein)\n`;
      responseText += `- **Dinner (Anabolic Fuel)**: 200g Lean Chicken Breast Stew with 100g Jollof Rice (using healthy canola/olive oil) + Steamed Vegetables. (520 kcal | 42g Protein)\n`;
      responseText += `- **Hydration**: Clear cucumber/lemon-infused water. Drink minimum 2.5 Liters daily.`;
      responseText += `\n\n##### 3. CALORIE & MACRONUTRIENT BUDGET\n`;
      responseText += `- **Daily Target Intake**: 1,850 kcal\n`;
      responseText += `- **Protein**: 160g (Body recomposition and muscle recovery)\n`;
      responseText += `- **Carbs**: 180g (High fiber complex fuels)\n`;
      responseText += `- **Fat**: 55g (Hormonal optimization and tissue health)`;
    }
  } else {
    responseText += `Hello Champion! Looking at your current weight of **${userObj.currentWeight || '80'}kg**, aiming for **${userObj.targetWeight || '75'}kg**, here is my pro recommendation:\n\n`;
    responseText += `1. **Nutrition**: Focus on a structured caloric budget. Increase protein density using **Grilled Fish**, **Chicken Breast (Stewed/Grilled)**, and **Egg Whites**. These Nigerian and global power proteins trigger muscle synthesis. \n\n`;
    responseText += `2. **Cardio**: Supplement code routines with the **12-3-30 Treadmill protocol** 3 times weekly. This maintains your joint preservation while burning pure fat stores.\n\n`;
    responseText += `3. **Progress**: Log your metrics in the **Progress Analyst** panel. Consistency leads to permanent transformations! Let's get to work!`;
  }
  
  res.json({ answer: responseText });
});

// 8. Admin statistics API
app.get('/api/admin/stats', (req, res) => {
  res.json({
    totalUsers: db.users.length,
    activePremium: db.users.filter(u => u.subscriptionStatus === "premium").length,
    loggedWorkouts: db.workouts.length,
    loggedMeals: db.meals.length,
    revenueSimulated: db.payments.reduce((acc, curr) => acc + curr.amount, 0),
    payments: db.payments,
    users: db.users.map(u => ({ id: u.id, name: u.name, email: u.email, sub: u.subscriptionStatus }))
  });
});

// ----------------------------------------------------------------------------
// SERVE CLIENT ASSETS & ROUTING IN DEV/PROD
// ----------------------------------------------------------------------------

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    // Vite middleware for development
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Server static bundle in production
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ALEXFITNESSHUB running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

